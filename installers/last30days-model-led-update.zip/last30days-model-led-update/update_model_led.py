"""Update only model-led instructions and their stdlib ledger in a known Skill."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path

FILES = ("SKILL.md", "references/codex-research.md", "scripts/research_session.py", "scripts/lib/intelligence/session.py")


def validate(payload):
    manifest = json.loads((payload / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("format") != 1 or set(manifest.get("files", {})) != set(FILES):
        raise ValueError("Unsupported update manifest")
    for name, expected in manifest["files"].items():
        source = payload / name
        if source.is_symlink() or not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest() != expected["after"]:
            raise ValueError("Update payload checksum mismatch")
        if name.endswith(".py"):
            compile(source.read_bytes(), name, "exec")
    return manifest


def update(payload, destination):
    manifest = validate(payload)
    if destination.is_symlink() or not (destination / "scripts/intelligence.py").is_file():
        raise ValueError("Install the full intelligence Skill before applying this update")
    previous, changed = {}, []
    for name in FILES:
        target = destination / name
        if target.is_symlink() or any(p.is_symlink() for p in target.parents if p != destination.parent):
            raise ValueError("Unsupported symbolic link in Skill")
        data = target.read_bytes() if target.is_file() else None
        current = hashlib.sha256(data).hexdigest() if data is not None else None
        expected = manifest["files"][name]
        if current == expected["after"]:
            continue
        if current not in expected["before"]:
            raise ValueError("Unrecognized local modification; no files changed")
        previous[name] = data
        changed.append(name)
    if not changed:
        return {"status": "already_updated", "backup": None}
    backup = destination.parent / (".last30days-model-led-backup-" + datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:8])
    backup.mkdir(mode=0o700)
    for name, data in previous.items():
        if data is not None:
            saved = backup / name
            saved.parent.mkdir(parents=True, exist_ok=True)
            saved.write_bytes(data)
    applied = []
    try:
        for name in changed:
            target = destination / name
            target.parent.mkdir(parents=True, exist_ok=True)
            temporary = target.with_name(target.name + "." + uuid.uuid4().hex + ".tmp")
            try:
                shutil.copyfile(payload / name, temporary)
                os.replace(temporary, target)
                applied.append(name)
            finally:
                temporary.unlink(missing_ok=True)
    except BaseException:
        for name in applied:
            target = destination / name
            if previous[name] is None:
                target.unlink(missing_ok=True)
            else:
                target.write_bytes(previous[name])
        raise
    return {"status": "updated", "path": str(destination), "backup": str(backup),
            "changed_files": changed, "source_configuration_touched": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--payload", type=Path, default=Path(__file__).parent / "payload")
    parser.add_argument("--destination", type=Path, default=Path.home() / ".agents/skills/last30days")
    args = parser.parse_args()
    try:
        result = update(args.payload, args.destination)
    except (ValueError, OSError, KeyError, TypeError) as error:
        print(json.dumps({"status": "update_failed", "error_type": type(error).__name__,
                          "message": str(error) if isinstance(error, ValueError) else "Check the package and installed Skill; existing backup is retained"}))
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
