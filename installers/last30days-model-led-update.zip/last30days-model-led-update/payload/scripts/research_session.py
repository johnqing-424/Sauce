#!/usr/bin/env python3
"""Optional local budget and report ledger for Codex native research."""
from __future__ import annotations

import argparse
import json

from lib.intelligence.session import check_session, finish_session, start_session


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--session-dir", help="Override the local session directory")
    commands = parser.add_subparsers(dest="operation", required=True)
    start = commands.add_parser("start")
    start.add_argument("topic")
    start.add_argument("seconds", type=int, nargs="?", default=360)
    start.add_argument("calls", type=int, nargs="?", default=18)
    check = commands.add_parser("check")
    check.add_argument("id")
    check.add_argument("reserve", type=int, nargs="?", default=0)
    finish = commands.add_parser("finish")
    finish.add_argument("id")
    finish.add_argument("report")
    args = parser.parse_args(argv)
    try:
        if args.operation == "start":
            result = start_session(args.topic, directory=args.session_dir, max_seconds=args.seconds, max_calls=args.calls)
        elif args.operation == "check":
            result = check_session(args.id, directory=args.session_dir, reserve=args.reserve)
        else:
            result = finish_session(args.id, args.report, directory=args.session_dir)
    except (ValueError, OSError, KeyError, TypeError) as error:
        print(json.dumps({"status": "session_ledger_unavailable", "error_type": type(error).__name__,
                          "next_action": "use_host_clock_and_finish_report; no_source_setup_required"}))
        return 1
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
