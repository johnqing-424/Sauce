"""A local deadline ledger for model-led research; no search or setup side effects."""
from __future__ import annotations

import hashlib
import json
import math
import os
import re
import time
import uuid
from pathlib import Path

SCHEMA = "last30days-research-session/1"


def _number(value, low, high):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not low <= value <= high:
        raise ValueError("Invalid research budget")
    return value


def _path(identifier, directory):
    if not isinstance(identifier, str) or not re.fullmatch(r"[0-9a-f]{32}", identifier):
        raise ValueError("Invalid research session id")
    root = Path(directory) if directory is not None else Path.home() / ".local/share/last30days/intelligence/sessions"
    return root / (identifier + ".json")


def _write(state, directory):
    path = _path(state["id"], directory)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    try:
        with os.fdopen(os.open(temporary, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600), "w", encoding="utf-8") as output:
            json.dump(state, output, ensure_ascii=False, allow_nan=False, indent=2)
            output.write("\n")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _read(identifier, directory):
    path = _path(identifier, directory)
    if path.is_symlink() or path.stat().st_size > 16384:
        raise ValueError("Invalid research session file")
    state = json.loads(path.read_text(encoding="utf-8"))
    if state.get("schema_version") != SCHEMA or state.get("id") != identifier or state.get("status") not in {"active", "finished"}:
        raise ValueError("Invalid research session state")
    _number(state["max_seconds"], 1, 3600)
    _number(state["max_calls"], 1, 60)
    if not isinstance(state["max_calls"], int) or state["deadline_epoch"] != state["started_epoch"] + state["max_seconds"]:
        raise ValueError("Invalid research session budget")
    _number(state["calls_reserved"], 0, state["max_calls"])
    return state


def _view(state, now, allowed=None, reason=None):
    remaining = max(0, state["deadline_epoch"] - now)
    calls_left = state["max_calls"] - state["calls_reserved"]
    if allowed is None:
        allowed = state["status"] == "active" and remaining > 0 and calls_left > 0
    return {**state, "remaining_seconds": round(remaining, 3), "calls_remaining": calls_left,
            "elapsed_seconds": round(max(0, now - state["started_epoch"]), 3),
            "retrieval_allowed": allowed, "stop_reason": reason,
            "next_action": "retrieve_and_compare" if allowed else "finish_with_available_evidence"}


def start_session(topic, *, directory=None, max_seconds=360, max_calls=18, now=None):
    if not isinstance(topic, str) or not topic.strip() or len(topic) > 500:
        raise ValueError("Research requires a bounded topic")
    _number(max_seconds, 1, 3600)
    _number(max_calls, 1, 60)
    if not isinstance(max_calls, int):
        raise ValueError("Research calls must be an integer")
    now = time.time() if now is None else now
    state = {"schema_version": SCHEMA, "id": uuid.uuid4().hex, "topic": " ".join(topic.split()),
             "status": "active", "started_epoch": now, "deadline_epoch": now + max_seconds,
             "max_seconds": max_seconds, "max_calls": max_calls, "calls_reserved": 0}
    _write(state, directory)
    return _view(state, now)


def check_session(identifier, *, directory=None, reserve=0, now=None):
    if isinstance(reserve, bool) or not isinstance(reserve, int) or not 0 <= reserve <= 60:
        raise ValueError("Invalid research reservation")
    state = _read(identifier, directory)
    now = time.time() if now is None else now
    if state["status"] != "active":
        reason = "session_finished"
    elif now >= state["deadline_epoch"]:
        reason = "deadline_reached"
    elif max(1, reserve) > state["max_calls"] - state["calls_reserved"]:
        reason = "call_budget_exhausted"
    else:
        if reserve:
            state["calls_reserved"] += reserve
            _write(state, directory)
        return _view(state, now, allowed=True)
    return _view(state, now, allowed=False, reason=reason)


def finish_session(identifier, report_path, *, directory=None, now=None):
    state = _read(identifier, directory)
    report = Path(report_path).resolve()
    if not report.is_file() or report.stat().st_size > 2 * 1024 * 1024:
        raise ValueError("A saved bounded report is required")
    now = time.time() if now is None else now
    state.update(status="finished", finished_epoch=now, report_path=str(report),
                 report_sha256=hashlib.sha256(report.read_bytes()).hexdigest(),
                 verification_scope="local_file_saved; factual_verification_is_agent_responsibility")
    _write(state, directory)
    return _view(state, now, allowed=False, reason="session_finished")
