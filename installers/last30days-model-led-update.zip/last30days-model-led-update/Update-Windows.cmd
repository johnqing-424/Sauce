@echo off
setlocal
cd /d "%~dp0"
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
if not errorlevel 1 goto use_py
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
if not errorlevel 1 goto use_python
if exist "%ProgramFiles%\Python312\python.exe" goto use_known_python
where uv >nul 2>&1
if errorlevel 1 goto no_python
for /f "delims=" %%P in ('uv python find --offline --no-python-downloads 3.12 2^>nul') do set "TASK_MODEL_PYTHON=%%P"
if not defined TASK_MODEL_PYTHON goto no_python
"%TASK_MODEL_PYTHON%" -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
if not errorlevel 1 goto use_uv_python

:no_python
echo Python 3.12+ is required. No software will be downloaded.
pause
exit /b 1

:use_py
py -3 "%~dp0update_model_led.py"
goto finish

:use_python
python "%~dp0update_model_led.py"
goto finish

:use_known_python
"%ProgramFiles%\Python312\python.exe" "%~dp0update_model_led.py"
goto finish

:use_uv_python
"%TASK_MODEL_PYTHON%" "%~dp0update_model_led.py"

:finish
set "MODEL_LED_UPDATE_EXIT=%errorlevel%"
if not "%MODEL_LED_UPDATE_EXIT%"=="0" goto failed
echo.
echo Update complete. Open a NEW local Codex conversation and use $last30days.
echo Existing source tools, network configuration and database were preserved.
pause
exit /b 0

:failed
echo Update failed. Keep this window open and show the result to Codex.
pause
exit /b %MODEL_LED_UPDATE_EXIT%
