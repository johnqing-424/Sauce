# Windows 本机安装

## 普通入口也由 Codex 模型主导

普通 `$last30days AI圈的热点` 现在优先使用 Codex 可用的原生检索、网页读取
和连接器，由模型选择方向和判断价值；不会为了开始研究先安装 Go、编译来源
工具或修复浏览器接口。明确的配置、诊断和原命令仍可单独使用。
默认检索预算为 6 分钟、18 次查询/读取，之后基于已有证据交付；这是 Agent
检查点，不是对 Codex 总响应时长的强制中断器。

本次小更新仅更新 Skill 根说明、新研究参考和两项时间账本文件，保留现有
检索实现、已安装工具、Cookie 连接修复、代理配置和数据库。解压后双击
`Update-Windows.cmd`，成功后打开本机 Codex 新会话输入原来的自然语言请求。
更新器会校验兼容版本并备份旧文件；未知修改不会被覆盖。

## Codex 原生能力优先更新

新版 `last30days-intelligence-native-windows.zip` 的安装方式仍是完整解压后双击
`Install-Windows.cmd`。它会备份旧 Skill，保留已经可用的 Clash 私人配置和
数据库；不需要再运行旧的五文件联网修复包。

更新后在本机 Codex 新会话中输入：

```text
$last30days intelligence discover AI
```

新流程由 Codex 自动选择方向，优先调用已经可用的搜索、GitHub 连接和网页工具。
原 last30days 平台发现仍参与收集；Python 负责证据校验、溯源、数据库和简报。
用户无需手写 JSON，也无需为了启用已连接的 Codex 工具再提供搜索 API Key。
候选不足时会要求换查询或补搜，逐项深挖有效关联，并用内置命令生成中文报告。
个人主页和资料清单只作发现入口，文档分数不代表真正创新或实验正确性。

此包需在安装后打开一个新的本机会话，才能加载新的 Skill 流程。已有 Clash
配置和数据库会保留，旧五文件联网修复包不适用于本次代码。无原生检索工具的
定时 CLI 仍使用已有适配器；语义分析需要 Agent 运行环境。真实机器人发送和
本次 Windows 实机执行需另行验证，云端验证不能替代。

1. 下载并完整解压 `last30days-intelligence-windows.zip`。不要在压缩包内直接运行。
2. 双击 `Install-Windows.cmd`。需要 Python 3.12+；如果已经有 uv，安装器可以通过 uv 准备 Python。安装包附带官方 tzdata 的 IANA 时区数据，支持 Windows 上的北京时间日报和周报。
3. 安装窗口显示 `installed` 或 `already_installed` 后，在电脑上的 Codex 打开一个新的**本机**会话。
4. 输入：`$last30days intelligence trace https://github.com/mvanhorn/last30days-skill`。
5. 再输入：`$last30days intelligence discover robotics`，或直接描述你希望探索的领域。

Skill 安装位置是当前 Windows 用户的 `%USERPROFILE%\.agents\skills\last30days`。
安装器先检查文件校验和和 Python 语法，再复制文件；已有版本会保存在同目录的
`.last30days-backup-日期-随机值`。重复安装同一包不会再次备份。私人配置和数据库不在
Skill 目录中，安装器不会读写它们。

安装成功后，新会话应能选择或识别 `$last30days`。如果看不到，重新打开 Codex 并确保
使用本机执行环境。安装到本机不会让单独的云端会话自动获得这个 Skill。

此安装包不会启动后台任务或发送消息。先确认研究报告能正常生成，再配置自己的
Webhook、Telegram 或飞书接收端和操作系统定时任务。没有推送凭据时，真实发送尚未验证。

此版本从原开发会话保存的修改记录恢复；通知模块中无法取回的尾部按原接口重建，
验收结果以恢复后的重新测试为准，不能视为原提交 `34fc4bb` 的逐字节副本。
云端验证不能代替你的 Windows 实机安装验证。

## 已安装，但 GitHub 溯源提示地址不公开

如果你使用 Clash / Clash Verge / Mihomo，且错误中出现 `198.18.*`，这是
Fake-IP 与地址检查的兼容问题。保持 Clash 开启，下载专用的
`last30days-clash-repair.zip`，完整解压，双击 `Repair-Clash.cmd`。

修复器会备份支持版本的联网文件，检测本机 HTTP/mixed 代理端口。通过真实
GitHub HTTPS 验证后，它会保存 Skill 私有配置并自动再次溯源。看到
`external_trace_verified` 表示那台电脑实际取到了证据；模拟测试不能代替这个
结果。数据库和已有报告保留，不会发送通知或修改 Clash/Windows 代理设置。

如果显示 `No verified proxy`，打开 Clash 设置查看 HTTP/mixed 端口，然后把
窗口结果告诉本机 Codex。也可在终端执行 `Repair-Clash.cmd --proxy
http://127.0.0.1:实际端口`。如果提示版本不匹配，使用最新完整安装包；原副本
仍会备份。恢复方法与真实测试范围见修复 ZIP 的 `修复说明.md`。
