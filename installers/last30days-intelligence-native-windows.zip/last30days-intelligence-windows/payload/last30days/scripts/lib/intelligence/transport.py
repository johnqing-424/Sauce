"""Bounded, unauthenticated HTTPS reads from public destinations.

Each hop owns a subprocess deadline covering DNS, TLS and body reads. Normally
DNS answers and connections (including a proxy CONNECT) are checked and pinned.
In a managed environment that owns DNS, only exact, policy-allowlisted public
provider names can delegate address validation to the configured managed proxy.
An explicit loopback HTTP proxy can similarly resolve exact known providers on
an unmanaged host using Fake-IP DNS. That limitation is recorded. There is no
direct or insecure-TLS fallback.
"""

from __future__ import annotations

import base64
import http.client
import ipaddress
import json
import re
import socket
import ssl
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from functools import partial
from pathlib import Path
from urllib.parse import urljoin, urlsplit, urlunsplit

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from lib import subproc
from lib.intelligence.models import Budget


class SourceError(RuntimeError):
    """A secret-safe source failure, distinct from a valid empty result."""

    def __init__(self, kind: str, message: str, *, status: int | None = None, diagnostics: dict | None = None):
        self.kind = kind
        self.status = status
        self.message = message
        self.diagnostics = diagnostics or {}
        super().__init__(f"{kind}: {message}")

    def to_dict(self) -> dict:
        return {"kind": self.kind, "status": self.status, "message": self.message,
                **({"diagnostics": self.diagnostics} if self.diagnostics else {})}


@dataclass
class Response:
    url: str
    status: int
    headers: dict[str, str]
    body: bytes
    retrieval: dict = field(default_factory=dict)

    def __post_init__(self):
        self.headers = {str(key).lower(): str(value) for key, value in self.headers.items()}

    @property
    def content_type(self) -> str:
        return self.headers.get("content-type", "").split(";", 1)[0].strip().lower()

    def text(self) -> str:
        charset = re.search(r"charset\s*=\s*[\"']?([^;\s\"']+)", self.headers.get("content-type", ""), re.I)
        try:
            return self.body.decode(charset[1] if charset else "utf-8", errors="replace")
        except LookupError:
            return self.body.decode("utf-8", errors="replace")


def _public_address(address: str) -> bool:
    try:
        numeric = ipaddress.ip_address(address)
    except ValueError:
        return False
    return numeric.is_global and not (numeric.is_multicast or numeric.is_reserved or numeric.is_unspecified)


def canonical_public_url(url: str) -> str:
    """Perform non-I/O URL checks; DNS is additionally checked inside each worker."""
    if not isinstance(url, str) or not url or any(ord(char) <= 32 or ord(char) == 127 for char in url) or "\\" in url:
        raise SourceError("denied", "invalid public HTTPS URL")
    try:
        parts = urlsplit(url)
        if parts.scheme.lower() != "https" or not parts.hostname or parts.username is not None or parts.password is not None:
            raise ValueError
        if parts.port not in (None, 443):
            raise ValueError
        host = parts.hostname.rstrip(".").encode("idna").decode("ascii").lower()
        if not host or "%" in host:
            raise ValueError
    except (ValueError, UnicodeError):
        raise SourceError("denied", "expected public HTTPS on port 443 without credentials") from None
    try:
        numeric = ipaddress.ip_address(host)
    except ValueError:
        if ("." not in host or host == "localhost" or
                host.endswith((".localhost", ".local", ".internal", ".lan", ".home", ".invalid", ".test", ".onion")) or
                re.fullmatch(r"(?:0x[0-9a-f]+|\d+)(?:\.(?:0x[0-9a-f]+|\d+))*", host, re.I) or
                not all(re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label) for label in host.split("."))):
            raise SourceError("denied", "local, metadata or ambiguous hostname")
        authority = host
    else:
        if not _public_address(str(numeric)):
            raise SourceError("denied", "private or nonpublic address")
        authority = f"[{numeric}]" if numeric.version == 6 else str(numeric)
    return urlunsplit(("https", authority, parts.path or "/", parts.query, ""))


def validate_public_url(url: str, *, resolver=None) -> tuple[str, list[str]]:
    """Reject a hostname if any DNS answer is nonpublic; return pinned addresses."""
    canonical = canonical_public_url(url)
    host = urlsplit(canonical).hostname
    try:
        answers = (resolver or socket.getaddrinfo)(host, 443, type=socket.SOCK_STREAM)
    except OSError:
        raise SourceError("unavailable", "public hostname resolution failed") from None
    addresses = list(dict.fromkeys(answer[4][0] for answer in answers))
    if not addresses or any(not _public_address(address) for address in addresses):
        raise SourceError("denied", "DNS contains private or nonpublic addresses")
    # Prefer IPv4 where both are observed, without making an uncharged retry.
    addresses.sort(key=lambda address: ipaddress.ip_address(address).version)
    return canonical, addresses


def validate_local_proxy_url(value: str | None) -> str | None:
    """An explicit user setting may select an unauthenticated loopback HTTP proxy."""
    if value is None:
        return None
    try:
        parts = urlsplit(value)
        if (not isinstance(value, str) or any(ord(c) <= 32 for c in value)
                or parts.scheme != 'http' or parts.hostname not in {'127.0.0.1', '::1'}
                or parts.username is not None or parts.password is not None
                or parts.port is None or not 1 <= parts.port <= 65535
                or parts.path not in {'', '/'} or parts.query or parts.fragment):
            raise ValueError
    except (ValueError, TypeError, AttributeError):
        raise SourceError('configuration', 'local proxy requires loopback HTTP with an explicit port and no credentials') from None
    authority = f'[{parts.hostname}]' if parts.hostname == '::1' else parts.hostname
    return f'http://{authority}:{parts.port}'


_CONTENT_TYPES = frozenset({
    "text/html", "application/xhtml+xml", "application/json", "application/ld+json",
    "application/atom+xml", "application/rss+xml", "application/xml", "text/xml",
    "text/plain", "text/markdown", "text/x-markdown",
})
_REDIRECTS = frozenset({301, 302, 303, 307, 308})
_CLEANUP_GRACE = 0.05
_MANAGED_POLICY_PATH = Path("/etc/codex/network-policy.json")
_PUBLIC_PROVIDER_HOSTS = frozenset({
    "github.com", "www.github.com", "raw.githubusercontent.com", "api.github.com",
    "gitlab.com", "arxiv.org", "www.arxiv.org", "export.arxiv.org", "doi.org", "dx.doi.org",
    "api.crossref.org", "api.openalex.org",
})


def _local_proxy_route(url: str, value: str | None) -> str | None:
    proxy = validate_local_proxy_url(value)
    if proxy is None:
        return None
    if _MANAGED_POLICY_PATH.exists():
        raise SourceError('network_policy', 'local proxy cannot override a managed environment policy')
    host = urlsplit(canonical_public_url(url)).hostname
    # Fake-IP DNS is delegated only for exact, known public providers. Unknown
    # sites retain checked-and-pinned DNS, even with an explicit local proxy.
    return proxy if host in _PUBLIC_PROVIDER_HOSTS else None


def _managed_proxy_route(url: str) -> str | None:
    """Constrain delegated DNS to known public providers on a managed allowlist.

The supported startup snapshot supplies the proxy and exact host allowlist;
the sidecar enforces current policy. An arbitrary proxy or arbitrary website
cannot opt out of public DNS validation by setting an environment variable.
"""
    host = urlsplit(canonical_public_url(url)).hostname
    try:
        policy = json.loads(_MANAGED_POLICY_PATH.read_text(encoding="utf-8"))
        if type(policy.get("version")) is not int or policy["version"] != 1:
            return None
        network = policy.get("http_network_policy", {})
        configured = urlsplit(policy.get("http_proxy") or "")
        inherited_value = urllib.request.getproxies().get("https", "")
        inherited = urlsplit(inherited_value)
        if not inherited.hostname or not configured.hostname or (
            inherited.scheme, inherited.hostname, inherited.port
        ) != (configured.scheme, configured.hostname, configured.port):
            return None
        if network.get("type") != "restricted":
            return None
        allowed = {row.get("host", "").lower() for row in network.get("egress_rules", []) if isinstance(row, dict)}
    except (OSError, ValueError, TypeError, AttributeError):
        return None
    if host not in allowed:
        raise SourceError("network_policy", "destination is absent from the managed HTTP allowlist", status=403)
    if host not in _PUBLIC_PROVIDER_HOSTS:
        return None
    if urllib.request.proxy_bypass(host):
        raise SourceError("denied", "managed proxy route cannot use NO_PROXY or direct forwarding")
    return inherited_value


def _check_content(response: Response, max_bytes: int) -> None:
    if response.content_type not in _CONTENT_TYPES:
        raise SourceError("content_type", "unsupported or missing content type")
    if response.headers.get("content-encoding", "identity").lower() not in ("", "identity"):
        raise SourceError("content_encoding", "compressed response is unsupported")
    try:
        announced = int(response.headers.get("content-length", "0"))
    except ValueError:
        raise SourceError("content_length", "invalid content length") from None
    if announced < 0 or announced > max_bytes or len(response.body) > max_bytes:
        raise SourceError("size", "response exceeds byte limit")


def _http_failure(response: Response) -> SourceError:
    """Retain only typed quota hints, never arbitrary error bodies or headers."""
    details = {}
    for header, key in (("x-ratelimit-remaining", "rate_limit_remaining"),
                        ("x-ratelimit-reset", "rate_limit_reset_epoch"),
                        ("x-ratelimit-limit", "rate_limit"), ("retry-after", "retry_after_seconds")):
        value = response.headers.get(header, "")
        if re.fullmatch(r"[0-9]{1,12}", value):
            details[key] = int(value)
    resource = response.headers.get("x-ratelimit-resource")
    if resource in {"core", "search", "code_search", "graphql", "integration_manifest"}:
        details["rate_limit_resource"] = resource
    if urlsplit(response.url).hostname == "api.github.com":
        details.update(provider="github", request_authentication="anonymous")
    limited = response.status == 429 or (response.status == 403 and details.get("rate_limit_remaining") == 0)
    details["cause"] = "rate_limit_confirmed_by_response" if limited else (
        "authentication_required" if response.status == 401 else "access_denied_cause_unknown" if response.status == 403 else "http_error")
    details["next_action"] = "wait_or_use_authorized_host_tool" if limited else "use_authorized_host_tool_or_check_source_access"
    return SourceError("rate_limit" if limited else "http", f"HTTP {response.status}",
                       status=response.status, diagnostics=details)


class PublicTransport:
    """One charged operation per hop. Errors and rate limits are not retried."""

    def __init__(self, sender=None, *, max_redirects: int = 3, local_proxy_url: str | None = None):
        self.local_proxy_url = validate_local_proxy_url(local_proxy_url)
        self.sender = sender or partial(_worker_request, local_proxy_url=self.local_proxy_url)
        self.max_redirects = max_redirects

    def get(self, url: str, budget: Budget) -> Response:
        current = canonical_public_url(url)
        for hop in range(self.max_redirects + 1):
            timeout = budget.take()
            result = self.sender(current, timeout, budget.limits.max_bytes)
            if canonical_public_url(result.url) != current:
                raise SourceError("redirect", "transport performed an unvalidated redirect")
            if result.status in _REDIRECTS:
                if hop >= self.max_redirects:
                    raise SourceError("redirect", "redirect limit exceeded")
                location = result.headers.get("location")
                if not location:
                    raise SourceError("redirect", "redirect has no location")
                current = canonical_public_url(urljoin(current, location))
                continue
            if not 200 <= result.status < 300:
                raise _http_failure(result)
            _check_content(result, budget.limits.max_bytes)
            return result
        raise SourceError("redirect", "redirect limit exceeded")  # pragma: no cover


def _worker_request(url: str, timeout: float, max_bytes: int, *, local_proxy_url: str | None = None) -> Response:
    deadline = time.monotonic() + timeout
    worker_deadline = deadline - 2 * _CLEANUP_GRACE
    try:
        result = subproc.run_with_timeout(
            [sys.executable, "-I", str(Path(__file__).resolve())],
            timeout=max(0, worker_deadline - time.monotonic()),
            deadline_monotonic=worker_deadline,
            input_text=json.dumps({"url": url, "timeout": timeout, "max_bytes": max_bytes,
                                   **({'local_proxy_url': local_proxy_url} if local_proxy_url else {})}),
            cleanup_grace=_CLEANUP_GRACE,
            capture_limit_bytes=2 * max_bytes + 65536,
        )
    except subproc.SubprocTimeout:
        raise SourceError("timeout", "request exceeded operation deadline") from None
    except OSError:
        raise SourceError("unavailable", "public request worker could not start") from None
    if result.returncode != 0:
        raise SourceError("unavailable", "public request worker failed")
    try:
        record = json.loads(result.stdout)
        if "error" in record:
            failure = record["error"]
            raise SourceError(failure["kind"], failure["message"], status=failure.get("status"),
                              diagnostics=failure.get("diagnostics"))
        return Response(record["url"], record["status"], record["headers"], base64.b64decode(record["body"], validate=True), record.get("retrieval", {}))
    except (ValueError, KeyError, TypeError):
        raise SourceError("unavailable", "invalid public request worker response") from None


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _pinned_opener(url: str, addresses: list[str]):
    origin = urlsplit(url).hostname

    class PinnedConnection(http.client.HTTPSConnection):
        def connect(self):
            if self._tunnel_host:
                if self._tunnel_host.rstrip(".").lower() != origin:
                    raise SourceError("denied", "proxy tunnel changed destination")
                # Connect to the configured proxy; CONNECT goes to a checked IP.
                self.sock = self._create_connection((self.host, self.port), self.timeout, self.source_address)
                self._tunnel_host = addresses[0]
                self._tunnel()
            else:
                if self.host.rstrip(".").lower() != origin:
                    raise SourceError("denied", "connection changed destination")
                self.sock = self._create_connection((addresses[0], 443), self.timeout, self.source_address)
            self.sock = self._context.wrap_socket(self.sock, server_hostname=origin)

    class PinnedHandler(urllib.request.HTTPSHandler):
        def https_open(self, req):
            return self.do_open(PinnedConnection, req, context=self._context)

    # Default ProxyHandler honors HTTPS_PROXY/NO_PROXY. Default SSL context keeps
    # certificate verification and the configured CA trust intact.
    return urllib.request.build_opener(PinnedHandler(context=ssl.create_default_context()), _NoRedirect())


def _managed_opener(url: str, proxy: str, *, force_loopback: bool = False):
    origin = urlsplit(url).hostname
    if force_loopback:
        proxy = validate_local_proxy_url(proxy)
    proxy_parts = urlsplit(proxy)
    proxy_port = proxy_parts.port or (443 if proxy_parts.scheme == "https" else 80)

    class ManagedConnection(http.client.HTTPSConnection):
        def connect(self):
            if (self._tunnel_host != origin or self.host != proxy_parts.hostname or self.port != proxy_port):
                raise SourceError("denied", "managed public retrieval requires the configured proxy tunnel")
            super().connect()

    class ManagedHandler(urllib.request.HTTPSHandler):
        def https_open(self, req):
            return self.do_open(ManagedConnection, req, context=self._context)

    class ExplicitLoopbackProxyHandler(urllib.request.ProxyHandler):
        def proxy_open(self, req, configured_proxy, request_type):
            # This user-selected numeric-loopback route must not be skipped by
            # NO_PROXY or Windows proxy exceptions. Only local opt-in uses it.
            req.set_proxy(urlsplit(configured_proxy).netloc, 'http')
            return None

    proxy_handler = ExplicitLoopbackProxyHandler if force_loopback else urllib.request.ProxyHandler
    return urllib.request.build_opener(
        proxy_handler({"https": proxy}),
        ManagedHandler(context=ssl.create_default_context()), _NoRedirect(),
    )


def _request_once(url: str, timeout: float, max_bytes: int, *, local_proxy_url: str | None = None) -> Response:
    canonical = canonical_public_url(url)
    proxy = _managed_proxy_route(canonical)
    if proxy:
        opener = _managed_opener(canonical, proxy)
        retrieval = {"dns_validation": "delegated_to_managed_proxy", "local_address_verified": False,
                     "restriction": "exact allowlisted public provider; managed proxy owns resolution"}
    elif (proxy := _local_proxy_route(canonical, local_proxy_url)):
        opener = _managed_opener(canonical, proxy, force_loopback=True)
        retrieval = {'dns_validation': 'delegated_to_trusted_local_proxy', 'local_address_verified': False,
                     'restriction': 'explicit loopback proxy; exact known public providers; origin TLS verification retained'}
    else:
        canonical, addresses = validate_public_url(canonical)
        opener = _pinned_opener(canonical, addresses)
        retrieval = {"dns_validation": "validated_and_pinned", "local_address_verified": True}
    request = urllib.request.Request(canonical, headers={
        "User-Agent": "last30days-source-intelligence/1 (public research)",
        "Accept": "text/html,application/json,application/atom+xml,application/rss+xml,application/xml,text/plain",
        "Accept-Encoding": "identity",
    })
    try:
        connection = opener.open(request, timeout=timeout)
    except urllib.error.HTTPError as exc:
        connection = exc
    with connection:
        result = Response(canonical, connection.code, dict(connection.headers.items()), b"", retrieval)
        if 200 <= result.status < 300:
            _check_content(result, max_bytes)
            result.body = connection.read(max_bytes + 1)
            _check_content(result, max_bytes)
        return result


def _worker_main() -> None:
    try:
        payload = json.load(sys.stdin)
        result = _request_once(payload["url"], payload["timeout"], payload["max_bytes"],
                               local_proxy_url=payload.get('local_proxy_url'))
        record = {"url": result.url, "status": result.status, "headers": result.headers, "retrieval": result.retrieval,
                  "body": base64.b64encode(result.body).decode("ascii")}
    except SourceError as exc:
        record = {"error": exc.to_dict()}
    except (TimeoutError, socket.timeout):
        record = {"error": {"kind": "timeout", "message": "request exceeded operation deadline"}}
    except Exception:
        # Network exceptions can contain credentialed proxy URLs or headers.
        record = {"error": {"kind": "unavailable", "message": "public request failed"}}
    json.dump(record, sys.stdout)


if __name__ == "__main__":
    _worker_main()
