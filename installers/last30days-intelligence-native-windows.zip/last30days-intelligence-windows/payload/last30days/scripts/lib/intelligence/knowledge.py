"""Additive source graph and evidence history in the upstream research store."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from copy import deepcopy
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

import store

from .analysis import add_agent_analysis
from .models import Document, identity_url, normalize_url, utc_now


SCHEMA = """
CREATE TABLE IF NOT EXISTS intel_schema_version(version INTEGER PRIMARY KEY);
INSERT OR IGNORE INTO intel_schema_version VALUES(1);
CREATE TABLE IF NOT EXISTS intel_resources(
 url TEXT PRIMARY KEY, kind TEXT NOT NULL, primary_basis TEXT, content_hash TEXT NOT NULL,
 document_json TEXT NOT NULL, verified_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS intel_versions(
 url TEXT NOT NULL, content_hash TEXT NOT NULL, document_json TEXT NOT NULL, verified_at TEXT NOT NULL,
 PRIMARY KEY(url,content_hash));
CREATE TABLE IF NOT EXISTS intel_edges(
 from_url TEXT NOT NULL, to_url TEXT NOT NULL, relation TEXT NOT NULL, locator TEXT NOT NULL,
 state TEXT NOT NULL, verified_at TEXT NOT NULL, PRIMARY KEY(from_url,to_url,relation));
CREATE TABLE IF NOT EXISTS intel_sources(
 url TEXT PRIMARY KEY, kind TEXT NOT NULL, score REAL NOT NULL, authority_basis TEXT,
 verified_at TEXT NOT NULL, next_check REAL NOT NULL DEFAULT 0, enabled INTEGER NOT NULL DEFAULT 1,
 failures INTEGER NOT NULL DEFAULT 0, last_content_hash TEXT);
CREATE TABLE IF NOT EXISTS intel_source_domains(
 url TEXT NOT NULL REFERENCES intel_sources(url), domain TEXT NOT NULL, PRIMARY KEY(url,domain));
CREATE TABLE IF NOT EXISTS intel_events(
 id TEXT PRIMARY KEY, canonical_url TEXT NOT NULL, title TEXT NOT NULL, latest_revision TEXT NOT NULL,
 report_json TEXT NOT NULL, first_seen TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS intel_aliases(
 url TEXT PRIMARY KEY, event_id TEXT NOT NULL REFERENCES intel_events(id));
CREATE TABLE IF NOT EXISTS intel_revisions(
 event_id TEXT NOT NULL REFERENCES intel_events(id), revision TEXT NOT NULL,
 report_json TEXT NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY(event_id,revision));
CREATE TABLE IF NOT EXISTS intel_observations(
 event_id TEXT NOT NULL REFERENCES intel_events(id), observation_key TEXT NOT NULL,
 observation_json TEXT NOT NULL, first_seen TEXT NOT NULL, last_seen TEXT NOT NULL,
 seen_count INTEGER NOT NULL DEFAULT 1, PRIMARY KEY(event_id,observation_key));
CREATE TABLE IF NOT EXISTS intel_event_merges(
 merged_event_id TEXT PRIMARY KEY, event_id TEXT NOT NULL REFERENCES intel_events(id), merged_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS intel_runs(
 id INTEGER PRIMARY KEY, mode TEXT NOT NULL, domain TEXT, started_at TEXT NOT NULL,
 finished_at TEXT, status TEXT NOT NULL, result_json TEXT);
CREATE TABLE IF NOT EXISTS intel_watches(
 id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE, kind TEXT NOT NULL, target TEXT NOT NULL,
 interval_seconds REAL NOT NULL, next_run REAL NOT NULL DEFAULT 0, lease_until REAL NOT NULL DEFAULT 0,
 enabled INTEGER NOT NULL DEFAULT 1, failures INTEGER NOT NULL DEFAULT 0, last_status TEXT,
 config_json TEXT NOT NULL DEFAULT '{}');
CREATE INDEX IF NOT EXISTS intel_watches_due ON intel_watches(enabled,next_run,lease_until);
CREATE INDEX IF NOT EXISTS intel_sources_due ON intel_sources(enabled,next_check);
"""


def encode(payload) -> str:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, allow_nan=False)


class Knowledge:
    def __init__(self, path: str | Path | None = None):
        self.path = store.ensure_private_db_files(Path(path).expanduser() if path else store.DB_PATH)
        store.init_db(self.path)
        with self.connection() as conn:
            conn.executescript(SCHEMA)
        store.ensure_private_db_files(self.path)

    @contextmanager
    def connection(self):
        conn = store._connect(self.path)
        try:
            with conn:
                yield conn
        finally:
            conn.close()
            store.ensure_private_db_files(self.path)

    def save_document(self, document: Document, *, current: bool = True):
        url = normalize_url(document.url)
        payload = encode(document.to_dict())
        with self.connection() as conn:
            if current:
                conn.execute("INSERT INTO intel_resources VALUES(?,?,?,?,?,?) ON CONFLICT(url) DO UPDATE SET "
                             "kind=excluded.kind,primary_basis=excluded.primary_basis,content_hash=excluded.content_hash,"
                             "document_json=excluded.document_json,verified_at=excluded.verified_at",
                             (url, document.resource_type, document.primary_basis, document.content_hash, payload, document.verified_at))
            conn.execute("INSERT OR IGNORE INTO intel_versions VALUES(?,?,?,?)",
                         (url, document.content_hash, payload, document.verified_at))
            if current and (document.primary_basis or document.resource_type == "feed"):
                score = .85 if document.primary_basis else .55
                conn.execute("INSERT INTO intel_sources(url,kind,score,authority_basis,verified_at,last_content_hash) "
                             "VALUES(?,?,?,?,?,?) ON CONFLICT(url) DO UPDATE SET "
                             "verified_at=excluded.verified_at,last_content_hash=excluded.last_content_hash,failures=0",
                             (url, document.resource_type, score, document.primary_basis, document.verified_at, document.content_hash))

    def get_document(self, url: str, *, max_age_seconds: float | None = None) -> Document | None:
        with self.connection() as conn:
            row = conn.execute("SELECT document_json,verified_at FROM intel_resources WHERE url=?", (normalize_url(url),)).fetchone()
        if row is None:
            return None
        if max_age_seconds is not None:
            try:
                verified = datetime.fromisoformat(row["verified_at"].replace("Z", "+00:00"))
                age = (datetime.now(timezone.utc) - verified).total_seconds()
            except (ValueError, TypeError):
                return None
            if age < 0 or age > max_age_seconds:
                return None
        return Document.from_dict(json.loads(row["document_json"]))

    def save_edge(self, edge: dict):
        with self.connection() as conn:
            conn.execute("INSERT INTO intel_edges VALUES(?,?,?,?,?,?) ON CONFLICT(from_url,to_url,relation) "
                         "DO UPDATE SET locator=excluded.locator,state=excluded.state,verified_at=excluded.verified_at",
                         (edge["from_url"], edge["to_url"], edge["relation"], edge.get("locator", ""),
                          edge.get("state", "observed_link"), utc_now()))

    def find_event(self, urls: list[str]) -> dict | None:
        with self.connection() as conn:
            for url in urls:
                row = conn.execute("SELECT e.report_json FROM intel_aliases a JOIN intel_events e ON e.id=a.event_id "
                                   "WHERE a.url=?", (identity_url(url),)).fetchone()
                if row:
                    return json.loads(row[0])
        return None

    def get_event(self, event_id: str) -> dict | None:
        with self.connection() as conn:
            row = conn.execute("SELECT report_json FROM intel_events WHERE id=?", (event_id,)).fetchone()
            if not row:
                row = conn.execute("SELECT e.report_json FROM intel_event_merges m JOIN intel_events e ON e.id=m.event_id WHERE m.merged_event_id=?", (event_id,)).fetchone()
        return json.loads(row[0]) if row else None

    @staticmethod
    def _observe(conn, event_id: str, observation: dict, now: str):
        key_data = {"url": normalize_url(observation["url"]), "source": observation.get("source", "unknown")}
        key = hashlib.sha256(encode(key_data).encode()).hexdigest()
        conn.execute("INSERT INTO intel_observations VALUES(?,?,?,?,?,1) ON CONFLICT(event_id,observation_key) "
                     "DO UPDATE SET observation_json=excluded.observation_json,last_seen=excluded.last_seen,seen_count=seen_count+1",
                     (event_id, key, encode(observation), now, now))

    def record_observation(self, event_id: str, observation: dict):
        with self.connection() as conn:
            self._observe(conn, event_id, observation, utc_now())

    @staticmethod
    def _merge_event(conn, victim: str, winner: str, now: str):
        """Reconcile an unresolved observation with its now-established original.

        Keep every revision and observation, including a redirect from the old ID.
        Unresolved events cannot have qualified alert jobs, so no notification
        state is rewritten here.
        """
        for row in conn.execute("SELECT * FROM intel_revisions WHERE event_id=?", (victim,)).fetchall():
            history = json.loads(row["report_json"])
            history.update(id=winner, merged_from_event=victim)
            conn.execute("INSERT OR IGNORE INTO intel_revisions VALUES(?,?,?,?)", (winner, row["revision"], encode(history), row["created_at"]))
        conn.execute("INSERT INTO intel_observations SELECT ?,observation_key,observation_json,first_seen,last_seen,seen_count "
                     "FROM intel_observations WHERE event_id=? ON CONFLICT(event_id,observation_key) DO UPDATE SET "
                     "first_seen=min(first_seen,excluded.first_seen),last_seen=max(last_seen,excluded.last_seen),"
                     "seen_count=seen_count+excluded.seen_count", (winner, victim))
        conn.execute("UPDATE intel_aliases SET event_id=? WHERE event_id=?", (winner, victim))
        conn.execute("UPDATE intel_event_merges SET event_id=? WHERE event_id=?", (winner, victim))
        conn.execute("INSERT OR REPLACE INTO intel_event_merges VALUES(?,?,?)", (victim, winner, now))
        conn.execute("UPDATE intel_events SET first_seen=min(first_seen,(SELECT first_seen FROM intel_events WHERE id=?)) WHERE id=?", (victim, winner))
        conn.execute("DELETE FROM intel_observations WHERE event_id=?", (victim,))
        conn.execute("DELETE FROM intel_revisions WHERE event_id=?", (victim,))
        conn.execute("DELETE FROM intel_events WHERE id=?", (victim,))

    def _retain_assessment(self, report: dict, previous: dict) -> bool:
        """Keep a completed review only while its exact quotes remain available."""
        analysis = report.get("analysis", {})
        if analysis.get("status") == "evidence_linked_agent_review" and analysis.get("agent_assessment"):
            return True
        prior_analysis = previous.get("analysis", {})
        if prior_analysis.get("status") != "evidence_linked_agent_review" or not prior_analysis.get("agent_assessment"):
            return False
        # Validate on a separate analysis object: a rejected retained assessment
        # must not alter the fresh report or restore citations for different bytes.
        enriched = dict(report, analysis=deepcopy(analysis))
        try:
            payload = {"insights": analysis.get("agent_insights", []), "assessment": {
                key: {"text": item["text"], "evidence": item["evidence"]}
                for key, item in prior_analysis["agent_assessment"].items()
            }}
            documents = [Document.from_dict(item) for item in report.get("resources", [])]
            context = []
            for reference in prior_analysis.get("reference_documents", []):
                doc = self.get_document(reference["url"])
                if doc is None or doc.content_hash != reference["content_hash"]:
                    return False
                context.append(doc)
            documents.extend(context)
            add_agent_analysis(enriched, payload, documents)
            if context:
                enriched["analysis"]["reference_documents"] = [doc.to_dict() for doc in context]
        except (KeyError, TypeError, ValueError):
            return False
        report["analysis"] = enriched["analysis"]
        report["summary"] = enriched["summary"]
        return True

    def save_report(self, report: dict, aliases: list[str], observation: dict) -> dict:
        canonical = identity_url(report["canonical_url"])
        normalized = list(dict.fromkeys([canonical] + [identity_url(url) for url in aliases]))
        now = utc_now()
        with self.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            matches = {}
            for url in normalized:
                row = conn.execute("SELECT e.* FROM intel_aliases a JOIN intel_events e ON e.id=a.event_id WHERE a.url=?", (url,)).fetchone()
                if row:
                    matches.setdefault(row["id"], row)
            # The verified canonical artifact wins over an earlier unresolved
            # community alias. A different established project stays separate.
            existing = next((row for row in matches.values() if row["canonical_url"] == canonical), None)
            if existing is None:
                existing = next((row for row in matches.values() if json.loads(row["report_json"])["source_trace"]["origin_status"] == "unknown"), None)
            if existing:
                report["id"] = existing["id"]
                previous = json.loads(existing["report_json"])
                if not report.get("domain"):
                    report["domain"] = previous.get("domain", "")
                report["domains"] = list(dict.fromkeys(value for value in
                    previous.get("domains", [previous.get("domain", "")]) + [report.get("domain", "")] if value))
                change = "unchanged" if existing["latest_revision"] == report["revision"] else "updated"
            else:
                report["domains"] = [report["domain"]] if report.get("domain") else []
                change = "new"
            # Review is enrichment of a material revision, not a new discovery.
            # Older databases may have reviewed event data but a frozen placeholder
            # in revision history, so prefer the matching latest event first.
            prior_reports = []
            if existing and existing["latest_revision"] == report["revision"]:
                prior_reports.append(json.loads(existing["report_json"]))
            prior_revision = conn.execute(
                "SELECT report_json FROM intel_revisions WHERE event_id=? AND revision=?",
                (report["id"], report["revision"]),
            ).fetchone()
            if prior_revision:
                prior_reports.append(json.loads(prior_revision["report_json"]))
            for previous in prior_reports:
                if self._retain_assessment(report, previous):
                    break
            report["persistence"] = {"change": change, "database": str(self.path)}
            payload = encode(report)
            conn.execute("INSERT INTO intel_events VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET "
                         "canonical_url=excluded.canonical_url,title=excluded.title,report_json=excluded.report_json,"
                         "updated_at=CASE WHEN intel_events.latest_revision=excluded.latest_revision THEN intel_events.updated_at ELSE excluded.updated_at END,"
                         "latest_revision=excluded.latest_revision",
                         (report["id"], report["canonical_url"], report["title"], report["revision"], payload, now, now))
            conn.execute("INSERT INTO intel_revisions VALUES(?,?,?,?) ON CONFLICT(event_id,revision) "
                         "DO UPDATE SET report_json=excluded.report_json", (report["id"], report["revision"], payload, now))
            for other in matches.values():
                if other["id"] != report["id"] and json.loads(other["report_json"])["source_trace"]["origin_status"] == "unknown":
                    self._merge_event(conn, other["id"], report["id"], now)
            for url in normalized:
                # Never silently reassign an unrelated previously established event.
                conn.execute("INSERT OR IGNORE INTO intel_aliases VALUES(?,?)", (url, report["id"]))
            self._observe(conn, report["id"], observation, now)
        return report

    def reports(self, *, since: str | None = None, until: str | None = None) -> list[dict]:
        with self.connection() as conn:
            if since is None and until is None:
                rows = conn.execute("SELECT id AS event_id,report_json FROM intel_events ORDER BY updated_at DESC").fetchall()
            else:
                # Later updates must not erase earlier-period discoveries. One
                # latest material revision per event within the requested window.
                rows = conn.execute("SELECT event_id,report_json FROM intel_revisions WHERE "
                                    "(? IS NULL OR julianday(created_at)>=julianday(?)) "
                                    "AND (? IS NULL OR julianday(created_at)<julianday(?)) ORDER BY julianday(created_at) DESC,rowid DESC",
                                    (since, since, until, until)).fetchall()
        unique = {}
        for row in rows:
            unique.setdefault(row["event_id"], json.loads(row["report_json"]))
        return list(unique.values())

    def tag_source(self, url: str, domain: str):
        if domain:
            with self.connection() as conn:
                conn.execute("INSERT OR IGNORE INTO intel_source_domains SELECT url,? FROM intel_sources WHERE url=?",
                             (domain.casefold().strip(), normalize_url(url)))

    def sources(self, *, due_before: float | None = None, limit: int = 20, domain: str | None = None) -> list[dict]:
        with self.connection() as conn:
            if domain:
                rows = conn.execute("SELECT s.* FROM intel_sources s JOIN intel_source_domains d ON s.url=d.url "
                                    "WHERE d.domain=? AND s.enabled=1 ORDER BY s.score DESC,s.url LIMIT ?",
                                    (domain.casefold().strip(), limit)).fetchall()
            elif due_before is None:
                rows = conn.execute("SELECT * FROM intel_sources ORDER BY score DESC,url LIMIT ?", (limit,)).fetchall()
            else:
                rows = conn.execute("SELECT * FROM intel_sources WHERE enabled=1 AND next_check<=? "
                                    "ORDER BY next_check,score DESC LIMIT ?", (due_before, limit)).fetchall()
        return [dict(row) for row in rows]

    def mark_source_checked(self, url: str, *, interval_seconds: float = 86400, failed: bool = False):
        with self.connection() as conn:
            conn.execute("UPDATE intel_sources SET next_check=?,failures=CASE WHEN ? THEN failures+1 ELSE 0 END WHERE url=?",
                         (time.time() + interval_seconds, int(failed), normalize_url(url)))

    def start_run(self, mode: str, domain: str = "") -> int:
        with self.connection() as conn:
            cursor = conn.execute("INSERT INTO intel_runs(mode,domain,started_at,status) VALUES(?,?,?,'running')", (mode, domain, utc_now()))
            return cursor.lastrowid

    def finish_run(self, run_id: int, result: dict, status: str = "completed"):
        with self.connection() as conn:
            conn.execute("UPDATE intel_runs SET finished_at=?,status=?,result_json=? WHERE id=?", (utc_now(), status, encode(result), run_id))

    def add_watch(self, name: str, target: str, kind: str = "domain", *, interval_seconds: float = 3600, config: dict | None = None):
        if not name.strip() or not target.strip() or kind not in {"domain", "source"} or interval_seconds < 60:
            raise ValueError("watch requires a name, target, valid kind and interval >=60 seconds")
        with self.connection() as conn:
            conn.execute("INSERT INTO intel_watches(name,kind,target,interval_seconds,config_json) VALUES(?,?,?,?,?) "
                         "ON CONFLICT(name) DO UPDATE SET kind=excluded.kind,target=excluded.target,interval_seconds=excluded.interval_seconds,"
                         "config_json=excluded.config_json,enabled=1", (name, kind, target, interval_seconds, encode(config or {})))

    def watches(self) -> list[dict]:
        with self.connection() as conn:
            return [dict(row) for row in conn.execute("SELECT * FROM intel_watches ORDER BY id")]

    def claim_watch(self, *, now: float | None = None, lease_seconds: float = 600) -> dict | None:
        now = time.time() if now is None else now
        with self.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute("SELECT * FROM intel_watches WHERE enabled=1 AND next_run<=? AND lease_until<=? ORDER BY next_run,id LIMIT 1", (now, now)).fetchone()
            if row is None:
                return None
            conn.execute("UPDATE intel_watches SET lease_until=? WHERE id=?", (now + lease_seconds, row["id"]))
            result = dict(row)
            result["lease_until"] = now + lease_seconds
            result["claimed_at"] = now
            return result

    def finish_watch(self, watch: dict, status: str):
        with self.connection() as conn:
            conn.execute("UPDATE intel_watches SET lease_until=0,next_run=?,last_status=?,failures=CASE WHEN ?='failed' THEN failures+1 ELSE 0 END "
                         "WHERE id=? AND lease_until=?", (watch["claimed_at"] + watch["interval_seconds"], status, status, watch["id"], watch["lease_until"]))
