"""Discovery triage, trusted query data, and fair slices of one run budget.

Resource shapes decide what to inspect, never whether a breakthrough is true
or valuable. Semantic judgment belongs to the hosting agent after collection.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, replace
from pathlib import Path
from urllib.parse import urlsplit

from .models import BudgetExceeded, identity_url, normalize_url


PLAN_SCHEMA = "last30days-intelligence-plan/1"
MAX_PLAN_BYTES = 16_384
MAX_PLAN_QUERIES = 6
_COMMUNITY_SOURCES = frozenset({"reddit", "hackernews", "x", "xquik", "digg", "bluesky", "truthsocial",
                              "youtube", "tiktok", "instagram", "threads", "pinterest", "telegram", "linkedin"})
_COMMUNITY_HOSTS = frozenset({"reddit.com", "redd.it", "news.ycombinator.com", "x.com", "twitter.com",
                            "youtube.com", "youtu.be", "tiktok.com", "instagram.com", "bsky.app",
                            "threads.net", "threads.com", "pinterest.com", "t.me", "linkedin.com"})
_NAVIGATION_PATHS = frozenset({"about", "contact", "careers", "login", "search", "topics", "tags",
                             "categories", "archive", "archives", "explore", "settings", "marketplace",
                             "resources", "open-source"})


def _plan_text(value, field: str, max_chars: int) -> str:
    if not isinstance(value, str) or not value.strip() or len(value) > max_chars or any(
        not char.isprintable() for char in value
    ):
        raise ValueError(f"discovery plan {field} must be bounded printable text")
    return value.strip()


def validate_plan(payload: dict | None, domain: str) -> dict | None:
    """Accept query strings as data; no flags, URLs to execute, or instructions."""
    if payload is None:
        return None
    try:
        encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (TypeError, ValueError, RecursionError):
        raise ValueError("discovery plan must contain JSON data") from None
    if len(encoded) > MAX_PLAN_BYTES:
        raise ValueError("discovery plan exceeds the 16 KiB limit")
    if not isinstance(payload, dict) or set(payload) - {"schema_version", "domain", "queries"}:
        raise ValueError("discovery plan contains unknown fields")
    if payload.get("schema_version", PLAN_SCHEMA) != PLAN_SCHEMA:
        raise ValueError("unsupported discovery plan schema")
    bound_domain = " ".join(_plan_text(payload.get("domain"), "domain", 240).split())
    if bound_domain.casefold() != domain.casefold():
        raise ValueError("discovery plan domain does not match the request")
    queries = payload.get("queries")
    if not isinstance(queries, list) or not 1 <= len(queries) <= MAX_PLAN_QUERIES:
        raise ValueError("discovery plan requires 1 to 6 purposeful queries")
    validated, seen = [], set()
    for row in queries:
        if not isinstance(row, dict) or not {"query", "rationale"} <= set(row) or set(row) - {"query", "rationale", "providers"}:
            raise ValueError("discovery plan query requires query, rationale and optional providers")
        query = _plan_text(row["query"], "query", 240)
        rationale = _plan_text(row["rationale"], "rationale", 600)
        key = " ".join(query.casefold().split())
        if key in seen:
            raise ValueError("discovery plan queries must be distinct")
        seen.add(key)
        item = {"query": query, "rationale": rationale}
        if "providers" in row:
            providers = row["providers"]
            if not isinstance(providers, dict) or not providers or set(providers) - {"github", "arxiv", "web"}:
                raise ValueError("providers must contain only github, arxiv or web query data")
            item["providers"] = {key: _plan_text(value, key + " query", 480) for key, value in providers.items()}
        validated.append(item)
    return {"schema_version": PLAN_SCHEMA, "domain": domain, "queries": validated}


def load_plan(path: str, domain: str) -> dict:
    """Read a bounded local trusted file, never a shell command or remote URL."""
    with Path(path).expanduser().open("rb") as stream:
        data = stream.read(MAX_PLAN_BYTES + 1)
    if len(data) > MAX_PLAN_BYTES:
        raise ValueError("discovery plan exceeds the 16 KiB limit")
    try:
        payload = json.loads(data.decode("utf-8"))
    except (UnicodeError, ValueError, RecursionError):
        raise ValueError("discovery plan must be valid UTF-8 JSON") from None
    return validate_plan(payload, " ".join(domain.split()))


def research_handoff(domain: str, plan: dict | None, since: str, candidates: list,
                     queries: list, failures: list, *, native_search: bool) -> dict:
    """Give the hosting Agent an observable next step, never fake native results."""
    directions = plan["queries"] if plan else [{"query": domain, "rationale": "Explore recent original resources."}]
    eligible = [row for row in candidates if row["triage"]["kind"] != "source_entry"
                and row.get("source") != "historical_primary"]
    reasons = []
    if native_search:
        reasons.append("native_primary_search_pending")
    if len(eligible) < 12:
        reasons.append("small_candidate_pool")
    if any(row.get("candidate_count", 0) < 3 for row in queries):
        reasons.append("sparse_search_direction")
    if failures:
        reasons.append("primary_source_failures")
    handoff_queries = []
    for row in directions:
        providers = row.get("providers", {})
        handoff_queries.append({"query": row["query"], "rationale": row["rationale"], "since": since,
                                "providers": {"github": f"{providers.get('github', row['query'])} created:>={since} fork:false",
                                              "arxiv": providers.get("arxiv", row["query"]),
                                              "web": providers.get("web", row["query"])}})
    return {"required_action": "use_host_search" if native_search else "expand_search" if reasons else "review_candidates",
            "semantic_review": "required", "eligible_candidates": len(eligible), "target_candidate_pool": 12,
            "reasons": reasons, "queries": handoff_queries,
            "tool_policy": "Use available authorized host search, GitHub/MCP and page readers; native tool availability is host-resolved.",
            "ranking_basis": "Compare practical usefulness, evidence, prior approaches and limitations; document scores are not value ranking.",
            "budget_scope": "Host attempts and CLI operations share the Agent's total round ledger; CLI limits cover only that invocation."}


def _resource_triage(candidate: dict, domain: str) -> dict:
    parts = urlsplit(candidate["url"])
    host = (parts.hostname or "").lower().removeprefix("www.")
    segments = [part for part in parts.path.strip("/").split("/") if part]
    title = str(candidate.get("title") or "")
    text = " ".join([title, str(candidate.get("snippet") or "")]).casefold()
    personal_portfolio = bool(re.search(r"\b(?:my|personal) portfolio\b", text)) and not re.search(
        r"\bportfolio\s+(?:optimi[sz](?:ation|er)|management|allocation|risk|selection|simulation|analysis)\b", text
    )
    personal_profile = personal_portfolio or bool(re.search(
        r"\b(personal (?:website|site|homepage|profile)|about me|my (?:website|resume|résumé)|professional (?:resume|résumé))\b", text
    )) or title.strip().casefold() in {"resume", "résumé", "cv", "curriculum vitae"}
    reasons, entry_reason = [], None
    github = host == "github.com"
    if github and (len(segments) < 2 or segments[0].casefold() in _NAVIGATION_PATHS):
        entry_reason = "profile_or_navigation_page"
    elif github and (segments[1].casefold() == segments[0].casefold() or
                     segments[1].casefold().endswith(".github.io")):
        entry_reason = "profile_repository"
    elif personal_profile:
        entry_reason = "portfolio_or_profile"
    elif (github and re.search(r"(?:^|[-_])awesome(?:$|[-_])", segments[1], re.I)) or re.search(
        r"\b(awesome (?:list|links)|curated (?:list|links)|list of (?:links|resources)|collection of resources)\b", text
    ):
        entry_reason = "link_directory"
    elif (segments and segments[-1].casefold() in _NAVIGATION_PATHS) or (
        not segments and title.strip().casefold() in {"home", "homepage", "index", "profile"}
    ):
        entry_reason = "navigation_page"
    if entry_reason:
        return {"kind": "source_entry", "source_family": "source_entry", "priority": 0,
                "reasons": [entry_reason, "entry_point_not_a_specific_finding"],
                "semantic_status": "not_reviewed"}

    source = str(candidate.get("source") or "unknown").casefold()
    is_paper = host in {"arxiv.org", "export.arxiv.org", "doi.org", "dx.doi.org"}
    community_host = any(host == platform or host.endswith("." + platform) for platform in _COMMUNITY_HOSTS)
    community_original = source in _COMMUNITY_SOURCES and not community_host
    if community_original:
        kind, family, priority = "community_original", "community_original", 40
        reasons.append("community_original_link")
    elif is_paper:
        kind, family, priority = "paper", "paper", 35
        reasons.append("specific_paper_identifier")
    elif github:
        kind, family, priority = "repository", "repository", 25
        reasons.append("specific_repository")
    elif source == "historical_primary":
        kind, family, priority = "historical_primary", "historical_primary", 15
        reasons.append("previously_retrieved_primary_source")
    elif source in _COMMUNITY_SOURCES:
        kind, family, priority = "community", "community", 20
        reasons.append("community_observation_may_link_to_original_material")
    else:
        kind, family, priority = "resource", "web_resource", 20
        reasons.append("specific_resource_url" if segments else "publisher_entry_needs_semantic_review")
    if segments:
        reasons.append("specific_resource_path")
    domain_terms = set(re.findall(r"\w+", domain.casefold()))
    text_terms = set(re.findall(r"\w+", text))
    if domain_terms & text_terms:
        priority += 3
        reasons.append("domain_term_in_collected_text")
    reasons.append("popularity_not_used")
    return {"kind": kind, "source_family": family, "priority": priority, "reasons": reasons,
            "semantic_status": "not_reviewed"}


def _representative_key(candidate: dict, assessment: dict) -> tuple[int, int]:
    """Prefer an explicitly observed newer paper version within one identity.

    This preserves the exact input URL; it does not infer an unobserved version
    or claim the latest public version was independently checked.
    """
    parts = urlsplit(candidate["url"])
    version = 0
    if parts.hostname in {"arxiv.org", "www.arxiv.org", "export.arxiv.org"}:
        match = re.search(r"v([0-9]{1,6})(?:\.pdf)?$", parts.path)
        if match:
            version = int(match[1])
    return version, assessment["priority"]


def triage_candidates(candidates: list, domain: str, limit: int) -> tuple[list[dict], list[dict], list[dict], list[dict]]:
    """Deduplicate work identities while retaining all platform observations.

    One slot per available resource/source family is reserved before filling
    further slots. This protects community original links from repository-heavy
    collectors without assigning unverified scientific or practical value.
    """
    grouped, failures = {}, []
    for raw in candidates:
        if not isinstance(raw, dict) or not isinstance(raw.get("url"), str):
            failures.append({"source": "candidate_triage", "status": "invalid_resource_url"})
            continue
        try:
            url = normalize_url(raw["url"])
            identity = identity_url(url)
        except (ValueError, TypeError):
            failures.append({"source": "candidate_triage", "status": "invalid_resource_url"})
            continue
        candidate = {key: value for key, value in raw.items() if key not in {"candidate_id", "identity", "triage", "observations"}}
        candidate["url"] = url
        observations = raw.get("observations")
        if not isinstance(observations, list) or not observations:
            observations = [dict(candidate)]
        else:
            observations = [dict(row) for row in observations if isinstance(row, dict) and isinstance(row.get("url"), str)] or [dict(candidate)]
        assessment = _resource_triage(candidate, domain)
        if identity not in grouped:
            grouped[identity] = dict(candidate, candidate_id="candidate-" + hashlib.sha256(identity.encode()).hexdigest()[:16],
                                     identity=identity, triage=assessment, observations=observations)
        else:
            existing = grouped[identity]
            all_observations = existing["observations"] + observations
            if _representative_key(candidate, assessment) > _representative_key(existing, existing["triage"]):
                grouped[identity] = dict(candidate, candidate_id=existing["candidate_id"], identity=identity,
                                         triage=assessment, observations=all_observations)
            else:
                existing["observations"] = all_observations
    unique = list(grouped.values())
    eligible = sorted((row for row in unique if row["triage"]["kind"] != "source_entry"),
                      key=lambda row: (-row["triage"]["priority"], row["identity"]))
    chosen, families = [], set()
    for row in eligible:
        family = row["triage"]["source_family"]
        if family not in families and len(chosen) < limit:
            chosen.append(row)
            families.add(family)
    chosen_ids = {row["candidate_id"] for row in chosen}
    for row in eligible:
        if len(chosen) >= limit:
            break
        if row["candidate_id"] not in chosen_ids:
            chosen.append(row)
            chosen_ids.add(row["candidate_id"])
    selection = [{"candidate_id": row["candidate_id"], "url": row["url"],
                  "source_family": row["triage"]["source_family"], "reasons": list(row["triage"]["reasons"])} for row in chosen]
    deferred = [{"candidate_id": row["candidate_id"], "url": row["url"],
                 "reason": "source_entry_only" if row["triage"]["kind"] == "source_entry" else "report_limit",
                 "reasons": list(row["triage"]["reasons"])} for row in unique if row["candidate_id"] not in chosen_ids]
    return unique, selection, deferred, failures


class SharedBudgetSlice:
    """Duck-typed Runner budget whose every call/node also debits the parent.

    A slice expires at its own deadline and cannot consume calls or new nodes
    reserved for later roots. Unused capacity stays in the one global budget.
    """

    def __init__(self, parent, *, max_calls: int, max_nodes: int, max_seconds: float):
        self.parent = parent
        self.clock = parent.clock
        self.started = self.clock()
        self.call_allowance = max(0, max_calls)
        self.node_allowance = max(0, max_nodes)
        self.seconds_allowance = max(0.0, min(max_seconds, parent.remaining_seconds))
        self.limits = replace(parent.limits, max_calls=max(1, max_calls), max_nodes=max(1, max_nodes),
                              max_seconds=max(.001, self.seconds_allowance))
        self.calls, self.cost_usd, self.resource_nodes = 0, 0.0, set()

    @property
    def remaining_seconds(self) -> float:
        return max(0.0, min(self.parent.remaining_seconds, self.seconds_allowance - (self.clock() - self.started)))

    def take(self, cost_usd: float = 0) -> float:
        if self.remaining_seconds <= 0:
            raise BudgetExceeded("candidate time allocation exhausted")
        if self.calls >= self.call_allowance:
            raise BudgetExceeded("candidate call allocation exhausted")
        timeout = self.parent.take(cost_usd)
        self.calls += 1
        self.cost_usd += cost_usd
        return min(timeout, self.remaining_seconds)

    def visit(self, url: str):
        if url not in self.resource_nodes and len(self.resource_nodes) >= self.node_allowance:
            raise BudgetExceeded("candidate node allocation exhausted")
        self.parent.visit(url)
        self.resource_nodes.add(url)

    def snapshot(self) -> dict:
        return {"operations": self.calls, "resource_nodes": len(self.resource_nodes), "cost_usd": self.cost_usd,
                "elapsed_seconds": round(self.clock() - self.started, 3), "limits": asdict(self.limits),
                "allocation": {"max_calls": self.call_allowance, "max_nodes": self.node_allowance,
                               "max_seconds": self.seconds_allowance}, "shared_run": self.parent.snapshot()}


def fair_budget(parent, roots_remaining: int) -> SharedBudgetSlice:
    """Recompute an equal share from remaining capacity before each root."""
    return SharedBudgetSlice(parent, max_calls=max(0, parent.limits.max_calls - parent.calls) // roots_remaining,
                             max_nodes=max(0, parent.limits.max_nodes - len(parent.resource_nodes)) // roots_remaining,
                             max_seconds=parent.remaining_seconds / roots_remaining)
