"""Local, private, inspectable JSON and Markdown evidence reports."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path


def _text(value) -> str:
    return str(value or "unknown").replace("\x00", "").replace("\r", "")


def render_markdown(report: dict) -> str:
    score = report["score"]["total"]
    trace = report["source_trace"]
    lines = [f"# {_text(report['title'])}", "", f"Generated: {report['generated_at']}",
             f"Value proxy: {score}/100 · Delivery tier: {report['tier']}",
             f"Verification: {report['verification_status']}", "", "## Discovery", "", _text(report["summary"]),
             "", "## Three source roles", "", f"Origin status: {trace['origin_status']}"]
    earliest = trace.get("earliest_verifiable")
    lines.append(f"Earliest retrieved dated record: {earliest['url']} ({earliest['published_at']}); global earliest is unknown." if earliest else "Earliest dated record: unknown.")
    lines.extend(["Creator-direct records: " + (", ".join(trace.get("creator_direct", [])) or "unknown"),
                  "Underlying resources: " + (", ".join(trace.get("underlying_evidence", [])) or "unknown"),
                  "", "## Claims and facts", ""])
    for claim in report["claims"]:
        lines.append(f"- [{claim['status']}] {_text(claim['text'])}")
    lines.extend(["", "## Verifiable evidence", ""])
    for item in report["evidence"]:
        lines.extend([f"### {_text(item['resource_type'])}: {_text(item['author'])}", "", item["url"],
                      f"Published: {_text(item['published_at'])}; version: {_text(item['version'])}",
                      f"Retrieved: {item['verified_at']}; location: {item['locator']}; SHA256: {item['content_hash']}",
                      f"Status: {item['status']}; freshness: {item.get('freshness_status', 'retrieved')}", ""])
        lines.extend("> " + line for line in item["quote"].splitlines())
        for record in item.get("retrieval_records", []):
            if record.get("retrieval_method") == "host_tool_observation":
                lines.append(f"Host-reported retrieval: {_text(record.get('tool'))}; HTTP status unknown; CLI transport/DNS/TLS not independently verified.")
        lines.append("")
    lines.extend(["## Value and uncertainty", "", _text(report["analysis"]["why_it_matters"]),
                  _text(report["analysis"]["application_potential"]), ""])
    lines.extend("- " + _text(value) for value in report["analysis"]["uncertainty"])
    for insight in report["analysis"].get("agent_insights", []):
        lines.extend(["", f"AI inference (not fact): {_text(insight['text'])}"])
    assessment = report["analysis"].get("agent_assessment", {})
    if assessment:
        lines.extend(["", "## Evidence-linked Agent assessment", "", "AI interpretation; not independent verification."])
        for key, item in assessment.items():
            lines.extend(["", f"### {key.replace('_', ' ').capitalize()}", "", _text(item['text'])])
            for reference in item['evidence']:
                lines.extend(["", reference['url'], f"Location: {_text(reference.get('locator'))}; SHA256: {_text(reference.get('content_hash'))}"])
                lines.extend("> " + line for line in reference['quote'].splitlines())
    lines.extend(["", "## Observed relationship chain", ""])
    for edge in report["graph"]["edges"]:
        lines.append(f"- {edge['from_url']} → [{edge['relation']}] {edge['to_url']} ({edge.get('locator', 'unknown')}; target retrieved: {edge.get('target_verified', False)})")
    if report.get("failures"):
        lines.extend(["", "## Partial coverage", ""])
        lines.extend(f"- {item['url']}: {item['status']} ({item.get('reason', 'unknown')})" for item in report["failures"])
    lines.extend(["", "## Next directions", ""])
    if report['analysis'].get('next_steps'):
        lines.extend([_text(report['analysis']['next_steps']), ""])
    lines.extend(f"- {item['url']}: {item.get('relation', item.get('reason', 'linked resource'))}" for item in report.get("next_directions", []))
    return "\n".join(lines) + "\n"


def _atomic_write(path: Path, content: str):
    fd, staging = tempfile.mkstemp(prefix=".intel-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(staging, path)
    finally:
        Path(staging).unlink(missing_ok=True)


def save_research_brief(brief: dict, directory: str | Path) -> dict:
    """A compact Chinese research artifact; assessment quotes were checked at ingestion."""
    directory = Path(directory).expanduser().resolve()
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    path = directory / f"{brief['id']}-{brief['revision']}.json"
    brief.update(report_path=str(path), markdown_path=str(path.with_suffix(".md")))
    lines = [f"# {_text(brief['domain'])} 证据研究简报", "", f"生成时间：{brief['generated_at']}", "",
             "按 Agent 研究选择的顺序呈现。数值是文档证据代理，不是创新或实验正确性评分。", "",
             "以下分析不代表独立复现实验；已知限制和未确认事项应与发现一起阅读。", ""]
    labels = {"finding": "发现", "new": "有什么新东西", "why_it_matters": "为什么值得关注",
              "application_potential": "可能用途", "limitations": "限制与不确定性", "next_steps": "下一步验证"}
    if not brief["findings"]:
        lines.extend(["当前领域没有已保存的研究记录。", ""])
    for index, finding in enumerate(brief["findings"], 1):
        lines.extend([f"## {index}. {_text(finding['title'])}", "", finding["canonical_url"], "",
                      f"验证状态：{finding['verification_status']}；证据代理：{finding['score']['total']}/100；记录等级：{finding['tier']}。", ""])
        assessment = finding["analysis"].get("agent_assessment", {})
        if not assessment:
            lines.extend(["待 Agent 评审，不能作为高价值推荐。", ""])
        for key, label in labels.items():
            if key not in assessment:
                continue
            item = assessment[key]
            lines.extend([f"**{label}。** {_text(item['text'])}", ""])
            for reference in item["evidence"]:
                lines.extend([reference["url"], f"原文位置：{_text(reference.get('locator'))}"])
                lines.extend("> " + line for line in reference["quote"].splitlines())
                lines.append("")
        trace = finding["source_trace"]
        lines.extend(["原作者直接记录：" + (", ".join(trace.get("creator_direct", [])) or "未知"),
                      "底层材料：" + (", ".join(trace.get("underlying_evidence", [])) or "未知"),
                      "全球最早公开来源与实验独立验证状态：未由本简报确认。", ""])
        verified_edges = [edge for edge in finding["graph"]["edges"] if edge.get("target_verified")]
        if verified_edges:
            lines.extend(["已读取的关联材料：", ""])
            lines.extend(f"- {edge['from_url']} → {edge['to_url']}（{edge['relation']}）" for edge in verified_edges)
            lines.append("")
        if finding["failures"]:
            lines.extend(["部分读取未完成；详见完整报告中的失败记录。", ""])
        if finding.get("markdown_path"):
            report_path = finding["markdown_path"].replace("\\", "/")
            lines.extend([f"[完整溯源报告](<{report_path}>)", ""])
    _atomic_write(path, json.dumps(brief, ensure_ascii=False, indent=2, allow_nan=False))
    _atomic_write(path.with_suffix(".md"), "\n".join(lines) + "\n")
    return brief


def save_report(report: dict, directory: str | Path) -> dict:
    directory = Path(directory).expanduser().resolve()
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    path = directory / f"{report['id']}-{report['revision']}.json"
    report["report_path"] = str(path)
    report["markdown_path"] = str(path.with_suffix(".md"))
    _atomic_write(path, json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False))
    _atomic_write(path.with_suffix(".md"), render_markdown(report))
    return report
