"""Discover, preserve, monitor and deliver using the extension's shared state."""

from __future__ import annotations

import hashlib
import json
import time
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from . import delivery
from .analysis import AgentAnalysisError
from .discovery import SharedBudgetSlice, fair_budget, research_handoff, triage_candidates, validate_plan
from .engine import upstream_discover
from .knowledge import Knowledge
from .models import Budget, BudgetExceeded, Limits, identity_url, normalize_url, utc_now
from .reports import save_report, save_research_brief
from .runner import Runner


class IntelligenceService:
    def __init__(self, settings: dict, *, resolver=None, engine_fn=None):
        if resolver is None:
            from .sources import SourceResolver
            from .transport import PublicTransport
            resolver = SourceResolver(PublicTransport(local_proxy_url=settings.get('local_proxy_url')))
        self.settings = settings
        self.knowledge = Knowledge(settings["db"])
        self.resolver = resolver
        self.engine_fn = engine_fn or upstream_discover
        self.limits = Limits(**settings["limits"])
        self.runner = Runner(self.knowledge, resolver, self.limits, weights=settings["weights"],
                             threshold_a=settings["threshold_a"], threshold_b=settings["threshold_b"],
                             confidence_threshold=settings["confidence_threshold"], cache_seconds=settings["cache_seconds"])
        self.configs = delivery.load_channels()
        if settings["channels"]:
            self.configs = {key: value for key, value in self.configs.items() if key in settings["channels"]}
        with self.knowledge.connection() as conn:
            delivery.init_schema(conn)

    def _queue(self, report: dict, tier: str, *, period_key: str = "") -> int:
        if tier == "A" and not delivery.has_completed_agent_review(report):
            return 0
        with self.knowledge.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            queued = 0
            for name in self.configs:
                if tier in {"B", "C"} and conn.execute(
                    "SELECT 1 FROM intel_outbox WHERE channel=? AND tier=? AND period_key=? LIMIT 1",
                    (name, tier, period_key),
                ).fetchone():
                    continue
                queued += delivery.enqueue(conn, report, name, tier, period_key)
            return queued

    def deliver(self, *, send: bool = False) -> dict:
        with self.knowledge.connection() as conn:
            return delivery.flush(conn, self.configs, dry_run=not send,
                                  min_interval_seconds=self.settings["min_delivery_interval_seconds"])

    def trace(self, candidate: dict | str, *, refresh: bool = False, budget: Budget | None = None,
              domain: str = "", analysis: dict | None = None) -> dict:
        report = self.runner.trace(candidate, refresh=refresh, budget=budget, domain=domain, agent_analysis=analysis)
        save_report(report, self.settings["report_dir"])
        current_primary = any(
            resource["url"] in report["source_trace"]["creator_direct"]
            and resource["metadata"].get("freshness_status") != "historical_not_revalidated"
            and not resource["metadata"].get("retrieval_failures")
            for resource in report["resources"]
        )
        if report["tier"] == "A" and current_primary:
            self._queue(report, "A")
        return report

    def discover(self, domain: str, *, send: bool = False, seeds: dict | list | None = None,
                 collect_only: bool = False, plan: dict | None = None, native_search: bool = False,
                 analyses: dict | None = None) -> dict:
        domain = " ".join(domain.split())
        if not domain:
            raise ValueError("discover requires a nonempty domain")
        if collect_only and send:
            raise ValueError("collect-only cannot send notifications")
        if seeds is not None and plan is not None:
            raise ValueError("discovery plan cannot be combined with imported seeds")
        if native_search and (not collect_only or seeds is not None):
            raise ValueError("native-search requires collect-only without imported seeds")
        if seeds is None and getattr(self.resolver, "allow_fallback", True) is False:
            raise ValueError("host-only discovery requires selected seeds")
        if analyses is not None:
            if seeds is None or collect_only or not isinstance(analyses, dict) or not 1 <= len(analyses) <= self.settings["max_reports"]:
                raise ValueError("analyses require a bounded selected seed bundle, not collection-only")
            if len(json.dumps(analyses, ensure_ascii=False, allow_nan=False).encode()) > 262144:
                raise ValueError("analysis bundle exceeds 256 KiB")
            analyses = {identity_url(key): value for key, value in analyses.items()}
        plan = validate_plan(plan, domain)
        budget = Budget(self.limits)
        run_id = self.knowledge.start_run("discover", domain)
        upstream = {}
        failures, candidates, reports, collection_queries = [], [], [], []
        historical = self.knowledge.sources(domain=domain, limit=2)
        try:
            if seeds is None:
                try:
                    upstream = self.engine_fn(domain, budget, sources=self.settings["engine_sources"], lookback_days=self.settings["lookback_days"])
                except BudgetExceeded as exc:
                    failures.append({"source": "last30days", "status": "budget_exhausted", "reason": str(exc)})
                except Exception as exc:
                    failures.append({"source": "last30days", "status": "error", "reason": type(exc).__name__})
            else:
                upstream = _import_seeds(seeds)
            # Known creators are re-used as entry points. Leave room for new clues.
            for source in historical[:1] if seeds is None else []:
                candidates.append({"url": source["url"], "source": "historical_primary", "title": source["url"]})
            if seeds is None:
                queries = plan["queries"] if plan else [{"query": domain, "rationale": "Collect recent primary artifacts for the requested domain."}]
                since = (datetime.now(timezone.utc) - timedelta(days=self.settings["lookback_days"])).date().isoformat()
                # The resolver uses at most two API calls per query today. Reserve
                # at least half the remaining calls and most time for tracing;
                # collection-only has no trace work to reserve. Every query still
                # receives a slice of that one shared collection allowance.
                calls_left = max(0, self.limits.max_calls - budget.calls)
                collection_budget = SharedBudgetSlice(
                    budget, max_calls=min(len(queries) * 2, calls_left if collect_only else calls_left // 2),
                    max_nodes=self.limits.max_nodes,
                    max_seconds=budget.remaining_seconds * (1 if collect_only else .35),
                )
                for index, query in enumerate(queries):
                    if native_search:
                        collection_queries.append(dict(query, status="host_search_pending", candidate_count=0))
                        continue
                    query_budget = fair_budget(collection_budget, len(queries) - index)
                    query_record = dict(query, status="completed", candidate_count=0)
                    try:
                        discovered = self.resolver.discover(query["query"], query_budget, since,
                                                            limit=self.settings["max_reports"] * 2,
                                                            **({"provider_queries": query["providers"]} if "providers" in query else {}))
                        candidates.extend(dict(row, discovery_query=query["query"], discovery_rationale=query["rationale"])
                                          if isinstance(row, dict) else row for row in discovered)
                        query_record["candidate_count"] = len(discovered)
                        query_failures = list(getattr(self.resolver, "last_failures", []))
                        failures.extend(dict(failure, query=query["query"]) for failure in query_failures)
                        if query_failures:
                            query_record["status"] = "partial"
                    except BudgetExceeded as exc:
                        query_record["status"] = "budget_exhausted"
                        failures.append({"source": "primary_discovery", "query": query["query"],
                                         "status": "budget_exhausted", "reason": str(exc)})
                    except Exception as exc:
                        query_record["status"] = "error"
                        failures.append({"source": "primary_discovery", "query": query["query"],
                                         "status": "error", "reason": type(exc).__name__})
                    query_record["budget"] = query_budget.snapshot()
                    collection_queries.append(query_record)
            candidates.extend(upstream.get("candidates", []))
            candidates, selection, deferred, triage_failures = triage_candidates(candidates, domain, self.settings["max_reports"])
            failures.extend(triage_failures)
            candidates_by_id = {candidate["candidate_id"]: candidate for candidate in candidates}
            if analyses and set(analyses) - {candidates_by_id[row["candidate_id"]]["identity"] for row in selection}:
                raise ValueError("analysis bundle contains an unselected resource")
            if not collect_only:
                for index, selected in enumerate(selection):
                    candidate = candidates_by_id[selected["candidate_id"]]
                    try:
                        due = any(identity_url(item["url"]) == candidate["identity"] and item["next_check"] <= time.time()
                                  for item in historical)
                        report = self.trace(candidate, domain=domain, budget=fair_budget(budget, len(selection) - index), refresh=due,
                                            analysis=(analyses or {}).get(candidate["identity"]))
                        # Runner records the representative. Keep every other
                        # cross-platform observation on the same event identity.
                        representative_skipped = False
                        for observation in candidate["observations"]:
                            if not representative_skipped and observation.get("source") == candidate.get("source") and normalize_url(observation["url"]) == candidate["url"]:
                                representative_skipped = True
                                continue
                            self.knowledge.record_observation(report["id"], observation)
                        existing = next((item for item in reports if item["id"] == report["id"]), None)
                        if existing is None:
                            reports.append(report)
                        self.knowledge.mark_source_checked(candidate["url"], interval_seconds=self.settings["source_check_interval_seconds"], failed=bool(report["failures"]))
                        selected["trace_status"] = "partial" if report["failures"] or report["exploration"]["truncated"] else "completed"
                    except BudgetExceeded as exc:
                        selected["trace_status"] = "budget_exhausted"
                        failures.append({"source": candidate.get("source", "unknown"), "status": "budget_exhausted", "reason": str(exc)})
                    except AgentAnalysisError as exc:
                        selected["trace_status"] = "invalid_agent_analysis"
                        failures.append({"source": candidate.get("source", "unknown"), "status": "invalid_agent_analysis", "diagnostics": exc.diagnostics})
                    except ValueError:
                        selected["trace_status"] = "invalid_resource_url"
                        failures.append({"source": candidate.get("source", "unknown"), "status": "invalid_resource_url"})
                # A report-limit or entry-point decision does not erase already
                # known observations. New deferred clues remain in this run's
                # durable candidate collection for later agent-selected seeds.
                for row in deferred:
                    candidate = candidates_by_id[row["candidate_id"]]
                    known = self.knowledge.find_event([candidate["url"]])
                    if known:
                        for observation in candidate["observations"]:
                            self.knowledge.record_observation(known["id"], observation)
            outcomes = upstream.get("source_status", {})
            degraded = failures or any((value.get("state") if isinstance(value, dict) else value) not in {"ok", "no-results"} for value in outcomes.values())
            has_findings = bool(candidates) if collect_only else bool(reports)
            partial_trace = any(report["failures"] or report["exploration"]["truncated"] for report in reports)
            result = {"schema_version": "last30days-intelligence-run/1", "domain": domain,
                      "status": "partial" if degraded or partial_trace or native_search else "completed" if has_findings else "no-results",
                      "upstream": upstream, "source_failures": failures, "reports": reports,
                      "collect_only": collect_only, "candidates": candidates, "selection": selection, "deferred": deferred,
                      "selection_method": "resource_shapes_and_source_diversity; semantic_review_not_performed; popularity_not_used",
                      "discovery_plan": plan, "collection_queries": collection_queries,
                      "research_handoff": research_handoff(domain, plan,
                          (datetime.now(timezone.utc) - timedelta(days=self.settings["lookback_days"])).date().isoformat(),
                          candidates, collection_queries, failures, native_search=native_search) if collect_only else {
                              "required_action": "render_research_brief" if reports and all(r["analysis"].get("status") == "evidence_linked_agent_review" for r in reports) else "review_findings",
                              "semantic_review": "completed" if reports and all(r["analysis"].get("status") == "evidence_linked_agent_review" for r in reports) else "required"},
                      "historical_sources_used": min(1, len(historical)) if seeds is None else 0, "budget": budget.snapshot(),
                      "delivery": {"skipped": "collection_only", "sent": 0} if collect_only else self.deliver(send=send),
                      "real_send_requested": send, "generated_at": utc_now()}
            self.knowledge.finish_run(run_id, result, result["status"])
            return result
        except Exception as exc:
            self.knowledge.finish_run(run_id, {"error": type(exc).__name__, "budget": budget.snapshot()}, "failed")
            raise

    def run_watches(self, *, send: bool = False, max_jobs: int = 4) -> dict:
        executed = []
        for _ in range(max_jobs):
            watch = self.knowledge.claim_watch(lease_seconds=self.limits.max_seconds + 120)
            if not watch:
                break
            status = "failed"
            try:
                if watch["kind"] == "domain":
                    result = self.discover(watch["target"], send=send)
                    status = result["status"]
                    executed.append({"name": watch["name"], "result": result})
                else:
                    report = self.trace(watch["target"], refresh=True)
                    status = "completed" if not report["failures"] else "partial"
                    executed.append({"name": watch["name"], "report": report, "delivery": self.deliver(send=send)})
            except Exception as exc:
                executed.append({"name": watch["name"], "error": type(exc).__name__})
            finally:
                self.knowledge.finish_watch(watch, status)
        return {"executed": executed, "delivery": self.deliver(send=send), "generated_at": utc_now()}

    def research_brief(self, domain: str, *, event_ids: list[str] | None = None) -> dict:
        """Render stored current revisions in the Agent's chosen order, without IO to sources/channels."""
        domain = " ".join(domain.split())
        if not domain or len(domain) > 240:
            raise ValueError("research brief requires a bounded domain")
        tagged = {identity_url(row["url"]) for row in self.knowledge.sources(domain=domain, limit=100000)}
        reports = [row for row in self.knowledge.reports()
                   if domain.casefold() in {value.casefold() for value in row.get("domains", [row.get("domain", "")])}
                   or identity_url(row["canonical_url"]) in tagged]
        if event_ids is not None:
            if not isinstance(event_ids, list) or not 1 <= len(event_ids) <= 20 or any(not isinstance(value, str) for value in event_ids):
                raise ValueError("research brief requires 1–20 stored event IDs")
            by_id = {row["id"]: row for row in reports}
            if set(event_ids) - set(by_id):
                raise ValueError("research brief event is unknown or belongs to another domain")
            reports = [by_id[key] for key in dict.fromkeys(event_ids)]
        else:
            reports = reports[:self.settings["max_reports"]]
        findings = []
        for report in reports:
            save_report(report, self.settings["report_dir"])
            findings.append({key: report[key] for key in ("id", "revision", "title", "canonical_url", "tier", "score",
                                                         "verification_status", "source_trace", "failures", "graph",
                                                         "report_path", "markdown_path", "analysis") if key in report})
        revision = hashlib.sha256(json.dumps([(row["id"], row["revision"], row.get("analysis")) for row in findings],
                                            ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:24]
        result = {"schema_version": "last30days-research-brief/1", "domain": domain,
                  "id": "research-" + hashlib.sha256(domain.casefold().encode()).hexdigest()[:16],
                  "revision": revision, "generated_at": utc_now(), "findings": findings,
                  "ranking_basis": "Agent-selected order; proxy scores are not scientific or practical value ranking",
                  "delivery": {"sent": 0, "skipped": "local_research_brief"}}
        return save_research_brief(result, self.settings["report_dir"])

    def briefing(self, frequency: str, *, send: bool = False, now: datetime | None = None) -> dict:
        local = (now or datetime.now(timezone.utc)).astimezone(ZoneInfo(self.settings["timezone"]))
        midnight = local.replace(hour=0, minute=0, second=0, microsecond=0)
        if frequency == "daily":
            end = midnight
            start = end - timedelta(days=1)
            period = start.date().isoformat()
            tier = "B"
        elif frequency == "weekly":
            end = midnight - timedelta(days=local.weekday())
            start = end - timedelta(days=7)
            period = f"{start.isocalendar().year}-W{start.isocalendar().week:02d}"
            tier = "C"
        else:
            raise ValueError("briefing requires daily or weekly")
        reports = self.knowledge.reports(since=start.astimezone(timezone.utc).isoformat(), until=end.astimezone(timezone.utc).isoformat())
        reports = [report for report in reports if report["tier"] == "B" or (tier == "C" and report["tier"] == "A")]
        evidence = [item for report in reports for item in report["evidence"]]
        types = Counter(node["kind"] for report in reports for node in report["graph"]["nodes"])
        authors = Counter(node["author"] for report in reports for node in report["graph"]["nodes"] if node.get("author"))
        relations = Counter(edge["relation"] for report in reports for edge in report["graph"]["edges"])
        revision = hashlib.sha256(json.dumps(sorted((r["id"], r["revision"]) for r in reports)).encode()).hexdigest()[:24]
        report = {"schema_version": "last30days-intelligence/1", "id": f"briefing-{tier}-{period}", "revision": revision,
                  "observation_window": {"start": start.isoformat(), "end_exclusive": end.isoformat(), "timezone": self.settings["timezone"]},
                  "title": f"Source Intelligence {frequency} · {period}", "summary": "\n\n".join(f"{r['title']}: {r['summary'][:250]}" for r in reports) or "No qualified new observations in this period.",
                  "generated_at": utc_now(), "domain": ", ".join(sorted({r["domain"] for r in reports})),
                  "source_trace": {"creator_direct": list(dict.fromkeys(url for r in reports for url in r["source_trace"]["creator_direct"])),
                                   "underlying_evidence": list(dict.fromkeys(url for r in reports for url in r["source_trace"]["underlying_evidence"])), "earliest_verifiable": None, "origin_status": "see_individual_reports"},
                  "score": {"total": round(sum(r["score"]["total"] for r in reports) / len(reports), 2) if reports else 0}, "tier": tier,
                  "verification_status": "aggregated_local_observations; not an exhaustive industry trend", "evidence": evidence,
                  "claims": [claim for r in reports for claim in r["claims"]],
                  "analysis": {"status": "agent_review_required",
                               "new": "Newly recorded resources or material revisions in the local observation window.",
                               "why_it_matters": f"Observed {len(reports)} qualified events, {len(types)} resource types and {len(authors)} attributed authors.",
                               "application_potential": "Follow the linked primary resources for further evaluation.",
                               "uncertainty": ["Local sample coverage may be incomplete; counts do not establish a broader technical trend.", "Experimental claims remain unreplicated unless explicitly verified in an individual report."]},
                  "graph": {"nodes": [node for r in reports for node in r["graph"]["nodes"]], "edges": [edge for r in reports for edge in r["graph"]["edges"]]},
                  "failures": [], "next_directions": [item for r in reports for item in r["next_directions"]],
                  "trend_observations": {"resource_types": dict(types), "attributed_authors": dict(authors), "observed_relationships": dict(relations)},
                  "event_reports": [{"id": r["id"], "revision": r["revision"], "title": r["title"]} for r in reports]}
        save_report(report, self.settings["report_dir"])
        queued = self._queue(report, tier, period_key=period) if reports else 0
        return {"tier": tier, "period": period, "report": report, "queued": queued, "delivery": self.deliver(send=send)}


def _import_seeds(payload: dict | list) -> dict:
    if isinstance(payload, list):
        return {"candidates": payload, "source_status": {}, "imported_seed_bundle": True}
    if not isinstance(payload, dict):
        raise ValueError("seed input must be a source bundle or result array")
    if payload.get("mock") or payload.get("test_fixture"):
        raise ValueError("mock seed bundles cannot enter a real intelligence run")
    if "candidates" in payload:
        return dict(payload, imported_seed_bundle=True)
    if "results" in payload:
        candidates = [dict(row, snippet=row.get("summary", "")) for row in payload["results"] if isinstance(row, dict)]
        return {"candidates": candidates, "source_status": payload.get("source_status", {}), "imported_seed_bundle": True}
    if "items_by_source" in payload:
        candidates = [dict(item, source=source, snippet=item.get("snippet") or item.get("body", ""), raw_source_item=item)
                      for source, items in payload["items_by_source"].items() for item in items]
        return {"candidates": candidates, "source_status": payload.get("source_status", {}), "imported_seed_bundle": True}
    raise ValueError("unrecognized seed bundle")
