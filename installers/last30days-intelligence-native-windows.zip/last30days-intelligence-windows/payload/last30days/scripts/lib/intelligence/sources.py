"""Primary artifact adapters and conservative HTML/feed extraction.

All provider metadata comes from a retrieved response. A document's
``primary_basis`` describes control of the artifact, not scientific validation
or institutional identity. External text, including instructions, stays data.
"""

from __future__ import annotations

import base64
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from datetime import date, datetime
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
from urllib.parse import quote, urlencode, urljoin, urlsplit, urlunsplit

from .models import Budget, BudgetExceeded, Document, Link, utc_now
from .transport import PublicTransport, Response, SourceError, canonical_public_url


def _clean(value) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _date(value) -> str | None:
    value = _clean(value)
    if not value:
        return None
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00").replace("/", "-"))
        return value.replace("/", "-")
    except ValueError:
        try:
            return parsedate_to_datetime(value).isoformat()
        except (ValueError, TypeError, OverflowError):
            return None


def _json(response: Response) -> dict:
    try:
        value = json.loads(response.text())
    except (ValueError, TypeError):
        raise SourceError("metadata", "invalid JSON source metadata") from None
    if not isinstance(value, dict):
        raise SourceError("metadata", "expected a JSON metadata object")
    return value


def _observed_url(value: str, base: str = "") -> str:
    """Upgrade legacy links only for publishers with an explicit HTTPS endpoint."""
    resolved = urljoin(base, value)
    parts = urlsplit(resolved)
    if parts.scheme == "http" and parts.hostname in {"arxiv.org", "export.arxiv.org", "doi.org", "dx.doi.org"}:
        return urlunsplit(("https", parts.netloc, parts.path, parts.query, parts.fragment))
    return resolved


_GITHUB_SITE_ROUTES = frozenset({
    "about", "account", "apps", "collections", "contact", "customer-stories", "enterprise",
    "events", "explore", "features", "integrations", "issues", "login", "marketplace", "new",
    "notifications", "orgs", "organizations", "pricing", "pulls", "search", "security", "settings",
    "site", "solutions", "sponsors", "topics", "trending", "resources", "open-source", "signup", "join",
})


def _github_kind(url: str) -> str | None:
    parts = urlsplit(url)
    if parts.hostname not in {"github.com", "www.github.com"}:
        return None
    path = parts.path.strip("/").split("/")
    if not path[0] or path[0].lower() in _GITHUB_SITE_ROUTES:
        # Resource directories are navigation; an actual publisher article leaf
        # remains readable evidence when its article body is present.
        if len(path) > 2 and path[:2] in (["resources", "articles"], ["resources", "whitepapers"]):
            return "article"
        return "site_navigation"
    if len(path) == 1:
        return "author_profile"
    if len(path) == 2:
        if path[1].casefold().removesuffix(".git") == path[0].casefold():
            return "author_profile"
        return "website_repository" if path[1].lower().removesuffix(".git") == path[0].lower() + ".github.io" else "repository"
    if path[2] in {"blob", "tree", "wiki"}:
        return "documentation"
    if path[2] == "releases":
        return "release"
    return "discussion" if path[2] in {"issues", "discussions", "pull"} else "repository_page"


def _relation(url: str, label: str = "", default: str = "references") -> str:
    parts = urlsplit(url)
    if parts.hostname in {"github.com", "www.github.com"}:
        path = parts.path.strip("/").split("/")
        if not path[0] or path[0].lower() in _GITHUB_SITE_ROUTES:
            return "references"
        if len(path) == 1:
            return "author"
        if len(path) == 2:
            return "code"
        if path[2] in {"blob", "tree", "wiki"}:
            return "documentation"
        if path[2] == "releases":
            return "release"
        return "references"
    if parts.hostname in {"doi.org", "dx.doi.org"}:
        return "doi"
    if parts.path.endswith(".pdf") or (parts.hostname in {"arxiv.org", "export.arxiv.org"} and parts.path.startswith("/pdf/")):
        return "pdf"
    if parts.hostname in {"arxiv.org", "export.arxiv.org"} and parts.path.startswith(("/abs/", "/html/")):
        return "paper"
    if parts.hostname == "gitlab.com" and len(parts.path.strip("/").split("/")) >= 2:
        return "code"
    return default


def _link(value, base, relation="references", label="", locator="") -> Link | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        resolved = _observed_url(value.strip(), base)
        parts = urlsplit(resolved)
        if parts.scheme not in {"http", "https"} or not parts.hostname:
            return None
        if _github_kind(resolved) == "site_navigation" and relation not in {"canonical", "feed", "author", "organization"}:
            return None
    except ValueError:
        return None
    return Link(resolved, _relation(resolved, label, relation) if relation == "references" else relation, _clean(label), locator)


def _plain_links(text: str, base: str, locator: str) -> list[Link]:
    links = []
    for match in re.finditer(r"https?://[^\s<>\"'()\[\]{}]+", text):
        link = _link(match[0].rstrip(".,;!?"), base, locator=locator)
        if link:
            links.append(link)
    return links


def _failure(exc: Exception, source: str) -> dict:
    if isinstance(exc, SourceError):
        return {"source": source, **exc.to_dict()}
    if isinstance(exc, BudgetExceeded):
        return {"source": source, "kind": "budget_exceeded", "status": None, "message": str(exc)}
    return {"source": source, "kind": "metadata", "status": None, "message": "source metadata could not be read"}


def _navigation(tag: str, attrs: dict, *, in_content: bool) -> bool:
    role = (attrs.get("role") or "").lower()
    return tag in {"nav", "footer"} or role in {"navigation", "contentinfo"} or (
        not in_content and (tag == "header" or role == "banner")
    )


class _HTML(HTMLParser):
    _void = frozenset({"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"})

    def __init__(self, base: str):
        super().__init__(convert_charrefs=True)
        self.base = base
        self.meta: dict[str, list[str]] = {}
        self.links: list[Link] = []
        self.chunks: list[str] = []
        self.title: list[str] = []
        self.jsonld: list[dict] = []
        self._skip = 0
        self._title = False
        self._json = False
        self._script: list[str] = []
        self._anchor = None
        self._anchors = 0
        self._elements: list[str] = []
        self._content_starts: list[int] = []
        self._excluded: list[str] = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if self._excluded:
            if tag == self._excluded[-1]:
                self._excluded.append(tag)
            return
        if _navigation(tag, values, in_content=bool(self._content_starts)):
            self._excluded.append(tag)
            return
        if tag not in self._void:
            self._elements.append(tag)
            if tag == "article" or "markdown-body" in (values.get("class") or "").split():
                self._content_starts.append(len(self._elements) - 1)
        if tag in {"script", "style", "template"}:
            self._skip += 1
            self._json = tag == "script" and values.get("type", "").lower() == "application/ld+json"
            self._script = []
        elif self._skip:
            return
        elif tag == "title":
            self._title = True
        elif tag == "meta":
            key = (values.get("name") or values.get("property") or "").strip().lower()
            if key:
                self.meta.setdefault(key, []).append(values.get("content") or "")
        elif tag == "link":
            roles = set((values.get("rel") or "").lower().split())
            if not roles.intersection({"canonical", "alternate", "author"}) or roles.intersection({"stylesheet", "preload", "modulepreload", "icon", "apple-touch-icon", "mask-icon", "manifest", "preconnect", "dns-prefetch"}):
                return
            content_type = (values.get("type") or "").lower()
            relation = "canonical" if "canonical" in roles else "author" if "author" in roles else "references"
            if relation == "references" and content_type not in {"", "text/html", "application/xhtml+xml", "application/pdf", "application/rss+xml", "application/atom+xml", "application/xml", "text/xml"}:
                return
            if relation == "references" and ("rss" in content_type or "atom" in content_type):
                relation = "feed"
            link = _link(values.get("href"), self.base, relation, locator=f"html:line {self.getpos()[0]}, link/@href")
            if link:
                self.links.append(link)
        elif tag == "a":
            self._anchors += 1
            relation = "author" if "author" in (values.get("rel") or "").lower().split() else "references"
            self._anchor = (values.get("href"), [], f"html:line {self.getpos()[0]}, a[{self._anchors}]/@href", relation)
        if not self._skip and tag in {"p", "div", "article", "section", "h1", "h2", "h3", "li", "br", "tr"}:
            self.chunks.append("\n")

    def handle_endtag(self, tag):
        if self._excluded:
            if tag == self._excluded[-1]:
                self._excluded.pop()
            return
        for index in range(len(self._elements) - 1, -1, -1):
            if self._elements[index] == tag:
                del self._elements[index:]
                while self._content_starts and self._content_starts[-1] >= index:
                    self._content_starts.pop()
                break
        if tag in {"script", "style", "template"} and self._skip:
            if tag == "script" and self._json:
                try:
                    data = json.loads("".join(self._script))
                    for row in data if isinstance(data, list) else [data]:
                        if isinstance(row, dict):
                            self.jsonld.extend(row.get("@graph", [row]) if isinstance(row.get("@graph", [row]), list) else [row])
                except ValueError:
                    pass
            self._skip -= 1
            self._json = False
        elif self._skip:
            return
        elif tag == "title":
            self._title = False
        elif tag == "a" and self._anchor:
            href, label, locator, relation = self._anchor
            link = _link(href, self.base, relation, label="".join(label), locator=locator)
            if link:
                self.links.append(link)
            self._anchor = None
        if not self._skip and tag in {"p", "div", "article", "section", "h1", "h2", "h3", "li", "tr"}:
            self.chunks.append("\n")

    def handle_data(self, data):
        if self._excluded:
            return
        if self._skip:
            if self._json:
                self._script.append(data)
        elif self._title:
            self.title.append(data)
        else:
            self.chunks.append(data)
            if self._anchor:
                self._anchor[1].append(data)

    def first(self, *names):
        return next((_clean(value) for name in names for value in self.meta.get(name, []) if _clean(value)), "")

    @property
    def text(self):
        return "\n".join(line for line in (_clean(line) for line in "".join(self.chunks).splitlines()) if line)


def _author(value) -> str:
    if isinstance(value, list):
        return "; ".join(filter(None, (_author(item) for item in value)))
    if isinstance(value, dict):
        return _clean(value.get("name"))
    return _clean(value)


class _ReadmeHTML(HTMLParser):
    """Retain rendered Markdown or article markup without surrounding menus."""

    _void = frozenset({"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"})

    def __init__(self, *, mode="markdown"):
        super().__init__(convert_charrefs=False)
        self.mode = mode
        self.stack = []
        self.parts = []
        self._excluded = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if self._excluded:
            if tag == self._excluded[-1]:
                self._excluded.append(tag)
            return
        if _navigation(tag, values, in_content=bool(self.stack)):
            self._excluded.append(tag)
            return
        if not self.stack:
            classes = (values.get("class") or "").split()
            matches = tag == "article" if self.mode == "article" else tag in {"article", "div"} and "markdown-body" in classes
            if not matches:
                return
        self.parts.append(self.get_starttag_text())
        if tag not in self._void:
            self.stack.append(tag)

    def handle_endtag(self, tag):
        if self._excluded:
            if tag == self._excluded[-1]:
                self._excluded.pop()
            return
        if self.stack:
            self.parts.append(f"</{tag}>")
            if tag in self.stack:
                del self.stack[len(self.stack) - 1 - self.stack[::-1].index(tag):]

    def handle_data(self, data):
        if self.stack and not self._excluded:
            self.parts.append(data)

    def handle_entityref(self, name):
        if self.stack and not self._excluded:
            self.parts.append(f"&{name};")

    def handle_charref(self, name):
        if self.stack and not self._excluded:
            self.parts.append(f"&#{name};")


def _html(response: Response) -> Document:
    parser = _HTML(response.url)
    parser.feed(response.text())
    structured = next((row for row in parser.jsonld if isinstance(row, dict) and any(key in row for key in ("headline", "name", "author", "datePublished", "softwareVersion"))), {})
    authors = "; ".join(filter(None, (_clean(value) for value in parser.meta.get("citation_author", []))))
    authors = authors or parser.first("author", "article:author") or _author(structured.get("author"))
    declared_authors = structured.get("author", [])
    for declared_author in declared_authors if isinstance(declared_authors, list) else [declared_authors]:
        if isinstance(declared_author, dict):
            link = _link(declared_author.get("url"), response.url, "author", declared_author.get("name", ""), "html:jsonld/author/url")
            if link:
                parser.links.append(link)
    for key, value in structured.items():
        if key in {"url", "sameAs", "codeRepository", "citation"}:
            for target in value if isinstance(value, list) else [value]:
                if isinstance(target, dict):
                    target = target.get("url")
                link = _link(target, response.url, "code" if key == "codeRepository" else "references", locator=f"html:jsonld/{key}")
                if link:
                    parser.links.append(link)
    for key in ("citation_pdf_url", "citation_fulltext_html_url", "citation_abstract_html_url"):
        link = _link(parser.first(key), response.url, locator=f"html:meta[{key}]/@content")
        if link:
            parser.links.append(link)
    doi = parser.first("citation_doi")
    if doi:
        parser.links.append(Link("https://doi.org/" + quote(doi, safe="/"), "doi", doi, "html:meta[citation_doi]/@content"))
    kind = _github_kind(response.url)
    content_scope, resource_kind, discovery_role = "page_body", kind or "webpage", "background"
    declared = [link for link in parser.links if ", link/@href" in link.locator or link.locator.startswith(("html:meta[", "html:jsonld/"))]
    if kind == "site_navigation":
        parser.chunks, parser.links = [], declared
        content_scope, discovery_role = "metadata_only", "navigation"
    else:
        # GitHub profiles and repository pages need an actual rendered Markdown
        # block. Generic pages and publisher article leaves can use an article.
        content = _ReadmeHTML(mode="markdown" if kind and kind != "article" else "article")
        content.feed(response.text())
        if content.parts:
            focused = _HTML(response.url)
            focused.feed("".join(content.parts))
            parser.chunks, parser.links = focused.chunks, focused.links
            content_scope = {"repository": "repository_readme", "website_repository": "repository_readme", "author_profile": "profile_readme",
                             "documentation": "repository_documentation", "release": "release_notes", "discussion": "discussion_body"}.get(kind, "article")
            for link in focused.links:
                link.locator = link.locator.replace("html:", f"html:{content_scope.replace('_', '-')}/", 1)
            parser.links.extend(declared)
            if not kind:
                resource_kind = "article"
            discovery_role = "article" if resource_kind == "article" else "project"
        elif kind:
            parser.chunks, parser.links = [], declared
            content_scope, discovery_role = "metadata_only", "metadata_only"
        if kind == "author_profile":
            discovery_role = "author"
        elif kind == "website_repository":
            discovery_role = "background"
        elif kind == "documentation" and content_scope != "metadata_only":
            discovery_role = "documentation"
    return Document(
        url=response.url, title=parser.first("citation_title", "og:title", "twitter:title") or _clean(structured.get("headline") or structured.get("name")) or _clean("".join(parser.title)),
        text=parser.text, author=authors or None,
        published_at=_date(parser.first("citation_publication_date", "citation_date", "article:published_time", "date", "datepublished") or structured.get("datePublished")),
        version=parser.first("citation_version") or _clean(structured.get("softwareVersion")) or None,
        links=parser.links, metadata={"adapter": "html", "identity_verified": False,
                                      "author_basis": "author claim in retrieved metadata" if authors else None,
                                      "html_meta": parser.meta, "content_scope": content_scope,
                                      "resource_kind": resource_kind, "discovery_role": discovery_role},
    )


def _xml(response: Response):
    text = response.text()
    if re.search(r"<!\s*(?:DOCTYPE|ENTITY)\b", text, re.I):
        raise SourceError("metadata", "XML declarations and entities are unsupported")
    try:
        return ET.fromstring(text)
    except ET.ParseError:
        raise SourceError("metadata", "invalid XML source metadata") from None


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _child(node, name):
    return next((child for child in node if _local(child.tag) == name), None)


def _value(node, name):
    child = _child(node, name)
    return _clean("".join(child.itertext())) if child is not None else ""


def _entry(node, index: int, base: str, *, atom: bool) -> dict:
    prefix = f"{'atom' if atom else 'rss'}:entry[{index}]"
    links = []
    observed = {}
    for link_index, child in enumerate(node, 1):
        if _local(child.tag) == "link":
            raw = child.attrib.get("href") if atom else _clean(child.text)
            relation = "pdf" if child.attrib.get("type") == "application/pdf" else "references"
            link = _link(raw, base, relation, child.attrib.get("title", ""), f"{prefix}/link[{link_index}]" + ("/@href" if atom else "/text()"))
            if link:
                links.append(link)
                if raw != link.url:
                    observed[link.url] = raw
        elif _local(child.tag) == "doi" and _clean(child.text):
            doi = _clean(child.text)
            links.append(Link("https://doi.org/" + quote(doi, safe="/"), "doi", doi, f"{prefix}/doi/text()"))
    entry_id = _value(node, "id" if atom else "guid")
    alternate = next((child.attrib.get("href") for child in node if _local(child.tag) == "link" and child.attrib.get("rel", "alternate") == "alternate" and child.attrib.get("type", "text/html") == "text/html"), None) if atom else _value(node, "link")
    raw_url = alternate or entry_id
    url = _observed_url(raw_url, base) if raw_url else ""
    if raw_url and raw_url != url:
        observed[url] = raw_url
    author = "; ".join(filter(None, (_value(child, "name") for child in node if _local(child.tag) == "author"))) if atom else _value(node, "creator") or _value(node, "author")
    source = _child(node, "source")
    feed_source = None
    if source is not None:
        source_link = _child(source, "link")
        feed_source = {"title": _value(source, "title") if atom else _clean(source.text),
                       "url": source_link.attrib.get("href", "") if source_link is not None else source.attrib.get("url", "")}
    summary = _value(node, "summary" if atom else "description") or _value(node, "content") or _value(node, "encoded")
    if "<" in summary:
        clean = _HTML(base)
        clean.feed(summary)
        summary = clean.text
        links.extend(clean.links)
    links.extend(_plain_links(summary, base, prefix + ("/summary/text()" if atom else "/description/text()")))
    comment = _value(node, "comment")
    links.extend(_plain_links(comment, base, prefix + "/comment/text()"))
    return {"url": url, "title": _value(node, "title"), "snippet": summary, "author": author or None,
            "published_at": _date(_value(node, "published" if atom else "pubDate") or ("" if atom else _value(node, "date"))),
            "updated_at": _date(_value(node, "updated")), "id": entry_id, "links": links,
            "feed_source": feed_source, "observed_urls": observed, "comment": comment, "locator": prefix}


def _feed(response: Response) -> Document:
    root = _xml(response)
    atom = _local(root.tag) == "feed"
    channel = root if atom else _child(root, "channel")
    if channel is None or (not atom and _local(root.tag) != "rss"):
        raise SourceError("metadata", "unsupported XML feed format")
    entries = [_entry(child, index, response.url, atom=atom) for index, child in enumerate((node for node in channel if _local(node.tag) == ("entry" if atom else "item")), 1)]
    title = _value(channel, "title")
    lines = [title]
    links = []
    for row in entries:
        lines.extend(filter(None, [row["title"], row["snippet"], "Author: " + row["author"] if row["author"] else "",
                                   "Published: " + row["published_at"] if row["published_at"] else "", "URL: " + row["url"] if row["url"] else ""]))
        links.extend(row["links"])
        if row["url"] and not any(link.url == row["url"] for link in row["links"]):
            links.append(Link(row["url"], "references", row["title"], row["locator"] + "/id"))
    records = [{key: value for key, value in row.items() if key != "links"} for row in entries]
    return Document(response.url, title=title, text="\n".join(lines), resource_type="feed", links=links,
                    metadata={"adapter": "atom" if atom else "rss", "entries": records, "identity_verified": False})


class SourceResolver:
    def __init__(self, transport=None):
        self.transport = transport or PublicTransport()
        self.last_failures: list[dict] = []
        self.last_retrieval_observations: list[dict] = []
        self.last_retrieval_records: list[dict] = []
        self.adapters = {"github.com": self._github, "www.github.com": self._github,
                         "arxiv.org": self._arxiv, "www.arxiv.org": self._arxiv, "export.arxiv.org": self._arxiv}

    def fetch(self, url: str, budget: Budget) -> Document:
        canonical = canonical_public_url(url)
        self.last_retrieval_observations = []
        self.last_retrieval_records = []
        adapter = self.adapters.get(urlsplit(canonical).hostname, self._generic)
        document = adapter(canonical, budget)
        document.metadata["retrieval_observations"] = list(self.last_retrieval_observations)
        document.metadata["retrieval_records"] = list(self.last_retrieval_records)
        if document.url != canonical and not document.metadata.get("resolution_basis"):
            document.metadata["resolution_basis"] = "validated_http_redirect" if any(
                record["requested_url"] == canonical and record["response_url"] == document.url
                for record in self.last_retrieval_records
            ) else "adapter_returned_resource_url"
        return document

    def _get(self, url: str, budget: Budget) -> Response:
        response = self.transport.get(url, budget)
        self.last_retrieval_records.append({"requested_url": url, "response_url": response.url,
                                           "status": response.status, "content_type": response.content_type,
                                           "body_sha256": hashlib.sha256(response.body).hexdigest(), "retrieved_at": utc_now(),
                                           "etag": response.headers.get("etag"), "last_modified": response.headers.get("last-modified")})
        if response.retrieval:
            self.last_retrieval_observations.append({"url": response.url, **response.retrieval})
        return response

    def _generic(self, url: str, budget: Budget) -> Document:
        response = self._get(url, budget)
        if response.content_type in {"application/rss+xml", "application/atom+xml", "application/xml", "text/xml"}:
            return _feed(response)
        if response.content_type in {"text/plain", "text/markdown", "text/x-markdown"}:
            text = response.text()
            return Document(response.url, text=text, links=self._markdown_links(text, response.url, "text"), metadata={"adapter": "text", "identity_verified": False})
        if response.content_type in {"text/html", "application/xhtml+xml"}:
            return _html(response)
        raise SourceError("content_type", "source has no supported document adapter")

    @staticmethod
    def _markdown_links(text, base, path):
        links = []
        for line_number, line in enumerate(text.splitlines(), 1):
            locator = f"{path}:L{line_number}"
            observed = []
            for match in re.finditer(r"\[([^\]]*)\]\(\s*(?:<([^>]+)>|([^\s)]+))(?:\s+[^)]*)?\)", line):
                link = _link(match[2] or match[3], base, label=match[1], locator=locator)
                if link:
                    observed.append(link)
            definition = re.match(r"\s*\[([^\]]+)\]:\s*<?([^\s>]+)", line)
            if definition:
                link = _link(definition[2], base, label=definition[1], locator=locator)
                if link:
                    observed.append(link)
            for link in _plain_links(line, base, locator):
                if not any(existing.url == link.url for existing in observed):
                    observed.append(link)
            links.extend(observed)
        return links

    def _github(self, url: str, budget: Budget) -> Document:
        segments = urlsplit(url).path.strip("/").split("/")
        if len(segments) < 2 or segments[0].lower() in _GITHUB_SITE_ROUTES or not all(re.fullmatch(r"[\w.-]+", part) for part in segments[:2]) or (len(segments) > 2 and segments[2] not in {"releases"}):
            return self._generic(url, budget)
        owner, name = segments[:2]
        name = name[:-4] if name.lower().endswith(".git") else name
        api = "https://api.github.com/repos/" + quote(owner) + "/" + quote(name)
        try:
            repo = _json(self._get(api, budget))
        except SourceError as exc:
            if exc.kind == "denied":
                raise
            doc = self._generic(url, budget)
            if _github_kind(doc.url) not in {"repository", "website_repository", "release"}:
                # Classify the actual validated destination; metadata on another
                # site cannot establish GitHub repository ownership.
                doc.metadata.setdefault("retrieval_failures", []).append(_failure(exc, "github_api"))
                return doc
            observed = doc.metadata.get("html_meta", {}).get("octolytics-dimension-repository_nwo", [])
            if observed and observed[0].lower() == f"{owner}/{name}".lower():
                doc.author = observed[0].split("/", 1)[0]
                doc.metadata["author_basis"] = "repository owner declared in retrieved repository_nwo metadata"
            doc.resource_type = "repository"
            doc.metadata.update({"adapter": "github_html", "fork_status": "unknown", "retrieval_failures": [_failure(exc, "github_api")]})
            return doc
        observed_owner = repo.get("owner", {})
        author = _clean(observed_owner.get("login")) if isinstance(observed_owner, dict) else ""
        fork = repo.get("fork")
        mirror = repo.get("mirror_url")
        doc_url = canonical_public_url(repo.get("html_url") or url)
        observed_parts = urlsplit(doc_url)
        if observed_parts.hostname != "github.com" or not re.fullmatch(r"/[\w.-]+/[\w.-]+/?", observed_parts.path):
            raise SourceError("metadata", "GitHub metadata has no repository artifact URL")
        primary = "GitHub API records repository control by owner.login; no fork or mirror is reported" if author and fork is False and "mirror_url" in repo and mirror is None else None
        metadata = {"adapter": "github_api", "identity_verified": False, "fork": fork, "mirror_url": mirror,
                    "resolution_basis": "GitHub API /html_url",
                    "full_name": repo.get("full_name"), "requested_url": url, "created_at": _date(repo.get("created_at")),
                    "pushed_at": _date(repo.get("pushed_at")), "updated_at": _date(repo.get("updated_at")),
                    "date_basis": "repository_created_at", "retrieval_failures": [],
                    "resource_kind": _github_kind(doc_url), "content_scope": "repository_metadata", "discovery_role": "metadata_only"}
        links = []
        for field, relation in (("owner", "author"), ("organization", "organization")):
            observed = repo.get(field)
            target = observed.get("html_url") if isinstance(observed, dict) else None
            link = _link(target, doc_url, relation, locator=f"github-api:/{field}/html_url")
            if link:
                links.append(link)
        for field, relation in (("homepage", "homepage"), ("parent", "fork_of"), ("source", "upstream")):
            target = repo.get(field)
            target = target.get("html_url") if isinstance(target, dict) else target
            link = _link(target, doc_url, relation, locator=f"github-api:/{field}" + ("/html_url" if field != "homepage" else ""))
            if link:
                links.append(link)
        lines = list(filter(None, [_clean(repo.get("full_name")), _clean(repo.get("description")), "Owner: " + author if author else "",
                                   "Created: " + metadata["created_at"] if metadata["created_at"] else ""]))
        published = metadata["created_at"]
        version = None
        tag = "/".join(segments[4:]) if len(segments) >= 5 and segments[2:4] == ["releases", "tag"] else ""
        release_api = api + "/releases/" + ("tags/" + quote(tag, safe="") if tag else "latest")
        try:
            release = _json(self._get(release_api, budget))
            version = _clean(release.get("tag_name")) or None
            release_date = _date(release.get("published_at"))
            if release_date:
                published = release_date
                metadata["date_basis"] = "release_published_at"
            lines.extend(filter(None, ["Release: " + version if version else "", "Published: " + release_date if release_date else "", release.get("body")]))
            if _clean(release.get("body")):
                metadata.update({"content_scope": "release_notes", "discovery_role": "project"})
            link = _link(release.get("html_url"), doc_url, "release", locator="github-release:/html_url")
            if link:
                links.append(link)
            if tag:
                doc_url = canonical_public_url(release.get("html_url") or url)
        except (SourceError, BudgetExceeded) as exc:
            if isinstance(exc, SourceError) and exc.kind == "denied":
                raise
            if isinstance(exc, SourceError) and exc.status == 404 and not tag:
                # A new repository often has no published release. That optional
                # endpoint's absence must not freeze subsequent README updates.
                metadata["release_status"] = "no_latest_release"
            else:
                metadata["retrieval_failures"].append(_failure(exc, "github_release"))
        readme_api = api + "/readme" + ("?" + urlencode({"ref": version}) if tag and version else "")
        try:
            readme = _json(self._get(readme_api, budget))
            if readme.get("encoding") != "base64":
                raise SourceError("metadata", "unsupported README encoding")
            try:
                content = base64.b64decode(re.sub(r"\s+", "", readme.get("content", "")), validate=True).decode("utf-8", errors="replace")
            except (ValueError, TypeError):
                raise SourceError("metadata", "invalid README content") from None
            path = _clean(readme.get("path")) or "README"
            lines.extend(["README:", content])
            if content.strip():
                metadata.update({"content_scope": "repository_readme", "discovery_role": "background" if metadata["resource_kind"] in {"website_repository", "author_profile"} else "project"})
            metadata["readme_scope"] = version if tag and version else "current repository default branch"
            readme_url = readme.get("html_url") or doc_url
            link = _link(readme.get("html_url"), doc_url, "readme", locator="github-readme:/html_url")
            if link:
                links.append(link)
            links.extend(self._markdown_links(content, readme_url, path))
        except (SourceError, BudgetExceeded) as exc:
            if isinstance(exc, SourceError) and exc.kind == "denied":
                raise
            metadata["retrieval_failures"].append(_failure(exc, "github_readme"))
        if metadata["resource_kind"] in {"website_repository", "author_profile"}:
            metadata["discovery_role"] = "background"
        return Document(doc_url, title=_clean(repo.get("full_name")), text="\n".join(lines), resource_type="repository",
                        author=author or None, published_at=published, version=version, links=links, metadata=metadata, primary_basis=primary)

    def _arxiv(self, url: str, budget: Budget) -> Document:
        match = re.fullmatch(r"/(?:abs|pdf|html)/((?:\d{4}\.\d{4,5}|[a-z.-]+/\d{7})(?:v\d+)?)(?:\.pdf)?/?", urlsplit(url).path, re.I)
        if not match:
            return self._generic(url, budget)
        api = "https://export.arxiv.org/api/query?" + urlencode({"id_list": match[1]})
        try:
            response = self._get(api, budget)
            root = _xml(response)
            entry = _child(root, "entry")
            if entry is None:
                raise SourceError("metadata", "arXiv returned no paper entry")
            row = _entry(entry, 1, response.url, atom=True)
            doc_url = canonical_public_url(row["url"])
            if urlsplit(doc_url).hostname != "arxiv.org" or not urlsplit(doc_url).path.startswith("/abs/"):
                raise SourceError("metadata", "arXiv did not return a paper identifier")
            observed_id = urlsplit(doc_url).path.removeprefix("/abs/")
            if re.sub(r"v\d+$", "", observed_id) != re.sub(r"v\d+$", "", match[1]):
                raise SourceError("metadata", "arXiv returned metadata for a different paper")
            version = re.search(r"v\d+$", urlsplit(_observed_url(row["id"])).path)
            text = "\n".join(filter(None, [row["title"], "Authors: " + row["author"] if row["author"] else "",
                                          "Published: " + row["published_at"] if row["published_at"] else "", "Abstract:", row["snippet"], row["comment"]]))
            return Document(doc_url, title=row["title"], text=text, resource_type="paper", author=row["author"],
                            published_at=row["published_at"], version=version[0] if version else None, links=row["links"],
                            primary_basis="arXiv author-submitted paper record" if row["author"] else None,
                            metadata={"adapter": "arxiv_atom", "identity_verified": False, "updated_at": row["updated_at"],
                                      "resolution_basis": "arXiv Atom entry/id",
                                      "observed_urls": row["observed_urls"], "requested_url": url, "date_basis": "author_submission"})
        except SourceError as exc:
            if exc.kind == "denied":
                raise
            # Same policy-checked transport and proxy; no alternate network lane.
            page_url = "https://arxiv.org/abs/" + match[1]
            doc = self._generic(page_url, budget)
            doc.resource_type = "paper"
            doc.metadata.update({"adapter": "arxiv_html", "retrieval_failures": [_failure(exc, "arxiv_api")]})
            identifiers = doc.metadata.get("html_meta", {}).get("citation_arxiv_id", [])
            observed = _clean(identifiers[0]) if identifiers else ""
            if observed and re.sub(r"v\d+$", "", observed) != re.sub(r"v\d+$", "", match[1]):
                raise SourceError("metadata", "arXiv abstract metadata describes a different paper")
            version = re.search(r"v\d+$", observed)
            doc.version = version[0] if version else None
            if observed and doc.author:
                doc.primary_basis = "arXiv author-submitted paper metadata on the retrieved abstract page"
            return doc

    def discover(self, domain: str, budget: Budget, since: str, limit: int = 8, *, provider_queries: dict | None = None) -> list[dict]:
        start = date.fromisoformat(since)
        if not domain.strip() or not isinstance(limit, int) or isinstance(limit, bool) or limit < 1:
            raise ValueError("domain and positive candidate limit are required")
        self.last_failures = []
        self.last_retrieval_observations = []
        self.last_retrieval_records = []
        count = min(limit, budget.limits.max_nodes)
        normalized = domain.strip().lower()
        if normalized in {"ai", "人工智能", "artificial intelligence"}:
            github_query, arxiv_query = "topic:artificial-intelligence", "(cat:cs.AI OR cat:cs.LG)"
        elif normalized in {"机器人", "robotics", "robot"}:
            github_query, arxiv_query = "robotics", "cat:cs.RO"
        else:
            github_query, arxiv_query = domain.strip(), 'all:"' + domain.strip().replace('"', "") + '"'
        if provider_queries:
            github_query = provider_queries.get("github", github_query)
            arxiv_query = provider_queries.get("arxiv", arxiv_query)
        github_url = "https://api.github.com/search/repositories?" + urlencode({
            "q": f"{github_query} created:>={start.isoformat()} fork:false", "sort": "updated", "order": "desc", "per_page": count,
        })
        arxiv_url = "https://export.arxiv.org/api/query?" + urlencode({
            "search_query": f"{arxiv_query} AND submittedDate:[{start.strftime('%Y%m%d')}0000 TO 300001010000]",
            "start": 0, "max_results": count, "sortBy": "submittedDate", "sortOrder": "descending",
        })
        results = []
        try:
            payload = _json(self._get(github_url, budget))
            for row in payload.get("items", [])[:count]:
                if not isinstance(row, dict) or not row.get("html_url"):
                    continue
                try:
                    url = canonical_public_url(row["html_url"])
                except SourceError:
                    continue
                results.append({"url": url, "title": _clean(row.get("full_name")), "source": "github",
                                "snippet": _clean(row.get("description")), "author": _clean((row.get("owner") or {}).get("login")) or None,
                                "published_at": _date(row.get("created_at"))})
        except (SourceError, BudgetExceeded, TypeError, AttributeError) as exc:
            self.last_failures.append(_failure(exc, "github"))
        try:
            response = self._get(arxiv_url, budget)
            root = _xml(response)
            for index, entry in enumerate((child for child in root if _local(child.tag) == "entry"), 1):
                row = _entry(entry, index, response.url, atom=True)
                try:
                    url = canonical_public_url(row["url"])
                except SourceError:
                    continue
                if urlsplit(url).hostname != "arxiv.org" or not urlsplit(url).path.startswith("/abs/"):
                    continue
                results.append({"url": url, "title": row["title"], "source": "arxiv", "snippet": row["snippet"],
                                "author": row["author"], "published_at": row["published_at"]})
        except (SourceError, BudgetExceeded) as exc:
            self.last_failures.append(_failure(exc, "arxiv"))
        # Publication timestamps are provider metadata; missing dates sort last.
        results.sort(key=lambda row: row["published_at"] or "", reverse=True)
        seen = set()
        unique = []
        for row in results:
            if row["url"] not in seen:
                seen.add(row["url"])
                unique.append(row)
        return unique[:count]
