@echo off
setlocal
cd /d "%~dp0"
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
if not errorlevel 1 goto use_py
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
if not errorlevel 1 goto use_python
where uv >nul 2>&1
if not errorlevel 1 goto use_uv
echo Python 3.12+ is required. Keep this window open and show it to Codex.
pause
exit /b 1

:use_py
py -3 "%~dp0repair_clash.py" %*
goto finish

:use_python
python "%~dp0repair_clash.py" %*
goto finish

:use_uv
uv run --no-project --python 3.12 python "%~dp0repair_clash.py" %*

:finish
set INTEL_REPAIR_EXIT=%errorlevel%
echo.
if not "%INTEL_REPAIR_EXIT%"=="0" goto failed
echo Network repair and real trace completed. You can continue in local Codex.
echo Try: $last30days intelligence discover robotics
pause
exit /b 0

:failed
echo Repair or real trace is incomplete. Keep Clash running.
echo Keep this window open and show the result to Codex.
pause
exit /b %INTEL_REPAIR_EXIT%
