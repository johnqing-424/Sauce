"""Backed-up, version-checked Skill repair and an explicit Clash HTTP proxy probe.

Does not change Windows/Clash configuration, read cookies, or send notifications.
The actual HTTPS probe and trace run on the machine invoking this helper.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
import uuid
from datetime import datetime
from pathlib import Path


ALLOWED_FILES = frozenset({
    'scripts/lib/intelligence/transport.py',
    'scripts/lib/intelligence/configuration.py',
    'scripts/lib/intelligence/service.py',
    'intelligence.example.json', 'references/intelligence.md',
})
PROBE_URL = 'https://github.com/mvanhorn/last30days-skill'


def _proxy(value: str) -> str:
    match = re.fullmatch(r'http://(127\.0\.0\.1|\[::1\]):([1-9][0-9]{0,4})/?', value or '')
    if not match or int(match[2]) > 65535:
        raise ValueError('Use an unauthenticated numeric-loopback HTTP proxy with an explicit port')
    return f'http://{match[1]}:{int(match[2])}'


def _plain_file(path: Path, root: Path) -> bool:
    relative = path.relative_to(root)
    current = root
    for part in ('', *relative.parts):
        current = current / part
        if current.is_symlink() or (hasattr(current, 'is_junction') and current.is_junction()):
            return False
    return path.is_file()


def _stamp() -> str:
    return datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8]


def _atomic_write(path: Path, data: bytes) -> None:
    fd, name = tempfile.mkstemp(prefix='.intel-repair-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(name, 0o600)
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def update_skill(source: Path, installed: Path) -> dict:
    """Refuse custom versions and unsafe paths; roll back a partial replacement."""
    manifest = json.loads((source / 'manifest.json').read_text(encoding='utf-8'))
    files = manifest.get('files')
    required = {name for name in ALLOWED_FILES if name.endswith('.py')}
    if manifest.get('format') != 1 or not isinstance(files, dict) or not required.issubset(files) or set(files) - ALLOWED_FILES:
        raise ValueError('Invalid network repair manifest')
    pending = {}
    for name, hashes in files.items():
        packaged, target = source / name, installed / name
        if not _plain_file(packaged, source) or not _plain_file(target, installed):
            raise ValueError('Missing or linked Skill files; use the full installer')
        data = packaged.read_bytes()
        expected = hashes.get('after')
        if hashlib.sha256(data).hexdigest() != expected:
            raise ValueError('Corrupt network repair package')
        if name.endswith('.py'):
            compile(data, str(packaged), 'exec')
        original = target.read_bytes()
        digest = hashlib.sha256(original).hexdigest()
        if digest == expected:
            continue
        if digest != hashes.get('before'):
            raise ValueError('Skill has a different or customized version; use the full installer')
        pending[name] = (original, data)
    if not pending:
        return {'status': 'already_updated', 'backup': None}
    backup = installed.parent / ('.last30days-network-backup-' + _stamp())
    backup.mkdir()
    for name, (original, _) in pending.items():
        path = backup / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(original)
    changed = []
    try:
        for name, (_, data) in pending.items():
            _atomic_write(installed / name, data)
            changed.append(name)
    except BaseException:
        for name in reversed(changed):
            _atomic_write(installed / name, pending[name][0])
        raise
    return {'status': 'updated', 'backup': str(backup)}


def configure_proxy(profile: Path, proxy: str, *, probe=None) -> dict:
    """Keep other settings and a private backup; a failed probe cannot save opt-in."""
    proxy = _proxy(proxy)
    if profile.is_symlink() or (hasattr(profile, 'is_junction') and profile.is_junction()):
        raise ValueError('Configuration must be an ordinary private file')
    original = profile.read_bytes() if profile.exists() else None
    settings = json.loads(original.decode('utf-8')) if original is not None else {}
    if not isinstance(settings, dict):
        raise ValueError('Configuration must be an object')
    if (probe or probe_proxy)(proxy) is not True:
        raise ValueError('Proxy could not verify the real public GitHub resource')
    if settings.get('local_proxy_url') == proxy:
        return {'status': 'already_configured', 'backup': None}
    profile.parent.mkdir(parents=True, exist_ok=True)
    backup = None
    if original is not None:
        backup = profile.with_name('.intelligence-config-backup-' + _stamp() + '.json')
        backup.write_bytes(original)
        os.chmod(backup, 0o600)
    settings['local_proxy_url'] = proxy
    _atomic_write(profile, (json.dumps(settings, indent=2, ensure_ascii=False) + '\n').encode('utf-8'))
    return {'status': 'configured', 'backup': str(backup) if backup else None}


def proxy_candidates(registry_server: str = '') -> list[str]:
    """Read only loopback endpoint hints; never fetch Clash subscriptions/secrets."""
    candidates = []
    for part in registry_server.split(';'):
        endpoint = part.partition('=')[2] if '=' in part else part
        value = endpoint.strip()
        try:
            value = _proxy(value if value.startswith('http://') else 'http://' + value)
        except ValueError:
            continue
        if value not in candidates:
            candidates.append(value)
    for port in (7897, 7890):
        value = f'http://127.0.0.1:{port}'
        if value not in candidates:
            candidates.append(value)
    return candidates[:4]


def _windows_hint() -> str:
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r'Software\Microsoft\Windows\CurrentVersion\Internet Settings') as key:
            value, _ = winreg.QueryValueEx(key, 'ProxyServer')
            return value if isinstance(value, str) else ''
    except (ImportError, OSError):
        return ''


def probe_proxy(proxy: str) -> bool:
    from lib.intelligence.models import Budget, Limits
    from lib.intelligence.transport import PublicTransport
    response = PublicTransport(local_proxy_url=_proxy(proxy)).get(
        PROBE_URL, Budget(Limits(max_calls=3, max_nodes=1, max_seconds=15, request_timeout=5)),
    )
    return (200 <= response.status < 300
            and response.retrieval.get('dns_validation') == 'delegated_to_trusted_local_proxy'
            and response.content_type == 'text/html'
            and b'mvanhorn/last30days-skill' in response.body)


def main() -> int:
    parser = argparse.ArgumentParser(description='Repair this user\'s installed Skill for Clash Fake-IP')
    parser.add_argument('--payload', type=Path, default=Path(__file__).resolve().parent / 'payload')
    parser.add_argument('--skill-dir', type=Path, default=Path.home() / '.agents/skills/last30days')
    parser.add_argument('--config', type=Path)
    parser.add_argument('--proxy', help='Optional http://127.0.0.1:<Clash mixed/HTTP port>')
    args = parser.parse_args()
    if sys.version_info < (3, 12):
        raise RuntimeError('Python 3.12 or newer is required')
    print('Step 1/3: Verify, back up and update the installed Skill.', flush=True)
    print(json.dumps(update_skill(args.payload, args.skill_dir), ensure_ascii=True, indent=2))
    sys.path.insert(0, str(args.skill_dir / 'scripts'))
    from lib.intelligence.configuration import load_settings
    profile = args.config or Path(os.environ.get('LAST30DAYS_INTEL_CONFIG') or Path.home() / '.config/last30days/intelligence.json').expanduser()
    # Validate existing settings before attempting to persist the proxy choice.
    load_settings(str(profile if profile.exists() else args.skill_dir / 'intelligence.example.json'))
    candidates = [_proxy(args.proxy)] if args.proxy else proxy_candidates(_windows_hint())
    print('Step 2/3: Verify GitHub HTTPS through the local Clash proxy.', flush=True)
    configured = False
    for candidate in candidates:
        try:
            result = configure_proxy(profile, candidate)
        except Exception as exc:
            print('Local proxy candidate failed: ' + type(exc).__name__, flush=True)
            continue
        print(json.dumps(result, ensure_ascii=True, indent=2))
        configured = True
        break
    if not configured:
        print('No verified proxy. Keep Clash running; check its mixed/HTTP port and retry with --proxy.')
        return 2
    print('Step 3/3: Run a real bounded source trace; no messages will be sent.', flush=True)
    settings = load_settings(str(profile))
    for key, cap in {'max_depth': 1, 'max_calls': 12, 'max_nodes': 5, 'max_seconds': 60, 'request_timeout': 8}.items():
        settings['limits'][key] = min(settings['limits'][key], cap)
    from lib.intelligence.service import IntelligenceService
    report = IntelligenceService(settings).trace(PROBE_URL, refresh=True)
    current_resource = any(
        row['url'].rstrip('/') == PROBE_URL
        and row['metadata'].get('freshness_status') != 'historical_not_revalidated'
        for row in report['resources']
    )
    current_evidence = any(
        row['url'].rstrip('/') == PROBE_URL
        and row.get('freshness_status') != 'historical_not_revalidated'
        for row in report['evidence']
    )
    verified = current_resource and current_evidence
    print(json.dumps({'status': 'external_trace_verified' if verified else 'trace_incomplete',
                      'resources': len(report['resources']), 'evidence': len(report['evidence']),
                      'verification_status': report['verification_status'],
                      'reports': {'json': report['report_path'], 'markdown': report['markdown_path']},
                      'source_failures': report['failures']}, ensure_ascii=True, indent=2))
    return 0 if verified else 3


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        # Do not print exceptions that might contain private configuration values.
        print('Repair failed: ' + type(exc).__name__ + '. Keep this window open and show it to Codex.', file=sys.stderr)
        raise SystemExit(1)
