# Windows 本机安装

1. 下载并完整解压 `last30days-intelligence-windows.zip`。不要在压缩包内直接运行。
2. 双击 `Install-Windows.cmd`。需要 Python 3.12+；如果已经有 uv，安装器可以通过 uv 准备 Python。安装包附带官方 tzdata 的 IANA 时区数据，支持 Windows 上的北京时间日报和周报。
3. 安装窗口显示 `installed` 或 `already_installed` 后，在电脑上的 Codex 打开一个新的**本机**会话。
4. 输入：`$last30days intelligence trace https://github.com/mvanhorn/last30days-skill`。
5. 再输入：`$last30days intelligence discover robotics`，或直接描述你希望探索的领域。

Skill 安装位置是当前 Windows 用户的 `%USERPROFILE%\.agents\skills\last30days`。
安装器先检查文件校验和和 Python 语法，再复制文件；已有版本会保存在同目录的
`.last30days-backup-日期-随机值`。重复安装同一包不会再次备份。私人配置和数据库不在
Skill 目录中，安装器不会读写它们。

安装成功后，新会话应能选择或识别 `$last30days`。如果看不到，重新打开 Codex 并确保
使用本机执行环境。安装到本机不会让单独的云端会话自动获得这个 Skill。

此安装包不会启动后台任务或发送消息。先确认研究报告能正常生成，再配置自己的
Webhook、Telegram 或飞书接收端和操作系统定时任务。没有推送凭据时，真实发送尚未验证。

此版本从原开发会话保存的修改记录恢复；通知模块中无法取回的尾部按原接口重建，
验收结果以恢复后的重新测试为准，不能视为原提交 `34fc4bb` 的逐字节副本。
云端验证不能代替你的 Windows 实机安装验证。
