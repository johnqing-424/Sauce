@echo off
setlocal
cd /d "%~dp0"
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
if not errorlevel 1 goto use_py
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 12) else 1)" >nul 2>&1
if not errorlevel 1 goto use_python
where uv >nul 2>&1
if not errorlevel 1 goto use_uv
echo Python 3.12+ is required. No Skill was installed.
echo Open this extracted folder in a LOCAL Codex task and ask it to install Python,
echo then run install.py. You can also install Python from python.org.
pause
exit /b 1

:use_py
py -3 "%~dp0install.py"
goto finish

:use_python
python "%~dp0install.py"
goto finish

:use_uv
uv run --no-project --python 3.12 python "%~dp0install.py"

:finish
set INTEL_INSTALL_EXIT=%errorlevel%
if not "%INTEL_INSTALL_EXIT%"=="0" goto failed
echo.
echo Skill installed for this Windows user. Open a new local Codex conversation.
echo Try: $last30days intelligence trace https://github.com/mvanhorn/last30days-skill
pause
exit /b 0

:failed
echo.
echo Installation failed. Keep this window open and show the error to Codex.
pause
exit /b %INTEL_INSTALL_EXIT%
