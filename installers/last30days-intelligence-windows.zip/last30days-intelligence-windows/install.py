"""Install the bundled, verified Skill into the current user's Codex skills."""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import uuid
from datetime import datetime
from pathlib import Path, PurePosixPath


def validate(source: Path) -> dict[str, str]:
    manifest = json.loads((source.parent / 'manifest.json').read_text(encoding='utf-8'))
    files = manifest.get('files')
    required = {'SKILL.md', 'scripts/intelligence.py',
                'scripts/lib/intelligence/delivery.py', 'scripts/lib/intelligence/sources.py'}
    if not isinstance(files, dict) or not required.issubset(files):
        raise ValueError('Incomplete intelligence package')
    seen = set()
    for name, expected in files.items():
        rel = PurePosixPath(name)
        if rel.is_absolute() or '..' in rel.parts or '\\' in name or ':' in name:
            raise ValueError('Invalid package path')
        if name.casefold() in seen:
            raise ValueError('Ambiguous package paths')
        seen.add(name.casefold())
        path = source.joinpath(*rel.parts)
        if path.is_symlink() or not path.is_file():
            raise ValueError('Missing package file: ' + name)
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != expected:
            raise ValueError('Package checksum mismatch: ' + name)
        if path.suffix == '.py':
            compile(data, str(path), 'exec')
    return files


def install(source: Path, root: Path) -> dict:
    files = validate(source)
    destination = root / 'last30days'
    if destination.is_dir() and all(
        (destination / name).is_file()
        and hashlib.sha256((destination / name).read_bytes()).hexdigest() == expected
        for name, expected in files.items()
    ):
        return {'status': 'already_installed', 'path': str(destination), 'backup': None}
    root.mkdir(parents=True, exist_ok=True)
    stage = root / ('.last30days-install-' + uuid.uuid4().hex)
    backup = None
    try:
        stage.mkdir()
        # Copy only manifest-listed public Skill files, never local credentials/cache.
        for name in files:
            target = stage / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source / name, target)
        if destination.exists() or destination.is_symlink():
            suffix = datetime.now().strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8]
            backup = root / ('.last30days-backup-' + suffix)
            destination.rename(backup)
        try:
            stage.rename(destination)
        except BaseException:
            if backup is not None and not destination.exists() and not destination.is_symlink():
                backup.rename(destination)
            raise
    finally:
        if stage.exists():
            shutil.rmtree(stage)
    return {'status': 'installed', 'path': str(destination),
            'backup': str(backup) if backup is not None else None}


def main() -> int:
    parser = argparse.ArgumentParser(description='Install this bundled Skill for the current Codex user')
    parser.add_argument('--source', type=Path, default=Path(__file__).resolve().parent / 'payload' / 'last30days')
    parser.add_argument('--install-root', type=Path, default=Path.home() / '.agents' / 'skills')
    parser.add_argument('--check', action='store_true', help='Validate the package without installing')
    args = parser.parse_args()
    if sys.version_info < (3, 12):
        raise RuntimeError('Python 3.12 or newer is required')
    if args.check:
        print('Validated package: ' + str(len(validate(args.source))) + ' files')
        return 0
    result = install(args.source, args.install_root)
    print(json.dumps(result, ensure_ascii=True, indent=2))
    print('Open a new local Codex conversation and invoke $last30days.')
    print('Installation does not enable scheduled jobs or send notifications.')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print('Installation failed: ' + type(exc).__name__ + ': ' + str(exc), file=sys.stderr)
        raise SystemExit(1)
