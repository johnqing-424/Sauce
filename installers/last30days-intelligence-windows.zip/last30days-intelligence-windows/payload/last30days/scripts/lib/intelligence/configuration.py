"""Non-secret JSON settings; delivery credentials remain environment-only."""

from __future__ import annotations

import json
import math
import os
from dataclasses import asdict
from pathlib import Path
from zoneinfo import ZoneInfo

from .analysis import DEFAULT_WEIGHTS
from .models import Limits
from .transport import validate_local_proxy_url

ENV_KEYS = frozenset({"LAST30DAYS_INTEL_CONFIG", "LAST30DAYS_INTEL_DB", "LAST30DAYS_INTEL_REPORT_DIR"})


def load_settings(path: str | None = None) -> dict:
    settings = {"limits": asdict(Limits()), "weights": dict(DEFAULT_WEIGHTS),
                "threshold_a": 85, "threshold_b": 60, "confidence_threshold": .7,
                "lookback_days": 30, "max_reports": 4, "cache_seconds": 86400,
                "engine_sources": ["reddit", "hackernews"], "channels": [],
                "timezone": "Asia/Shanghai", "min_delivery_interval_seconds": 1,
                "source_check_interval_seconds": 3600, "local_proxy_url": None,
                "db": str(Path.home() / ".local/share/last30days/research.db"),
                "report_dir": str(Path.home() / ".local/share/last30days/intelligence/reports")}
    file_path = path or os.environ.get("LAST30DAYS_INTEL_CONFIG")
    if not file_path:
        default_file = Path.home() / '.config/last30days/intelligence.json'
        if default_file.is_file():
            file_path = str(default_file)
    if file_path:
        payload = json.loads(Path(file_path).expanduser().read_text(encoding="utf-8"))
        if not isinstance(payload, dict) or set(payload) - set(settings):
            raise ValueError("configuration contains unknown non-secret settings")
        for key, value in payload.items():
            if key in {"limits", "weights"}:
                if not isinstance(value, dict):
                    raise ValueError(f"{key} must be an object")
                settings[key].update(value)
            else:
                settings[key] = value
    settings["limits"] = asdict(Limits(**settings["limits"]))
    for key in ("lookback_days", "max_reports"):
        if type(settings[key]) is not int or settings[key] < 1:
            raise ValueError(f"{key} must be a positive integer")
    for key in ("threshold_a", "threshold_b", "confidence_threshold", "cache_seconds",
                "min_delivery_interval_seconds", "source_check_interval_seconds"):
        value = settings[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError(f"invalid {key}")
    if not 0 <= settings["threshold_b"] <= settings["threshold_a"] <= 100 or settings["confidence_threshold"] > 1:
        raise ValueError("invalid score or confidence thresholds")
    if set(settings["weights"]) - set(DEFAULT_WEIGHTS):
        raise ValueError("unknown score weight")
    for value in settings["weights"].values():
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError("invalid score weight")
    if sum(settings["weights"].values()) <= 0:
        raise ValueError("score weights need a positive sum")
    if not isinstance(settings["channels"], list) or set(settings["channels"]) - {"webhook", "telegram", "feishu", "slack", "wecom", "smtp"}:
        raise ValueError("unknown notification channel")
    if not isinstance(settings["engine_sources"], list) or not all(isinstance(item, str) for item in settings["engine_sources"]):
        raise ValueError("engine_sources must be a list")
    ZoneInfo(settings["timezone"])
    settings['local_proxy_url'] = validate_local_proxy_url(settings['local_proxy_url'])
    for key, variable in (("db", "LAST30DAYS_INTEL_DB"), ("report_dir", "LAST30DAYS_INTEL_REPORT_DIR")):
        if os.environ.get(variable):
            settings[key] = os.environ[variable]
        if not isinstance(settings[key], str) or not settings[key].strip():
            raise ValueError(f"invalid {key}")
    return settings
