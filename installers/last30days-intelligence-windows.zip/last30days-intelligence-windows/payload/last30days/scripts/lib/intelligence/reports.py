"""Local, private, inspectable JSON and Markdown evidence reports."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path


def _text(value) -> str:
    return str(value or "unknown").replace("\x00", "").replace("\r", "")


def render_markdown(report: dict) -> str:
    score = report["score"]["total"]
    trace = report["source_trace"]
    lines = [f"# {_text(report['title'])}", "", f"Generated: {report['generated_at']}",
             f"Value proxy: {score}/100 · Delivery tier: {report['tier']}",
             f"Verification: {report['verification_status']}", "", "## Discovery", "", _text(report["summary"]),
             "", "## Three source roles", "", f"Origin status: {trace['origin_status']}"]
    earliest = trace.get("earliest_verifiable")
    lines.append(f"Earliest retrieved dated record: {earliest['url']} ({earliest['published_at']}); global earliest is unknown." if earliest else "Earliest dated record: unknown.")
    lines.extend(["Creator-direct records: " + (", ".join(trace.get("creator_direct", [])) or "unknown"),
                  "Underlying resources: " + (", ".join(trace.get("underlying_evidence", [])) or "unknown"),
                  "", "## Claims and facts", ""])
    for claim in report["claims"]:
        lines.append(f"- [{claim['status']}] {_text(claim['text'])}")
    lines.extend(["", "## Verifiable evidence", ""])
    for item in report["evidence"]:
        lines.extend([f"### {_text(item['resource_type'])}: {_text(item['author'])}", "", item["url"],
                      f"Published: {_text(item['published_at'])}; version: {_text(item['version'])}",
                      f"Retrieved: {item['verified_at']}; location: {item['locator']}; SHA256: {item['content_hash']}",
                      f"Status: {item['status']}; freshness: {item.get('freshness_status', 'retrieved')}", ""])
        lines.extend("> " + line for line in item["quote"].splitlines())
        lines.append("")
    lines.extend(["## Value and uncertainty", "", _text(report["analysis"]["why_it_matters"]),
                  _text(report["analysis"]["application_potential"]), ""])
    lines.extend("- " + _text(value) for value in report["analysis"]["uncertainty"])
    for insight in report["analysis"].get("agent_insights", []):
        lines.extend(["", f"AI inference (not fact): {_text(insight['text'])}"])
    lines.extend(["", "## Observed relationship chain", ""])
    for edge in report["graph"]["edges"]:
        lines.append(f"- {edge['from_url']} → [{edge['relation']}] {edge['to_url']} ({edge.get('locator', 'unknown')}; target retrieved: {edge.get('target_verified', False)})")
    if report.get("failures"):
        lines.extend(["", "## Partial coverage", ""])
        lines.extend(f"- {item['url']}: {item['status']} ({item.get('reason', 'unknown')})" for item in report["failures"])
    lines.extend(["", "## Next directions", ""])
    lines.extend(f"- {item['url']}: {item.get('relation', item.get('reason', 'linked resource'))}" for item in report.get("next_directions", []))
    return "\n".join(lines) + "\n"


def _atomic_write(path: Path, content: str):
    fd, staging = tempfile.mkstemp(prefix=".intel-", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(staging, path)
    finally:
        Path(staging).unlink(missing_ok=True)


def save_report(report: dict, directory: str | Path) -> dict:
    directory = Path(directory).expanduser().resolve()
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    path = directory / f"{report['id']}-{report['revision']}.json"
    report["report_path"] = str(path)
    report["markdown_path"] = str(path.with_suffix(".md"))
    _atomic_write(path, json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False))
    _atomic_write(path.with_suffix(".md"), render_markdown(report))
    return report
