"""Discover, preserve, monitor and deliver using the extension's shared state."""

from __future__ import annotations

import hashlib
import json
import time
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

from . import delivery
from .engine import upstream_discover
from .knowledge import Knowledge
from .models import Budget, BudgetExceeded, Limits, identity_url, normalize_url, utc_now
from .reports import save_report
from .runner import Runner


class IntelligenceService:
    def __init__(self, settings: dict, *, resolver=None, engine_fn=None):
        if resolver is None:
            from .sources import SourceResolver
            resolver = SourceResolver()
        self.settings = settings
        self.knowledge = Knowledge(settings["db"])
        self.resolver = resolver
        self.engine_fn = engine_fn or upstream_discover
        self.limits = Limits(**settings["limits"])
        self.runner = Runner(self.knowledge, resolver, self.limits, weights=settings["weights"],
                             threshold_a=settings["threshold_a"], threshold_b=settings["threshold_b"],
                             confidence_threshold=settings["confidence_threshold"], cache_seconds=settings["cache_seconds"])
        self.configs = delivery.load_channels()
        if settings["channels"]:
            self.configs = {key: value for key, value in self.configs.items() if key in settings["channels"]}
        with self.knowledge.connection() as conn:
            delivery.init_schema(conn)

    def _queue(self, report: dict, tier: str, *, period_key: str = "") -> int:
        with self.knowledge.connection() as conn:
            conn.execute("BEGIN IMMEDIATE")
            queued = 0
            for name in self.configs:
                if tier in {"B", "C"} and conn.execute(
                    "SELECT 1 FROM intel_outbox WHERE channel=? AND tier=? AND period_key=? LIMIT 1",
                    (name, tier, period_key),
                ).fetchone():
                    continue
                queued += delivery.enqueue(conn, report, name, tier, period_key)
            return queued

    def deliver(self, *, send: bool = False) -> dict:
        with self.knowledge.connection() as conn:
            return delivery.flush(conn, self.configs, dry_run=not send,
                                  min_interval_seconds=self.settings["min_delivery_interval_seconds"])

    def trace(self, candidate: dict | str, *, refresh: bool = False, budget: Budget | None = None,
              domain: str = "", analysis: dict | None = None) -> dict:
        report = self.runner.trace(candidate, refresh=refresh, budget=budget, domain=domain, agent_analysis=analysis)
        save_report(report, self.settings["report_dir"])
        current_primary = any(
            resource["url"] in report["source_trace"]["creator_direct"]
            and resource["metadata"].get("freshness_status") != "historical_not_revalidated"
            and not resource["metadata"].get("retrieval_failures")
            for resource in report["resources"]
        )
        if report["tier"] == "A" and current_primary:
            self._queue(report, "A")
        return report

    def discover(self, domain: str, *, send: bool = False, seeds: dict | list | None = None) -> dict:
        domain = " ".join(domain.split())
        if not domain:
            raise ValueError("discover requires a nonempty domain")
        budget = Budget(self.limits)
        run_id = self.knowledge.start_run("discover", domain)
        upstream = {}
        failures, candidates, reports = [], [], []
        historical = self.knowledge.sources(domain=domain, limit=2)
        try:
            if seeds is None:
                try:
                    upstream = self.engine_fn(domain, budget, sources=self.settings["engine_sources"], lookback_days=self.settings["lookback_days"])
                except BudgetExceeded as exc:
                    failures.append({"source": "last30days", "status": "budget_exhausted", "reason": str(exc)})
                except Exception as exc:
                    failures.append({"source": "last30days", "status": "error", "reason": type(exc).__name__})
            else:
                upstream = _import_seeds(seeds)
            # Known creators are re-used as entry points. Leave room for new clues.
            for source in historical[:1]:
                candidates.append({"url": source["url"], "source": "historical_primary", "title": source["url"]})
            if seeds is None:
                try:
                    since = (datetime.now(timezone.utc) - timedelta(days=self.settings["lookback_days"])).date().isoformat()
                    candidates.extend(self.resolver.discover(domain, budget, since, limit=self.settings["max_reports"] * 2))
                    failures.extend(getattr(self.resolver, "last_failures", []))
                except BudgetExceeded as exc:
                    failures.append({"source": "primary_discovery", "status": "budget_exhausted", "reason": str(exc)})
                except Exception as exc:
                    failures.append({"source": "primary_discovery", "status": "error", "reason": type(exc).__name__})
            candidates.extend(upstream.get("candidates", []))
            identities = set()
            for candidate in candidates:
                if not isinstance(candidate, dict) or not candidate.get("url"):
                    continue
                try:
                    identity = identity_url(candidate["url"])
                    if identity in identities:
                        known = self.knowledge.find_event([candidate["url"]])
                        if known:
                            self.knowledge.record_observation(known["id"], candidate)
                        continue
                    if len(reports) >= self.settings["max_reports"]:
                        known = self.knowledge.find_event([candidate["url"]])
                        if known:
                            self.knowledge.record_observation(known["id"], candidate)
                        continue
                    identities.add(identity)
                    is_history = candidate.get("source") == "historical_primary"
                    due = any(item["url"] == candidate["url"] and item["next_check"] <= time.time() for item in historical)
                    report = self.trace(candidate, domain=domain, budget=budget, refresh=is_history and due)
                    # Persist all cross-platform observations, even when one event
                    # appears several times in a scan; only one card is emitted.
                    existing = next((item for item in reports if item["id"] == report["id"]), None)
                    if existing is None:
                        reports.append(report)
                    self.knowledge.mark_source_checked(candidate["url"], interval_seconds=self.settings["source_check_interval_seconds"], failed=bool(report["failures"]))
                except BudgetExceeded:
                    break
                except ValueError:
                    failures.append({"source": candidate.get("source", "unknown"), "status": "invalid_resource_url"})
            outcomes = upstream.get("source_status", {})
            degraded = failures or any((value.get("state") if isinstance(value, dict) else value) not in {"ok", "no-results"} for value in outcomes.values())
            result = {"schema_version": "last30days-intelligence-run/1", "domain": domain,
                      "status": "partial" if degraded or any(report["failures"] for report in reports) else "completed" if reports else "no-results",
                      "upstream": upstream, "source_failures": failures, "reports": reports,
                      "historical_sources_used": min(1, len(historical)), "budget": budget.snapshot(),
                      "delivery": self.deliver(send=send),
                      "real_send_requested": send, "generated_at": utc_now()}
            self.knowledge.finish_run(run_id, result, result["status"])
            return result
        except Exception as exc:
            self.knowledge.finish_run(run_id, {"error": type(exc).__name__, "budget": budget.snapshot()}, "failed")
            raise

    def run_watches(self, *, send: bool = False, max_jobs: int = 4) -> dict:
        executed = []
        for _ in range(max_jobs):
            watch = self.knowledge.claim_watch(lease_seconds=self.limits.max_seconds + 120)
            if not watch:
                break
            status = "failed"
            try:
                if watch["kind"] == "domain":
                    result = self.discover(watch["target"], send=send)
                    status = result["status"]
                    executed.append({"name": watch["name"], "result": result})
                else:
                    report = self.trace(watch["target"], refresh=True)
                    status = "completed" if not report["failures"] else "partial"
                    executed.append({"name": watch["name"], "report": report, "delivery": self.deliver(send=send)})
            except Exception as exc:
                executed.append({"name": watch["name"], "error": type(exc).__name__})
            finally:
                self.knowledge.finish_watch(watch, status)
        return {"executed": executed, "delivery": self.deliver(send=send), "generated_at": utc_now()}

    def briefing(self, frequency: str, *, send: bool = False, now: datetime | None = None) -> dict:
        local = (now or datetime.now(timezone.utc)).astimezone(ZoneInfo(self.settings["timezone"]))
        midnight = local.replace(hour=0, minute=0, second=0, microsecond=0)
        if frequency == "daily":
            end = midnight
            start = end - timedelta(days=1)
            period = start.date().isoformat()
            tier = "B"
        elif frequency == "weekly":
            end = midnight - timedelta(days=local.weekday())
            start = end - timedelta(days=7)
            period = f"{start.isocalendar().year}-W{start.isocalendar().week:02d}"
            tier = "C"
        else:
            raise ValueError("briefing requires daily or weekly")
        reports = self.knowledge.reports(since=start.astimezone(timezone.utc).isoformat(), until=end.astimezone(timezone.utc).isoformat())
        reports = [report for report in reports if report["tier"] == "B" or (tier == "C" and report["tier"] == "A")]
        evidence = [item for report in reports for item in report["evidence"]]
        types = Counter(node["kind"] for report in reports for node in report["graph"]["nodes"])
        authors = Counter(node["author"] for report in reports for node in report["graph"]["nodes"] if node.get("author"))
        relations = Counter(edge["relation"] for report in reports for edge in report["graph"]["edges"])
        revision = hashlib.sha256(json.dumps(sorted((r["id"], r["revision"]) for r in reports)).encode()).hexdigest()[:24]
        report = {"schema_version": "last30days-intelligence/1", "id": f"briefing-{tier}-{period}", "revision": revision,
                  "observation_window": {"start": start.isoformat(), "end_exclusive": end.isoformat(), "timezone": self.settings["timezone"]},
                  "title": f"Source Intelligence {frequency} · {period}", "summary": "\n\n".join(f"{r['title']}: {r['summary'][:250]}" for r in reports) or "No qualified new observations in this period.",
                  "generated_at": utc_now(), "domain": ", ".join(sorted({r["domain"] for r in reports})),
                  "source_trace": {"creator_direct": list(dict.fromkeys(url for r in reports for url in r["source_trace"]["creator_direct"])),
                                   "underlying_evidence": list(dict.fromkeys(url for r in reports for url in r["source_trace"]["underlying_evidence"])), "earliest_verifiable": None, "origin_status": "see_individual_reports"},
                  "score": {"total": round(sum(r["score"]["total"] for r in reports) / len(reports), 2) if reports else 0}, "tier": tier,
                  "verification_status": "aggregated_local_observations; not an exhaustive industry trend", "evidence": evidence,
                  "claims": [claim for r in reports for claim in r["claims"]],
                  "analysis": {"new": "Newly recorded resources or material revisions in the local observation window.",
                               "why_it_matters": f"Observed {len(reports)} qualified events, {len(types)} resource types and {len(authors)} attributed authors.",
                               "application_potential": "Follow the linked primary resources for further evaluation.",
                               "uncertainty": ["Local sample coverage may be incomplete; counts do not establish a broader technical trend.", "Experimental claims remain unreplicated unless explicitly verified in an individual report."]},
                  "graph": {"nodes": [node for r in reports for node in r["graph"]["nodes"]], "edges": [edge for r in reports for edge in r["graph"]["edges"]]},
                  "failures": [], "next_directions": [item for r in reports for item in r["next_directions"]],
                  "trend_observations": {"resource_types": dict(types), "attributed_authors": dict(authors), "observed_relationships": dict(relations)},
                  "event_reports": [{"id": r["id"], "revision": r["revision"], "title": r["title"]} for r in reports]}
        save_report(report, self.settings["report_dir"])
        queued = self._queue(report, tier, period_key=period) if reports else 0
        return {"tier": tier, "period": period, "report": report, "queued": queued, "delivery": self.deliver(send=send)}


def _import_seeds(payload: dict | list) -> dict:
    if isinstance(payload, list):
        return {"candidates": payload, "source_status": {}, "imported_seed_bundle": True}
    if not isinstance(payload, dict):
        raise ValueError("seed input must be a source bundle or result array")
    if payload.get("mock") or payload.get("test_fixture"):
        raise ValueError("mock seed bundles cannot enter a real intelligence run")
    if "candidates" in payload:
        return dict(payload, imported_seed_bundle=True)
    if "results" in payload:
        candidates = [dict(row, snippet=row.get("summary", "")) for row in payload["results"] if isinstance(row, dict)]
        return {"candidates": candidates, "source_status": payload.get("source_status", {}), "imported_seed_bundle": True}
    if "items_by_source" in payload:
        candidates = [dict(item, source=source, snippet=item.get("snippet") or item.get("body", ""), raw_source_item=item)
                      for source, items in payload["items_by_source"].items() for item in items]
        return {"candidates": candidates, "source_status": payload.get("source_status", {}), "imported_seed_bundle": True}
    raise ValueError("unrecognized seed bundle")
