# Optional autonomous source-intelligence extension; no eager imports.
