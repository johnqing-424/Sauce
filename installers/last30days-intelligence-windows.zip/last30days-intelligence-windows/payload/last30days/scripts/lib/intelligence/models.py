"""Shared records and finite exploration budgets (standard library only)."""

from __future__ import annotations

import hashlib
import math
import re
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def normalize_url(url: str) -> str:
    """Remove presentation/tracking only; preserve meaningful query parameters."""
    parts = urlsplit(url.strip())
    if parts.scheme not in {"https", "http"} or not parts.hostname or parts.username or parts.password:
        raise ValueError("expected a public HTTP(S) resource URL without credentials")
    query = [(k, v) for k, v in parse_qsl(parts.query, keep_blank_values=True)
             if not k.lower().startswith("utm_") and k.lower() not in {"fbclid", "gclid"}]
    host = parts.netloc.lower()
    return urlunsplit((parts.scheme.lower(), host, parts.path or "/", urlencode(query), ""))


def identity_url(url: str) -> str:
    """Project identity, distinct from exact evidence/version URLs."""
    normalized = normalize_url(url)
    parts = urlsplit(normalized)
    path = parts.path.rstrip("/")
    if parts.hostname in {"github.com", "www.github.com"}:
        segments = path.strip("/").split("/")
        if len(segments) >= 2:
            return "https://github.com/" + "/".join(segments[:2]).removesuffix(".git").lower()
    if parts.hostname in {"arxiv.org", "www.arxiv.org", "export.arxiv.org"}:
        match = re.match(r"/(?:abs|pdf|html)/(.+?)(?:\.pdf)?$", path)
        if match:
            return "https://arxiv.org/abs/" + re.sub(r"v\d+$", "", match[1])
    if parts.hostname in {"doi.org", "dx.doi.org"}:
        return "https://doi.org" + path.lower()
    return normalized


@dataclass
class Link:
    url: str
    relation: str = "references"
    label: str = ""
    locator: str = ""


@dataclass
class Document:
    url: str
    title: str = ""
    text: str = ""
    resource_type: str = "webpage"
    author: str | None = None
    published_at: str | None = None
    version: str | None = None
    links: list[Link] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)
    primary_basis: str | None = None
    verified_at: str = field(default_factory=utc_now)
    content_hash: str = ""

    def __post_init__(self):
        if not self.content_hash:
            self.content_hash = hashlib.sha256(self.text.encode("utf-8")).hexdigest()

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict) -> Document:
        data = dict(payload)
        data["links"] = [Link(**row) for row in data.get("links", [])]
        return cls(**data)


@dataclass(frozen=True)
class Limits:
    max_depth: int = 2
    max_calls: int = 30
    max_nodes: int = 25
    max_seconds: float = 180
    max_cost_usd: float = 0
    request_timeout: float = 12
    max_bytes: int = 1_048_576

    def __post_init__(self):
        for name in ("max_calls", "max_nodes", "max_bytes"):
            value = getattr(self, name)
            if type(value) is not int or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        if type(self.max_depth) is not int or self.max_depth < 0:
            raise ValueError("max_depth must be a nonnegative integer")
        for name in ("max_seconds", "request_timeout", "max_cost_usd"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError(f"{name} must be finite")
            if value < 0 or (name != "max_cost_usd" and value == 0):
                raise ValueError(f"invalid {name}")


class BudgetExceeded(RuntimeError):
    pass


class Budget:
    def __init__(self, limits: Limits | None = None, *, clock=time.monotonic):
        self.limits = limits or Limits()
        self.clock = clock
        self.started = clock()
        self.calls = 0
        self.cost_usd = 0.0
        self.resource_nodes: set[str] = set()

    @property
    def remaining_seconds(self) -> float:
        return max(0.0, self.limits.max_seconds - (self.clock() - self.started))

    def take(self, cost_usd: float = 0) -> float:
        if not math.isfinite(cost_usd) or cost_usd < 0:
            raise ValueError("cost must be finite and nonnegative")
        if self.remaining_seconds <= 0:
            raise BudgetExceeded("time budget exhausted")
        if self.calls >= self.limits.max_calls:
            raise BudgetExceeded("call budget exhausted")
        if self.cost_usd + cost_usd > self.limits.max_cost_usd:
            raise BudgetExceeded("cost budget exhausted")
        self.calls += 1
        self.cost_usd += cost_usd
        return min(self.limits.request_timeout, self.remaining_seconds)

    def visit(self, url: str):
        if url not in self.resource_nodes and len(self.resource_nodes) >= self.limits.max_nodes:
            raise BudgetExceeded("resource node budget exhausted")
        self.resource_nodes.add(url)

    def snapshot(self) -> dict:
        return {"operations": self.calls, "resource_nodes": len(self.resource_nodes), "cost_usd": self.cost_usd,
                "elapsed_seconds": round(self.clock() - self.started, 3), "limits": asdict(self.limits)}
