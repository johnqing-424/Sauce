"""Conservative evidence reports; heuristic value is never a factual verdict."""

from __future__ import annotations

import hashlib
import json
import math
import re
from datetime import datetime, timezone

from .models import Document, identity_url, utc_now


DEFAULT_WEIGHTS = {"novelty": .15, "originality": .15, "technical_value": .2,
                   "application_potential": .15, "confidence": .2,
                   "evidence_quality": .15, "engagement": 0}
PRIMARY_TYPES = {"paper", "repository", "dataset", "release", "patent", "official_document", "documentation"}


def select_primary_documents(candidate: dict, documents: list[Document], edges: list[dict], *, preferred_url: str | None = None) -> list[Document]:
    """A resource-type link proves a reference, not same-work equivalence."""
    work_urls = {candidate["url"]}
    for _ in range(len(documents) + 1):
        for edge in edges:
            if edge["from_url"] in work_urls and edge["relation"] in {"paper", "code", "official", "release", "dataset", "documentation", "redirect", "resolved_resource", "same_work"}:
                work_urls.add(edge["to_url"])
    eligible = [doc for doc in documents if doc.url in work_urls and doc.primary_basis and doc.text.strip()
                and not doc.metadata.get("fork") and not doc.metadata.get("is_fork")]
    if preferred_url:
        eligible.sort(key=lambda doc: identity_url(doc.url) != identity_url(preferred_url))
    if not eligible:
        return []
    selected = [eligible[0]]
    for doc in eligible[1:]:
        # same_work is an explicitly evidence-backed relation, unlike code/paper
        # inferred solely from an href. Default adapters do not invent it.
        if any(edge["relation"] == "same_work" and edge["from_url"] in {item.url for item in selected}
               and edge["to_url"] == doc.url for edge in edges):
            selected.append(doc)
    return selected


def _quote(document: Document) -> dict | None:
    if not document.text.strip():
        return None
    start = len(document.text) - len(document.text.lstrip())
    quote = document.text[start:start + 400].rstrip()
    return {"url": document.url, "quote": quote, "locator": f"text:chars:{start}-{start + len(quote)}",
            "content_hash": document.content_hash, "verified_at": document.verified_at,
            "author": document.author, "published_at": document.published_at,
            "version": document.version, "resource_type": document.resource_type,
            "freshness_status": document.metadata.get("freshness_status", "retrieved_or_cached"),
            "content_origin": "extracted_or_adapter_assembled_snapshot",
            "retrieval_records": document.metadata.get("retrieval_records", []),
            "status": "primary_document_retrieved" if document.primary_basis else "document_retrieved",
            "primary_basis": document.primary_basis}


def material_revision(documents: list[Document], canonical_url: str) -> str:
    records = []
    for doc in documents:
        # Known propagation counters are useful context, not a material update.
        lines = [line for line in doc.text.splitlines() if not re.match(
            r'^\s*["\s]*(?:stars|stargazers_count|forks_count|watchers_count|likes|views|last_checked|verified_at)["\s]*\s*[:=]', line, re.I)]
        # Preserve code indentation and exact evidence separately. Ignore only
        # trailing whitespace and repeated blank lines in the material fingerprint.
        material_text = re.sub(r"\n{3,}", "\n\n", "\n".join(line.rstrip() for line in lines)).strip("\n")
        records.append((identity_url(doc.url), doc.resource_type, doc.version,
                        hashlib.sha256(material_text.encode()).hexdigest()))
    payload = {"identity": canonical_url, "resources": sorted(set(records), key=lambda value: str(value))}
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()[:24]


def _valid_date(raw: str | None) -> datetime | None:
    if not raw:
        return None
    try:
        value = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value
    except (ValueError, TypeError):
        return None


def build_report(candidate: dict, documents: list[Document], edges: list[dict], failures: list[dict],
                 exploration: dict, *, previous: dict | None = None, domain: str = "",
                 weights: dict | None = None, threshold_a: float = 85, threshold_b: float = 60,
                 confidence_threshold: float = .7) -> dict:
    primaries = select_primary_documents(candidate, documents, edges,
                                         preferred_url=previous.get("canonical_url") if previous else None)
    primary = primaries[0] if primaries else None
    canonical = identity_url(primary.url if primary else candidate["url"])
    event_id = "intel-" + hashlib.sha256(canonical.encode()).hexdigest()[:20]
    evidence = [item for doc in documents if (item := _quote(doc)) is not None]
    same_work_urls = {doc.url for doc in primaries} | {candidate["url"]}
    dated = [(date, doc) for doc in documents if doc.url in same_work_urls and (date := _valid_date(doc.published_at)) is not None
             and date <= datetime.now(timezone.utc)]
    earliest = min(dated, key=lambda pair: pair[0])[1] if dated else None
    earliest_record = ({"url": earliest.url, "published_at": earliest.published_at,
                        "date_basis": earliest.metadata.get("date_basis", "publisher_metadata"),
                        "scope": "retrieved_records_only", "unrelated_references_excluded": True} if earliest else None)
    primary_types = {doc.resource_type for doc in primaries}
    technical_artifacts = {d.resource_type for d in documents} & {"repository", "dataset", "documentation", "release", "paper"}
    confidence = .85 if primary else (.35 if evidence else 0)
    components = {"novelty": 100, "originality": 85 if primary else 15,
                  "technical_value": min(100, 35 + 22 * len(technical_artifacts)) if evidence else 0,
                  "application_potential": min(100, 30 + 25 * len(technical_artifacts)) if evidence else 0,
                  "confidence": confidence * 100,
                  "evidence_quality": min(100, 55 + 20 * len(primary_types)) if primary else (20 if evidence else 0),
                  "engagement": 0}
    revision = material_revision(primaries or documents, canonical)
    if previous and previous.get("revision") == revision:
        components = previous["score"]["components"]
    configured_weights = dict(DEFAULT_WEIGHTS)
    if weights is not None:
        if not isinstance(weights, dict) or set(weights) - set(DEFAULT_WEIGHTS):
            raise ValueError("unknown score weight")
        configured_weights.update(weights)
    for value in configured_weights.values():
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError("score weights must be finite and nonnegative")
    total_weight = sum(configured_weights.values())
    if total_weight <= 0:
        raise ValueError("score weights must have positive sum")
    # Engagement may be configured as context, but cannot gate primary evidence.
    engagement = candidate.get("engagement", {})
    if configured_weights["engagement"] and isinstance(engagement, dict):
        positive = [v for v in engagement.values() if isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) and v > 0]
        components = dict(components, engagement=min(100, math.log1p(sum(positive)) * 8))
    total = round(sum(components[key] * configured_weights[key] for key in configured_weights) / total_weight, 2)
    if not primary or confidence < confidence_threshold:
        tier = "hold"
    else:
        tier = "A" if total >= threshold_a else "B" if total >= threshold_b else "hold"
    claim_text = candidate.get("snippet") or candidate.get("title") or "Original observation has no claim text."
    claim_matches = [doc for doc in primaries if claim_text and claim_text in doc.text]
    claims = [{"text": claim_text, "status": "author_claim" if claim_matches else "unverified",
               "evidence_urls": [doc.url for doc in claim_matches],
               "note": "A quoted author claim does not establish independent experimental verification."}]
    for doc in primaries:
        claims.append({"text": f"Primary {doc.resource_type} retrieved: {doc.title or doc.url}",
                       "status": "primary_document_confirmed", "evidence_urls": [doc.url],
                       "note": "Confirms document availability and observed metadata only."})
    uncertainty = ["No independent replication or experimental fact verification was performed.",
                   "Earliest public record is scoped to retrieved records; global priority is unknown.",
                   "Novelty, originality and practical value are heuristic proxies, not proved breakthroughs."]
    if primary is None:
        uncertainty.append("The creator's original source is unknown.")
    if any(doc.published_at is None for doc in primaries):
        uncertainty.append("Some primary publication dates are unknown.")
    if failures:
        uncertainty.append("Some linked resources could not be retrieved; the evidence chain is partial.")
    report = {"schema_version": "last30days-intelligence/1", "id": event_id, "revision": revision,
              "canonical_url": canonical, "domain": domain,
              "title": primary.title if primary and primary.title else candidate.get("title") or canonical,
              "summary": (primary.text[:500] if primary else candidate.get("snippet", "")),
              "generated_at": utc_now(), "original_observations": [candidate],
              "source_trace": {"earliest_verifiable": earliest_record,
                               "creator_direct": [doc.url for doc in primaries],
                               "underlying_evidence": [doc.url for doc in documents if doc.resource_type in PRIMARY_TYPES],
                               "underlying_evidence_status": "linked_original_material; support_for_experimental_claims_not_established",
                               "origin_status": "primary_resource_verified" if primary else "unknown"},
              "evidence": evidence, "claims": claims,
              "verification_status": "primary_material_retrieved; experiments_not_independently_verified" if primary else "unverified_origin",
              "analysis": {"new": ("No material change from the previously recorded resource." if previous and previous.get("revision") == revision
                                    else "Material source revision changed from the prior local record." if previous
                                    else "Resource newly observed in this local knowledge base; global novelty is unknown."),
                           "why_it_matters": f"Observed resource types: {', '.join(sorted(technical_artifacts)) or 'unclassified'}. Primary evidence is linked below.",
                           "application_potential": "Available code, data or documentation may support evaluation; usability has not been tested.",
                           "uncertainty": uncertainty,
                           "inferences": [{"status": "ai_inference", "text": "Artifact availability may make follow-up evaluation practical.",
                                          "evidence_urls": [doc.url for doc in primaries]}] if primaries else []},
              "score": {"total": total, "components": components, "weights": configured_weights,
                        "method": "objective_artifact_proxies_and_local_history; not scientific novelty proof"},
              "tier": tier, "resources": [doc.to_dict() for doc in documents],
              "graph": {"nodes": [{"url": doc.url, "kind": doc.resource_type, "author": doc.author,
                                    "primary_basis": doc.primary_basis, "version": doc.version} for doc in documents], "edges": edges},
              "failures": failures, "exploration": exploration,
              "next_directions": exploration.get("pending", [])}
    return report


def add_agent_analysis(report: dict, payload: dict, documents: list[Document]) -> None:
    """Host-provided hypotheses need real quotations, and remain hypotheses."""
    snapshots = {doc.url: doc for doc in documents}
    insights = []
    if not isinstance(payload, dict) or not isinstance(payload.get("insights", []), list):
        raise ValueError("agent analysis must contain an insights list")
    for item in payload.get("insights", []):
        if not isinstance(item, dict) or not isinstance(item.get("text"), str) or not item["text"].strip():
            raise ValueError("agent insight needs text")
        references = item.get("evidence", [])
        if not isinstance(references, list) or not references:
            raise ValueError("agent insight needs snapshot quote evidence")
        for reference in references:
            doc = snapshots.get(reference.get("url")) if isinstance(reference, dict) else None
            quote = reference.get("quote") if isinstance(reference, dict) else None
            if not doc or not isinstance(quote, str) or not quote.strip() or quote not in doc.text:
                raise ValueError("agent evidence quote must match a retrieved snapshot")
        insights.append({"text": item["text"], "status": "ai_inference", "evidence": references})
    report["analysis"]["agent_insights"] = insights
