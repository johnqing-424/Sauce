"""Reuse the actual upstream pipeline before its nomination popularity filter.

The worker is a process so its platform request threads cannot escape the
intelligence run's deadline. Its internal network calls are one coarse budget
operation, explicitly distinguished from individually metered source fetches.
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from lib.intelligence.models import Budget


FREE_AUTH_KEYS = {"GITHUB_TOKEN", "AUTH_TOKEN", "CT0", "BSKY_HANDLE", "BSKY_APP_PASSWORD"}


def child_environment() -> dict:
    environment = dict(os.environ)
    for key in list(environment):
        if key not in FREE_AUTH_KEYS and (key.endswith(("_API_KEY", "_API_TOKEN", "_BEARER_TOKEN"))
                                         or key in {"OPENAI_KEY", "APIFY_API_TOKEN", "LAST30DAYS_API_KEY"}):
            environment.pop(key, None)
        if key.startswith("LAST30DAYS_INTEL_") or key.startswith("SMTP_"):
            environment.pop(key, None)
    environment.update({"LAST30DAYS_CONFIG_DIR": "", "LAST30DAYS_SKIP_KEYCHAIN": "1",
                        "FROM_BROWSER": "off", "BROWSER_CONSENT": "0",
                        "LAST30DAYS_STORE": "0", "LAST30DAYS_DEBUG": "0",
                        "LAST30DAYS_TRUST_PROJECT_CONFIG": "0"})
    return environment


def _free_config() -> dict:
    # No user/project/keychain config is loaded in this free-only lane. Original
    # last30days research retains its full credential/config behavior.
    config = {key: os.environ.get(key) for key in FREE_AUTH_KEYS}
    config.update({"FROM_BROWSER": "off", "_BROWSER_COOKIE_MODE": "off",
                   "LAST30DAYS_X_BACKEND": "bird",
                   "LAST30DAYS_REASONING_PROVIDER": "auto", "LAST30DAYS_STORE": "0",
                   "_research_deadline": time.monotonic() + 55})
    return config


def collect_raw(domain: str, *, sources: list[str] | None = None, lookback_days: int = 30) -> dict:
    from lib import dates, pipeline, planner, schema

    domain = " ".join(domain.split())
    if not domain:
        raise ValueError("autonomous discovery requires a nonempty domain")
    config = _free_config()
    available = pipeline.available_sources(config)
    requested = sources or ["reddit", "hackernews"]
    from_date, to_date = dates.get_date_range(lookback_days)
    plan = planner.build_discovery_plan(domain, available_sources=requested)
    bundle = pipeline.nominate_candidates(plan, from_date=from_date, to_date=to_date,
                                         depth="quick", mock=False, config=config,
                                         lookback_days=lookback_days, keyword_gate=True)
    candidates = []
    for source, items in bundle.items_by_source.items():
        for item in items:
            if not item.url:
                continue
            candidates.append({"url": item.url, "title": item.title, "snippet": item.snippet or item.body,
                               "author": item.author, "published_at": item.published_at,
                               "source": source, "engagement": item.engagement,
                               "raw_source_item": schema.to_dict(item)})
    return {"candidates": candidates, "source_status": schema.to_dict(bundle.source_status),
            "window": {"from": from_date, "to": to_date}, "available_sources": available,
            "collection": "upstream_pipeline.nominate_candidates_before_velocity_filter",
            "real_external": True, "mock": False,
            "budget_scope": "one bounded upstream operation; internal platform requests are not individually metered"}


def upstream_discover(domain: str, budget: Budget, *, sources: list[str] | None = None,
                      lookback_days: int = 30) -> dict:
    from lib import subproc

    budget.take()
    timeout = min(60, budget.remaining_seconds)
    payload = {"domain": domain, "sources": sources, "lookback_days": lookback_days}
    command = [sys.executable, "-I", str(Path(__file__).resolve())]
    try:
        result = subproc.run_with_timeout(command, timeout=timeout,
                                         deadline_monotonic=time.monotonic() + timeout,
                                         cleanup_grace=.2, env=child_environment(),
                                         input_text=json.dumps(payload),
                                         capture_limit_bytes=8_388_608)
        if result.returncode != 0:
            return {"candidates": [], "source_status": {"last30days": {"state": "error"}},
                    "real_external": True, "error": "upstream_worker_failed"}
        return json.loads(result.stdout)
    except subproc.SubprocTimeout:
        return {"candidates": [], "source_status": {"last30days": {"state": "timeout"}}, "real_external": True}
    except (OSError, ValueError):
        return {"candidates": [], "source_status": {"last30days": {"state": "error"}}, "real_external": True,
                "error": "upstream_worker_or_json_failure"}


if __name__ == "__main__":
    try:
        request = json.load(sys.stdin)
        # Upstream source diagnostics may print on stdout. Preserve JSON output.
        from contextlib import redirect_stdout
        with redirect_stdout(sys.stderr):
            response = collect_raw(**request)
        json.dump(response, sys.stdout, ensure_ascii=False)
    except Exception as exc:
        json.dump({"candidates": [], "source_status": {"last30days": {"state": "error"}},
                   "error": type(exc).__name__, "real_external": True}, sys.stdout)
        sys.exit(1)
