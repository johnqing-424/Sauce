"""Bounded relationship traversal and persistent evidence-first research."""

from __future__ import annotations

import heapq
import itertools
from urllib.parse import urlsplit

from .analysis import add_agent_analysis, build_report, select_primary_documents
from .knowledge import Knowledge
from .models import Budget, BudgetExceeded, Document, Limits, Link, identity_url, normalize_url


RELATION_PRIORITY = {"paper": 0, "code": 1, "official": 1, "dataset": 2, "release": 2,
                     "documentation": 3, "dependency": 4, "author": 5, "organization": 5,
                     "feed": 6, "api": 6, "references": 8}


class Runner:
    def __init__(self, knowledge: Knowledge, resolver, limits: Limits | None = None, *,
                 weights: dict | None = None, threshold_a: float = 85, threshold_b: float = 60,
                 confidence_threshold: float = .7, cache_seconds: float = 86400):
        self.knowledge = knowledge
        self.resolver = resolver
        self.limits = limits or Limits()
        self.weights = weights
        self.threshold_a = threshold_a
        self.threshold_b = threshold_b
        self.confidence_threshold = confidence_threshold
        self.cache_seconds = cache_seconds

    def trace(self, candidate: dict | str, *, domain: str = "", refresh: bool = False,
              budget: Budget | None = None, agent_analysis: dict | None = None) -> dict:
        if isinstance(candidate, str):
            candidate = {"url": candidate}
        candidate = dict(candidate)
        candidate["url"] = normalize_url(candidate["url"])
        budget = budget or Budget(self.limits)
        counters = itertools.count()
        frontier = [(0, 0, next(counters), candidate["url"])]
        visited, documents, edges, failures, pending = set(), [], [], [], []
        truncated = False
        cached = 0
        while frontier:
            if len(visited) >= self.limits.max_nodes or budget.remaining_seconds <= 0:
                truncated = True
                pending.extend({"url": entry[3], "reason": "budget_limit"} for entry in frontier)
                break
            depth, priority, _, url = heapq.heappop(frontier)
            if url in visited:
                continue
            visited.add(url)
            try:
                budget.visit(url)
                doc = None if refresh else self.knowledge.get_document(url, max_age_seconds=self.cache_seconds)
                if doc is None:
                    doc = self.resolver.fetch(url, budget)
                    if not isinstance(doc, Document):
                        raise ValueError("resolver did not return Document")
                    doc.url = normalize_url(doc.url)
                    prior = self.knowledge.get_document(doc.url)
                    if doc.metadata.get("retrieval_failures") and prior is not None and prior.primary_basis:
                        # A failed README/release lookup is not removal of the
                        # prior evidence. Retain the partial snapshot as history,
                        # but defer a material revision until a complete refresh.
                        self.knowledge.save_document(doc, current=False)
                        partial = doc
                        doc = Document.from_dict(prior.to_dict())
                        doc.metadata = dict(doc.metadata, freshness_status="historical_not_revalidated",
                                            retrieval_failures=partial.metadata["retrieval_failures"],
                                            partial_refresh={"verified_at": partial.verified_at,
                                                             "content_hash": partial.content_hash,
                                                             "observed_version": partial.version})
                    else:
                        self.knowledge.save_document(doc)
                else:
                    cached += 1
                documents.append(doc)
                self.knowledge.tag_source(doc.url, domain)
                for failure in doc.metadata.get("retrieval_failures", []):
                    if isinstance(failure, dict):
                        failures.append(dict(failure, url=doc.url))
                if doc.url != url:
                    resolution = doc.metadata.get("resolution_basis", "adapter_returned_resource_url")
                    redirected = resolution == "validated_http_redirect"
                    edge = {"from_url": url, "to_url": doc.url, "relation": "redirect" if redirected else "resolved_resource",
                            "locator": resolution, "state": "transport_observed" if redirected else "adapter_observed"}
                    edges.append(edge)
                    self.knowledge.save_edge(edge)
                    visited.add(doc.url)
                for raw in doc.links:
                    link = raw if isinstance(raw, Link) else Link(**raw)
                    try:
                        target = normalize_url(link.url)
                        if urlsplit(target).scheme != "https":
                            continue
                    except (ValueError, TypeError):
                        continue
                    edge = {"from_url": doc.url, "to_url": target, "relation": link.relation,
                            "label": link.label, "locator": link.locator, "state": "observed_link",
                            "source_content_hash": doc.content_hash, "observed_at": doc.verified_at}
                    edges.append(edge)
                    self.knowledge.save_edge(edge)
                    if target in visited:
                        continue
                    if depth < self.limits.max_depth:
                        heapq.heappush(frontier, (depth + 1, RELATION_PRIORITY.get(link.relation, 9), next(counters), target))
                    else:
                        truncated = True
                        pending.append({"url": target, "relation": link.relation, "reason": "depth_limit"})
            except BudgetExceeded as exc:
                truncated = True
                failures.append({"url": url, "status": "budget_exhausted", "reason": str(exc)})
                pending.append({"url": url, "reason": "budget_limit"})
                pending.extend({"url": entry[3], "reason": "budget_limit"} for entry in frontier)
                break
            except Exception as exc:
                # Source failures can include credential-bearing URLs: persist type only.
                if callable(getattr(exc, "to_dict", None)):
                    failures.append(dict(exc.to_dict(), url=url))
                else:
                    failures.append({"url": url, "status": "unavailable", "reason": type(exc).__name__})
        edge_keys = set()
        edges = [edge for edge in edges if (key := (edge["from_url"], edge["to_url"], edge["relation"])) not in edge_keys
                 and not edge_keys.add(key)]
        fetched_urls = {doc.url for doc in documents}
        for edge in edges:
            edge["target_verified"] = edge["to_url"] in fetched_urls
        # Find earlier history by the observation first. Project alias resolution
        # follows only same-work links, rather than merging a cited dependency.
        selected = select_primary_documents(candidate, documents, edges)
        alias_candidates = [doc.url for doc in selected] + [candidate["url"]]
        previous = self.knowledge.find_event(alias_candidates)
        observed_previous = self.knowledge.find_event([candidate["url"]])
        blocked = {identity_url(item["url"]) for item in failures + pending}
        blocked.update(identity_url(doc.url) for doc in documents if doc.metadata.get("freshness_status") == "historical_not_revalidated")
        if observed_previous and identity_url(observed_previous["canonical_url"]) in blocked:
            previous = observed_previous
        if previous:
            unavailable = {identity_url(item["url"]) for item in failures + pending}
            historical_edges = previous.get("graph", {}).get("edges", [])
            # An unavailable parent also blocks checking its descendants. Restore
            # that previously observed subtree with explicit historical status.
            historical_identities = [(identity_url(edge["from_url"]), identity_url(edge["to_url"])) for edge in historical_edges]
            for _ in range(len(historical_identities) + 1):
                before = len(unavailable)
                for origin, target in historical_identities:
                    if origin in unavailable:
                        unavailable.add(target)
                if len(unavailable) == before:
                    break
            fetched_identities = {identity_url(doc.url) for doc in documents}
            for payload in previous.get("resources", []):
                if identity_url(payload["url"]) in unavailable and identity_url(payload["url"]) not in fetched_identities:
                    historic = Document.from_dict(payload)
                    historic.metadata = dict(historic.metadata, freshness_status="historical_not_revalidated")
                    documents.append(historic)
                    fetched_identities.add(identity_url(historic.url))
            document_urls = {doc.url for doc in documents}
            for old in historical_edges:
                key = (old["from_url"], old["to_url"], old["relation"])
                if (identity_url(old["from_url"]) in unavailable or identity_url(old["to_url"]) in unavailable) and old["from_url"] in document_urls and key not in edge_keys:
                    edges.append(dict(old, state="historical_observed_link",
                                      freshness_status="historical_not_revalidated", target_verified=False))
                    edge_keys.add(key)
        exploration = {"truncated": truncated, "visited_nodes": len(documents), "cache_hits": cached,
                       "budget": budget.snapshot(), "pending": pending}
        report = build_report(candidate, documents, edges, failures, exploration, previous=previous, domain=domain,
                              weights=self.weights, threshold_a=self.threshold_a, threshold_b=self.threshold_b,
                              confidence_threshold=self.confidence_threshold)
        primary_docs = [doc for doc in documents if doc.url in report["source_trace"]["creator_direct"]]
        if primary_docs and all(doc.metadata.get("freshness_status") == "historical_not_revalidated" for doc in primary_docs):
            report["verification_status"] = "historical_primary_evidence; current_check_failed"
            report["analysis"]["uncertainty"].append("Primary evidence is historical and was not revalidated during this run.")
        if agent_analysis is not None:
            add_agent_analysis(report, agent_analysis, documents)
        # Only same-work artifact edges create aliases; cited dependencies/authors remain distinct.
        primary_urls = set(report["source_trace"]["creator_direct"])
        aliases = [candidate["url"], report["canonical_url"]] + [doc.url for doc in documents if doc.url in primary_urls]
        return self.knowledge.save_report(report, aliases, candidate)
