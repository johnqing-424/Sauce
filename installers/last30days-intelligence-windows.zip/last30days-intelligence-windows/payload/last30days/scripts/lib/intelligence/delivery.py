"""Evidence cards and a durable, credential-free notification outbox (stdlib).

Enable channels with LAST30DAYS_INTEL_CHANNELS=telegram,feishu,webhook,slack,
wecom,smtp. Credentials are read only from the supplied environment mapping (or
os.environ); this module never reads upstream SQLite settings or .env files.
All following names have the LAST30DAYS_INTEL_ prefix:

* TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
* FEISHU_WEBHOOK_URL, optional FEISHU_SECRET (custom-bot signing secret)
* SLACK_WEBHOOK_URL, WECOM_WEBHOOK_URL
* WEBHOOK_URL, optional WEBHOOK_TOKEN (Bearer authentication)
* SMTP_HOST, SMTP_PORT (465 by default), SMTP_FROM, SMTP_TO (comma-separated),
  SMTP_USERNAME, SMTP_PASSWORD, SMTP_TLS (ssl by default, or starttls)

init_schema/enqueue preserve an existing caller transaction. The caller must
commit it before an actual flush: leases, rate reservations and acknowledgments
must become durable before network I/O. A flush never sleeps waiting for a rate
limit or retry; another scheduled invocation processes jobs when they are due.

Delivery is at-least-once. Each acknowledged chunk is saved, but a remote send
whose acknowledgment is lost can repeat after a crash. Generic webhooks receive
a stable per-chunk idempotency key in both their body and Idempotency-Key header.
HTTP uses inherited proxies and verified TLS; redirects are rejected. SMTP uses
verified implicit TLS or STARTTLS, through the ordinary SMTP socket transport.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import math
import os
import re
import smtplib
import sqlite3
import ssl
import time
import urllib.error
import urllib.request
import uuid
from contextlib import contextmanager
from email.message import EmailMessage
from email.utils import parseaddr
from typing import Callable, Mapping
from urllib.parse import urlsplit


CHANNELS = frozenset({"telegram", "feishu", "slack", "wecom", "webhook", "smtp"})
ENV_KEYS = frozenset("LAST30DAYS_INTEL_" + suffix for suffix in (
    "CHANNELS", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID", "FEISHU_WEBHOOK_URL", "FEISHU_SECRET",
    "SLACK_WEBHOOK_URL", "WECOM_WEBHOOK_URL", "WEBHOOK_URL", "WEBHOOK_TOKEN", "SMTP_HOST", "SMTP_PORT",
    "SMTP_FROM", "SMTP_TO", "SMTP_USERNAME", "SMTP_PASSWORD", "SMTP_TLS",
))
LEASE_SECONDS = 120.0
HTTP_TIMEOUT_SECONDS = 20.0
_MAX_RESPONSE_BYTES = 65536
_SAFE_ERRORS = frozenset({
    "invalid_config", "invalid_report", "invalid_options", "transaction_pending",
    "platform_rejected", "smtp_rejected", "http_error", "network_error",
    "redirect_rejected", "sender_error", "lease_expired",
})
# Conservative text limits reserve space for wrappers and continuation headings.
_TEXT_LIMITS = {"telegram": 4000, "feishu": 8000, "slack": 2800,
                "wecom": 1900, "webhook": 16000, "smtp": 64000}


class DeliveryError(Exception):
    """An intentionally bounded error: no transport message or URL is retained."""

    def __init__(self, code: str):
        self.code = code if code in _SAFE_ERRORS else "sender_error"
        super().__init__(self.code)


class ChannelConfig(dict):
    """Runtime credentials, with a safe repr even inside an outer config dict."""

    def __repr__(self) -> str:
        return "ChannelConfig(<redacted>)"

    __str__ = __repr__


def load_channels(environ: Mapping[str, str] | None = None) -> dict[str, dict]:
    """Load explicitly enabled channels; missing credentials stay unconfigured.

    Dry-run previews need no credentials. Actual sends with incomplete settings
    fail with invalid_config, without exposing the supplied values.
    """
    env = os.environ if environ is None else environ
    names = [item.strip().lower() for item in env.get("LAST30DAYS_INTEL_CHANNELS", "").split(",") if item.strip()]
    if any(name not in CHANNELS for name in names):
        raise DeliveryError("invalid_config")

    def value(suffix: str, default: str = "") -> str:
        return env.get("LAST30DAYS_INTEL_" + suffix, default)

    result: dict[str, dict] = {}
    for name in names:
        if name == "telegram":
            config = {"bot_token": value("TELEGRAM_BOT_TOKEN"), "chat_id": value("TELEGRAM_CHAT_ID")}
        elif name == "smtp":
            tls = value("SMTP_TLS", "ssl").lower()
            config = {"host": value("SMTP_HOST"), "port": value("SMTP_PORT", "587" if tls == "starttls" else "465"),
                      "tls": tls, "from": value("SMTP_FROM"),
                      "to": [part.strip() for part in value("SMTP_TO").split(",") if part.strip()],
                      "username": value("SMTP_USERNAME"), "password": value("SMTP_PASSWORD")}
        else:
            suffix = "WEBHOOK_URL" if name == "webhook" else name.upper() + "_WEBHOOK_URL"
            config = {"webhook_url": value(suffix)}
            if name == "webhook":
                config["token"] = value("WEBHOOK_TOKEN")
            elif name == "feishu":
                config["signing_secret"] = value("FEISHU_SECRET")
        result[name] = ChannelConfig(config)
    return result


def init_schema(conn: sqlite3.Connection) -> None:
    """Add intelligence tables without changing upstream schema/user_version.

    Individual statements intentionally avoid executescript's implicit commit.
    """
    statements = (
        """CREATE TABLE IF NOT EXISTS intel_outbox (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id TEXT NOT NULL, revision TEXT NOT NULL,
            channel TEXT NOT NULL, tier TEXT NOT NULL, period_key TEXT NOT NULL,
            report_json TEXT NOT NULL, chunks_json TEXT NOT NULL,
            total_chunks INTEGER NOT NULL, next_chunk INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0,
            next_attempt_at REAL NOT NULL DEFAULT 0,
            lease_token TEXT, lease_until REAL,
            created_at REAL NOT NULL, updated_at REAL NOT NULL, sent_at REAL,
            last_error TEXT,
            UNIQUE(event_id, revision, channel, tier, period_key)
        )""",
        """CREATE INDEX IF NOT EXISTS intel_outbox_due
            ON intel_outbox(status, next_attempt_at, channel)""",
        """CREATE TABLE IF NOT EXISTS intel_delivery_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            outbox_id INTEGER NOT NULL REFERENCES intel_outbox(id),
            channel TEXT NOT NULL, chunk_index INTEGER NOT NULL,
            attempt INTEGER NOT NULL, outcome TEXT NOT NULL,
            attempted_at REAL NOT NULL, error_code TEXT,
            idempotency_key TEXT NOT NULL
        )""",
        """CREATE TABLE IF NOT EXISTS intel_delivery_rate_limits (
            channel TEXT PRIMARY KEY, next_send_at REAL NOT NULL
        )""",
    )
    for statement in statements:
        conn.execute(statement)


@contextmanager
def _savepoint(conn: sqlite3.Connection):
    name = "intel_" + uuid.uuid4().hex
    conn.execute("SAVEPOINT " + name)
    try:
        yield
        conn.execute("RELEASE SAVEPOINT " + name)
    except BaseException:
        conn.execute("ROLLBACK TO SAVEPOINT " + name)
        conn.execute("RELEASE SAVEPOINT " + name)
        raise


@contextmanager
def _atomic(conn: sqlite3.Connection):
    # This write lock is held only for queue bookkeeping, never during I/O.
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield
        conn.commit()
    except BaseException:
        conn.rollback()
        raise


def _json(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _display(value, default: str = "unknown") -> str:
    if value is None or value == "" or value == [] or value == {}:
        return default
    return _json(value) if isinstance(value, (dict, list)) else str(value)


def _card(report: dict, tier: str, period_key: str) -> str:
    kind = {"A": "A intelligence alert", "B": "B daily digest", "C": "C weekly synthesis"}[tier]
    lines = [kind + (" | " + period_key if period_key else ""),
             _display(report.get("title")), _display(report.get("summary")),
             "Event: " + _display(report.get("id")) + " | Revision: " + _display(report.get("revision")),
             "Domain: " + _display(report.get("domain")),
             "Verification: " + _display(report.get("verification_status")), "Source roles:"]
    trace = report.get("source_trace") or {}
    lines.append("Earliest verifiable retrieved record (observed graph): " + _display(trace.get("earliest_verifiable")))
    lines.append("Creator direct: " + _display(trace.get("creator_direct")))
    lines.append("Underlying evidence: " + _display(trace.get("underlying_evidence")))
    lines.append("Origin: " + _display(trace.get("origin_status")))
    lines.append("Evidence:")
    for index, evidence in enumerate(report.get("evidence") or [], 1):
        lines.append(str(index) + ". " + _display(evidence.get("url")))
        lines.append("Status: " + _display(evidence.get("status")) + " | Author: " + _display(evidence.get("author"))
                     + " | Published: " + _display(evidence.get("published_at")) + " | Version: "
                     + _display(evidence.get("version")) + " | Resource: " + _display(evidence.get("resource_type")))
        lines.append("Quote: " + _display(evidence.get("quote")))
        lines.append("Locator: " + _display(evidence.get("locator")) + " | Hash: " + _display(evidence.get("content_hash"))
                     + " | Verified at: " + _display(evidence.get("verified_at")))
    lines.append("Claims (status retained): " + _display(report.get("claims")))
    analysis = report.get("analysis") or {}
    for key, label in (("new", "New"), ("why_it_matters", "Why it matters"),
                       ("application_potential", "Application potential (hypothesis)"),
                       ("uncertainty", "Uncertainty"), ("inferences", "AI inferences (not verified)")):
        lines.append(label + ": " + _display(analysis.get(key)))
    score = report.get("score") or {}
    lines.append("Score (heuristic proxy; not proof of innovation): " + _display(score.get("total")))
    lines.append("Score components: " + _display(score.get("components")) + " | Method: " + _display(score.get("method")))
    if report.get("report_url"):
        # Only a caller-supplied, externally verified URL; no synthetic links.
        lines.append("Full report: " + str(report["report_url"]))
    lines.append("Generated: " + _display(report.get("generated_at")))
    return "\n".join(lines)


def _chunks(text: str, channel: str) -> list[str]:
    limit = _TEXT_LIMITS[channel] - 80
    encoding = "utf-16-le" if channel == "telegram" else "utf-8"
    divisor = 2 if channel == "telegram" else 1
    parts = []
    offset = 0
    while offset < len(text):
        size, end = 0, offset
        while end < len(text):
            # Feishu limits the JSON message body, where control characters can
            # expand sixfold. Its conservative limit includes escaped text.
            units = (len(_json(text[end])[1:-1].encode("utf-8")) if channel == "feishu"
                     else len(text[end].encode(encoding)) // divisor)
            if size + units > limit:
                break
            size += units
            end += 1
        if end < len(text):
            newline = text.rfind("\n", offset, end)
            if newline > offset + (end - offset) // 2:
                end = newline + 1
        parts.append(text[offset:end])
        offset = end
    total = len(parts)
    return [f"[last30days {index}/{total}]\n" + part for index, part in enumerate(parts, 1)]


def enqueue(conn: sqlite3.Connection, report: dict, channel: str, tier: str = "A", period_key: str = "") -> bool:
    """Persist a report once per event/revision/channel/tier/period; False on duplicates/hold."""
    if not isinstance(report, dict):
        raise DeliveryError("invalid_report")
    if report.get("tier") == "hold" or tier == "hold":
        return False
    if channel not in CHANNELS or tier not in {"A", "B", "C"} or not isinstance(period_key, str):
        raise DeliveryError("invalid_config")
    if not all(isinstance(report.get(key), str) and report[key].strip() for key in ("id", "revision")):
        raise DeliveryError("invalid_report")
    try:
        serialized = _json(report)
        chunks = _chunks(_card(report, tier, period_key), channel)
    except (TypeError, ValueError, AttributeError, UnicodeError):
        raise DeliveryError("invalid_report") from None
    init_schema(conn)
    created = time.time()
    with _savepoint(conn):
        cursor = conn.execute("""INSERT INTO intel_outbox
            (event_id,revision,channel,tier,period_key,report_json,chunks_json,total_chunks,created_at,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(event_id,revision,channel,tier,period_key) DO NOTHING""",
            (report["id"], report["revision"], channel, tier, period_key, serialized, _json(chunks), len(chunks), created, created))
    return cursor.rowcount == 1


def _rows(cursor) -> list[dict]:
    names = [column[0] for column in cursor.description]
    return [dict(zip(names, row)) for row in cursor.fetchall()]


def _delivery_key(job: dict, index: int) -> str:
    identity = [job[key] for key in ("event_id", "revision", "channel", "tier", "period_key")] + [index]
    return hashlib.sha256(_json(identity).encode("utf-8")).hexdigest()


def _payload(job: dict, report: dict, text: str, index: int, config: dict, preview: bool = False) -> dict:
    channel = job["channel"]
    if channel == "telegram":
        return {"chat_id": "<redacted>" if preview else config.get("chat_id", ""), "text": text,
                "link_preview_options": {"is_disabled": True}}
    if channel == "feishu":
        return {"msg_type": "post", "content": {"post": {"en_us": {
            "title": f"last30days {job['tier']} {index + 1}/{job['total_chunks']}",
            "content": [[{"tag": "text", "text": text}]]}}}}
    if channel == "slack":
        return {"text": text, "blocks": [{"type": "section", "text": {"type": "plain_text", "text": text}}],
                "unfurl_links": False, "unfurl_media": False}
    if channel == "wecom":
        return {"msgtype": "text", "text": {"content": text}}
    if channel == "smtp":
        title = str(report.get("title") or "Intelligence report").replace("\r", " ").replace("\n", " ")[:180]
        return {"subject": f"[last30days {job['tier']} {index + 1}/{job['total_chunks']}] {title}", "body": text}
    return {"source": "last30days", "kind": "source_intelligence", "event_id": job["event_id"],
            "revision": job["revision"], "tier": job["tier"], "period_key": job["period_key"],
            "idempotency_key": _delivery_key(job, index),
            "chunk": {"index": index, "count": job["total_chunks"]}, "text": text, "report": report}


def _log(conn: sqlite3.Connection, job: dict, index: int, outcome: str, now: float, error: str | None = None):
    conn.execute("""INSERT INTO intel_delivery_log
        (outbox_id,channel,chunk_index,attempt,outcome,attempted_at,error_code,idempotency_key)
        VALUES (?,?,?,?,?,?,?,?)""", (job["id"], job["channel"], index, job["attempts"], outcome, now, error,
                                      _delivery_key(job, index)))


def _reserve_rate(conn: sqlite3.Connection, channel: str, now: float, interval: float):
    conn.execute("""INSERT INTO intel_delivery_rate_limits(channel,next_send_at) VALUES (?,?)
        ON CONFLICT(channel) DO UPDATE SET next_send_at=excluded.next_send_at""", (channel, now + interval))


def _claim(conn: sqlite3.Connection, channels: list[str], now: float, interval: float, max_attempts: int) -> dict | None:
    with _atomic(conn):
        conn.execute("""UPDATE intel_outbox SET status='pending',lease_token=NULL,lease_until=NULL,updated_at=?
            WHERE status='leased' AND lease_until<=?""", (now, now))
        conn.execute("""UPDATE intel_outbox SET status='failed',last_error='lease_expired',updated_at=?
            WHERE status='pending' AND attempts>=?""", (now, max_attempts))
        if not channels:
            return None
        placeholders = ",".join("?" for _ in channels)
        jobs = _rows(conn.execute(f"""SELECT o.* FROM intel_outbox o
            WHERE o.status='pending' AND o.next_attempt_at<=? AND o.channel IN ({placeholders})
            AND NOT EXISTS (SELECT 1 FROM intel_delivery_rate_limits r
                            WHERE r.channel=o.channel AND r.next_send_at>?)
            ORDER BY o.next_attempt_at,o.id LIMIT 1""", (now, *channels, now)))
        if not jobs:
            return None
        job = jobs[0]
        token = uuid.uuid4().hex
        conn.execute("""UPDATE intel_outbox SET status='leased',lease_token=?,lease_until=?,
            attempts=attempts+1,updated_at=? WHERE id=?""", (token, now + LEASE_SECONDS, now, job["id"]))
        _reserve_rate(conn, job["channel"], now, interval)
        job.update(status="leased", lease_token=token, lease_until=now + LEASE_SECONDS, attempts=job["attempts"] + 1)
        return job


def _ack(conn: sqlite3.Connection, job: dict, index: int, now: float) -> bool:
    final = index + 1 == job["total_chunks"]
    with _atomic(conn):
        cursor = conn.execute("""UPDATE intel_outbox SET next_chunk=?,attempts=0,last_error=NULL,
            status=?,sent_at=?,updated_at=?,lease_token=?,lease_until=? WHERE id=? AND lease_token=?""",
            (index + 1, "sent" if final else "leased", now if final else None, now,
             None if final else job["lease_token"], None if final else now + LEASE_SECONDS,
             job["id"], job["lease_token"]))
        if cursor.rowcount != 1:
            return False
        _log(conn, job, index, "sent", now)
    job.update(next_chunk=index + 1, attempts=0)
    return True


def _reserve_next(conn: sqlite3.Connection, job: dict, now: float, interval: float) -> bool:
    with _atomic(conn):
        if not conn.execute("SELECT 1 FROM intel_outbox WHERE id=? AND lease_token=?",
                            (job["id"], job["lease_token"])).fetchone():
            return False
        slot = conn.execute("SELECT next_send_at FROM intel_delivery_rate_limits WHERE channel=?", (job["channel"],)).fetchone()
        if slot and slot[0] > now:
            conn.execute("""UPDATE intel_outbox SET status='pending',lease_token=NULL,lease_until=NULL,
                next_attempt_at=?,updated_at=? WHERE id=? AND lease_token=?""", (slot[0], now, job["id"], job["lease_token"]))
            return False
        conn.execute("UPDATE intel_outbox SET attempts=1,lease_until=?,updated_at=? WHERE id=? AND lease_token=?",
                     (now + LEASE_SECONDS, now, job["id"], job["lease_token"]))
        _reserve_rate(conn, job["channel"], now, interval)
        job["attempts"] = 1
        return True


def _fail(conn: sqlite3.Connection, job: dict, index: int, now: float, error: str, interval: float, max_attempts: int) -> bool:
    retry = job["attempts"] < max_attempts
    due = now + min(3600.0, max(1.0, interval) * 2 ** (job["attempts"] - 1)) if retry else now
    with _atomic(conn):
        cursor = conn.execute("""UPDATE intel_outbox SET status=?,next_attempt_at=?,last_error=?,
            updated_at=?,lease_token=NULL,lease_until=NULL WHERE id=? AND lease_token=?""",
            ("pending" if retry else "failed", due, error, now, job["id"], job["lease_token"]))
        if cursor.rowcount != 1:
            return False
        _log(conn, job, index, "retry" if retry else "failed", now, error)
    return retry


def flush(conn: sqlite3.Connection, configs: dict[str, dict], dry_run: bool = True,
          sender: Callable[[str, dict, dict], None] | None = None, now: float | None = None,
          min_interval_seconds: float = 1, max_attempts: int = 3) -> dict:
    """Preview or send due jobs, returning counters and credential-free previews.

    sent counts completed jobs; chunks_sent counts acknowledgments; failed counts
    failed send attempts; retried counts attempts scheduled for a later retry;
    skipped counts outstanding jobs not attempted (config, due time, rate, lease).
    attempts in SQLite count the current chunk, resetting after acknowledgment.
    A custom sender must raise on rejection; returning None means acknowledged.
    """
    if (not isinstance(max_attempts, int) or not 1 <= max_attempts <= 50
            or not isinstance(min_interval_seconds, (int, float))
            or not math.isfinite(min_interval_seconds) or min_interval_seconds < 0
            # RECOVERY RECONSTRUCTION: initial add truncates inside this condition.
            or (now is not None and (not isinstance(now, (int, float)) or not math.isfinite(now)))):
        raise DeliveryError("invalid_options")
    if not isinstance(configs, dict) or any(channel not in CHANNELS or not isinstance(config, dict)
                                           for channel, config in configs.items()):
        raise DeliveryError("invalid_config")
    if not dry_run and conn.in_transaction:
        raise DeliveryError("transaction_pending")
    init_schema(conn)
    current = lambda: float(now) if now is not None else time.time()
    runtime = {channel: ChannelConfig(config) for channel, config in configs.items()}
    result = {"sent": 0, "chunks_sent": 0, "failed": 0, "retried": 0, "skipped": 0, "previews": []}
    # The exact query below also appears in root-0-34.output.txt.
    outstanding = _rows(conn.execute("SELECT * FROM intel_outbox WHERE status IN ('pending','leased') ORDER BY id"))
    attempted = set()
    if dry_run:
        moment = current()
        for job in outstanding:
            if job["next_attempt_at"] > moment or (job["status"] == "leased" and (job["lease_until"] or 0) > moment):
                result["skipped"] += 1
                continue
            report, chunks = json.loads(job["report_json"]), json.loads(job["chunks_json"])
            for index in range(job["next_chunk"], job["total_chunks"]):
                result["previews"].append({"outbox_id": job["id"], "channel": job["channel"], "tier": job["tier"],
                                           "period_key": job["period_key"], "chunk_index": index,
                                           "payload": _payload(job, report, chunks[index], index,
                                                               runtime.get(job["channel"], {}), preview=True)})
        return result
    send = sender if sender is not None else _send
    while True:
        job = _claim(conn, list(runtime), current(), min_interval_seconds, max_attempts)
        if job is None:
            break
        attempted.add(job["id"])
        report, chunks = json.loads(job["report_json"]), json.loads(job["chunks_json"])
        start = job["next_chunk"]
        for index in range(start, job["total_chunks"]):
            if index != start and not _reserve_next(conn, job, current(), min_interval_seconds):
                break
            try:
                # This call is readable in root-0-14.output.txt.
                send(job["channel"], runtime[job["channel"]], _payload(job, report, chunks[index], index, runtime[job["channel"]]))
            except Exception as error:
                # These four lines are recovered from delivery-0-15's full patch.
                code = error.code if isinstance(error, DeliveryError) else "sender_error"
                if not isinstance(code, str) or code not in _SAFE_ERRORS:
                    code = "sender_error"
                result["failed"] += 1
                if _fail(conn, job, index, current(), code, min_interval_seconds, max_attempts):
                    result["retried"] += 1
                break
            if not _ack(conn, job, index, current()):
                break
            result["chunks_sent"] += 1
            if index + 1 == job["total_chunks"]:
                result["sent"] += 1
    result["skipped"] = sum(job["id"] not in attempted for job in outstanding)
    return result


# RECOVERY RECONSTRUCTION: redirect handler was not readable in saved history.
class _RejectRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise DeliveryError("redirect_rejected")


# RECOVERED: following HTTPS/HTTP/address source is from root-0-65.output.txt.
def _https_endpoint(url) -> str:
    if not isinstance(url, str) or any(ord(char) < 33 for char in url):
        raise DeliveryError("invalid_config")
    try:
        parts = urlsplit(url)
        port = parts.port
    except ValueError:
        raise DeliveryError("invalid_config") from None
    if parts.scheme != "https" or not parts.hostname or parts.username or parts.password or parts.fragment or port == 0:
        raise DeliveryError("invalid_config")
    return url


def _http_send(channel: str, config: dict, payload: dict) -> None:
    if channel == "telegram":
        token = config.get("bot_token", "")
        if not isinstance(token, str) or not re.fullmatch(r"[A-Za-z0-9:_-]+", token) or not config.get("chat_id"):
            raise DeliveryError("invalid_config")
        endpoint = "https://api.telegram.org/bot" + token + "/sendMessage"
    else:
        endpoint = config.get("webhook_url", "")
    endpoint = _https_endpoint(endpoint)
    headers = {"Content-Type": "application/json; charset=utf-8", "User-Agent": "last30days-source-intelligence/1"}
    body = dict(payload)
    if channel == "webhook":
        headers["Idempotency-Key"] = payload["idempotency_key"]
        if config.get("token"):
            token = config["token"]
            if not isinstance(token, str) or any(ord(char) < 32 or ord(char) == 127 for char in token):
                raise DeliveryError("invalid_config")
            headers["Authorization"] = "Bearer " + token
    elif channel == "feishu" and config.get("signing_secret"):
        timestamp = str(int(time.time()))
        key = (timestamp + "\n" + str(config["signing_secret"])).encode("utf-8")
        body.update(timestamp=timestamp, sign=base64.b64encode(hmac.new(key, b"", hashlib.sha256).digest()).decode("ascii"))
    request = urllib.request.Request(endpoint, data=_json(body).encode("utf-8"), headers=headers, method="POST")
    # build_opener supplies its normal ProxyHandler from the inherited environment.
    opener = urllib.request.build_opener(_RejectRedirects(), urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    with opener.open(request, timeout=HTTP_TIMEOUT_SECONDS) as response:
        if not 200 <= response.status < 300:
            raise DeliveryError("http_error")
        raw = response.read(_MAX_RESPONSE_BYTES + 1)
    if len(raw) > _MAX_RESPONSE_BYTES:
        raise DeliveryError("platform_rejected")
    try:
        parsed = json.loads(raw) if raw else None
    except (ValueError, UnicodeError):
        parsed = None
    if channel == "telegram":
        success = isinstance(parsed, dict) and parsed.get("ok") is True
    elif channel == "feishu":
        code = parsed.get("code", parsed.get("StatusCode")) if isinstance(parsed, dict) else None
        success = type(code) in (int, float) and code == 0
    elif channel == "wecom":
        code = parsed.get("errcode") if isinstance(parsed, dict) else None
        success = type(code) in (int, float) and code == 0
    elif channel == "slack":
        success = raw.strip() == b"ok" or (isinstance(parsed, dict) and parsed.get("ok") is True)
    else:
        success = not (isinstance(parsed, dict) and (parsed.get("ok") is False or parsed.get("success") is False or parsed.get("error")))
    if not success:
        raise DeliveryError("platform_rejected")


def _address(value) -> str:
    if not isinstance(value, str) or any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise DeliveryError("invalid_config")
    parsed = parseaddr(value)[1]
    if "@" not in parsed or not parsed.split("@", 1)[0] or not parsed.rsplit("@", 1)[1]:
        raise DeliveryError("invalid_config")
    return parsed


def _smtp_send(config: dict, payload: dict) -> None:
    host, tls = config.get("host"), config.get("tls", "ssl")
    if not isinstance(host, str) or not host or any(ord(char) < 33 for char in host) or tls not in {"ssl", "starttls"}:
        # RECOVERY RECONSTRUCTION: the captured output ends at the if above.
        raise DeliveryError("invalid_config")
    try:
        port = int(config.get("port", 587 if tls == "starttls" else 465))
    except (TypeError, ValueError):
        raise DeliveryError("invalid_config") from None
    if not 1 <= port <= 65535:
        raise DeliveryError("invalid_config")
    from_address = _address(config.get("from"))
    to_values = config.get("to")
    if isinstance(to_values, str):
        to_values = [to_values]
    if not isinstance(to_values, (list, tuple)) or not to_values:
        raise DeliveryError("invalid_config")
    to_addresses = [_address(value) for value in to_values]
    username, password = config.get("username", ""), config.get("password", "")
    if (not isinstance(username, str) or not isinstance(password, str)
            or bool(username) != bool(password)):
        raise DeliveryError("invalid_config")
    message = EmailMessage()
    message["From"] = from_address
    message["To"] = ", ".join(to_addresses)
    message["Subject"] = payload["subject"]
    message.set_content(payload["body"])
    context = ssl.create_default_context()
    if tls == "ssl":
        client = smtplib.SMTP_SSL(host, port, timeout=HTTP_TIMEOUT_SECONDS, context=context)
    else:
        client = smtplib.SMTP(host, port, timeout=HTTP_TIMEOUT_SECONDS)
    with client as smtp:
        if tls == "starttls":
            smtp.ehlo()
            smtp.starttls(context=context)
            smtp.ehlo()
        if username:
            smtp.login(username, password)
        refused = smtp.send_message(message)
        if refused:
            raise DeliveryError("smtp_rejected")


# RECOVERY RECONSTRUCTION: default sender exception translation is unreadable.
def _send(channel: str, config: dict, payload: dict) -> None:
    try:
        if channel == "smtp":
            _smtp_send(config, payload)
        else:
            _http_send(channel, config, payload)
    except DeliveryError:
        raise
    except urllib.error.HTTPError:
        raise DeliveryError("http_error") from None
    except smtplib.SMTPException:
        raise DeliveryError("smtp_rejected") from None
    except (urllib.error.URLError, OSError):
        raise DeliveryError("network_error") from None
    except Exception:
        raise DeliveryError("sender_error") from None
