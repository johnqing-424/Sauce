#!/usr/bin/env python3
"""Headless fallback/cron entry for the last30days source-intelligence Skill."""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent.resolve()
sys.path.insert(0, str(SCRIPT_DIR))

from lib.intelligence.configuration import load_settings
from lib.intelligence.discovery import load_plan


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Evidence-led source intelligence using last30days", allow_abbrev=False)
    parser.add_argument("--config", help="Non-secret JSON settings file")
    parser.add_argument("--env-file", help="Explicit private dotenv file (environment takes precedence)")
    parser.add_argument("--db", help="Research SQLite file, shared with upstream via additive tables")
    parser.add_argument("--report-dir", help="Private local JSON/Markdown report directory")
    sub = parser.add_subparsers(dest="command", required=True)
    discover = sub.add_parser("discover", help="Explore a broad domain without user-supplied keywords")
    discover.add_argument("domain")
    discover.add_argument("--seeds", help="Optional existing real upstream raw/agent JSON to trace")
    discover.add_argument("--collect-only", action="store_true", help="Preserve candidates and triage for host review; do not trace or notify")
    discover.add_argument("--plan", help="Trusted local JSON with domain and 1–6 purposeful queries and rationales")
    discover.add_argument("--host-observations", help="Trusted host snapshot JSON; provenance remains host-reported")
    discover.add_argument("--send", action="store_true", help="Flush A-tier alerts using configured channels")
    for name in ("trace", "explore"):
        trace = sub.add_parser(name, help="Follow observed links from a public resource")
        trace.add_argument("url")
        trace.add_argument("--refresh", action="store_true")
        trace.add_argument("--depth", type=int)
        trace.add_argument("--analysis", help="Host inference JSON with exact snapshot quotations")
        trace.add_argument("--host-observations", help="Trusted host snapshot JSON; provenance remains host-reported")
        trace.add_argument("--send", action="store_true")
    watch = sub.add_parser("watch", help="Persist and execute due monitoring jobs")
    watch_sub = watch.add_subparsers(dest="watch_command", required=True)
    add = watch_sub.add_parser("add")
    add.add_argument("target")
    add.add_argument("--name")
    add.add_argument("--source", action="store_true", help="Monitor a resource URL instead of a domain")
    add.add_argument("--interval", type=float, default=3600)
    watch_sub.add_parser("list")
    run = watch_sub.add_parser("run")
    run.add_argument("--send", action="store_true")
    run.add_argument("--max-jobs", type=int, default=4)
    briefing = sub.add_parser("briefing", help="Daily qualified findings or weekly relationship observations")
    briefing.add_argument("frequency", choices=["daily", "weekly"])
    briefing.add_argument("--send", action="store_true")
    deliver = sub.add_parser("deliver", help="Preview or flush pending durable notification jobs")
    deliver.add_argument("--send", action="store_true")
    sub.add_parser("sources", help="List verified accumulated source entry points")
    return parser


def main(argv: list[str] | None = None, *, resolver=None, engine_fn=None) -> int:
    args = build_parser().parse_args(argv)
    plan = None
    if args.command == "discover":
        if args.collect_only and args.send:
            raise ValueError("collect-only cannot send notifications")
        if args.plan and args.seeds:
            raise ValueError("discovery plan cannot be combined with imported seeds")
        if args.plan:
            plan = load_plan(args.plan, args.domain)
    if args.env_file:
        from lib import env
        private_file = Path(args.env_file).expanduser()
        if not private_file.is_file():
            raise FileNotFoundError("Explicit environment file is missing")
        for key, value in env.load_env_file(private_file).items():
            os.environ.setdefault(key, value)
    settings = load_settings(args.config)
    if args.db:
        settings["db"] = args.db
    if args.report_dir:
        settings["report_dir"] = args.report_dir
    if args.command in {"trace", "explore"} and args.depth is not None:
        settings["limits"]["max_depth"] = args.depth
    if args.command in {"discover", "trace", "explore"} and args.host_observations:
        from lib.intelligence.host_sources import load_host_observations
        if resolver is None:
            from lib.intelligence.sources import SourceResolver
            from lib.intelligence.transport import PublicTransport
            resolver = SourceResolver(PublicTransport(local_proxy_url=settings.get("local_proxy_url")))
        resolver = load_host_observations(args.host_observations, resolver)
    from lib.intelligence.service import IntelligenceService
    service = IntelligenceService(settings, resolver=resolver, engine_fn=engine_fn)
    if args.command == "discover":
        seeds = json.loads(Path(args.seeds).read_text(encoding="utf-8")) if args.seeds else None
        result = service.discover(args.domain, send=args.send, seeds=seeds, collect_only=args.collect_only, plan=plan)
    elif args.command in {"trace", "explore"}:
        analysis = json.loads(Path(args.analysis).read_text(encoding="utf-8")) if args.analysis else None
        result = {"report": service.trace(args.url, refresh=args.refresh, analysis=analysis), "delivery": service.deliver(send=args.send)}
    elif args.command == "watch":
        if args.watch_command == "add":
            if args.source:
                from lib.intelligence.transport import canonical_public_url
                canonical_public_url(args.target)
            service.knowledge.add_watch(args.name or args.target, args.target, "source" if args.source else "domain", interval_seconds=args.interval)
            result = {"watches": service.knowledge.watches()}
        elif args.watch_command == "list":
            result = {"watches": service.knowledge.watches()}
        else:
            if args.max_jobs < 1:
                raise ValueError("max-jobs must be positive")
            result = service.run_watches(send=args.send, max_jobs=args.max_jobs)
    elif args.command == "briefing":
        result = service.briefing(args.frequency, send=args.send)
    elif args.command == "sources":
        result = {"sources": service.knowledge.sources()}
    else:
        result = service.deliver(send=args.send)
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    try:
        if sys.version_info < (3, 12):
            raise RuntimeError("Python >=3.12 is required")
        raise SystemExit(main())
    except Exception as exc:
        # Exception messages may include credential-bearing URLs or dotenv data.
        print(json.dumps({"status": "failed", "error": type(exc).__name__, "detail": "Check local configuration or recorded source outcomes; no credentials are logged."}), file=sys.stderr)
        raise SystemExit(2)
