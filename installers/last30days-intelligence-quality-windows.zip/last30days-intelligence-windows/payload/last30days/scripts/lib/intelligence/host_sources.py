"""Explicit host-tool snapshots, with no CLI transport-verification assertion.

Public API: ``load_host_observations(path, fallback)`` returns a resolver with
``fetch(url, budget)``, ``discover(domain, budget, since, limit=8)`` and the
fallback's ``last_failures``. Missing URLs keep the fallback's network policy.
Each consumed supplied snapshot charges a processing operation and resource
node; its recorded HTTP status is unknown. This is supplied data, not an HTTP
retry, a proxy fallback, or independently established origin/TLS verification.
"""

from __future__ import annotations

import base64
import hashlib
import json
import re
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import unquote, urlsplit

from .models import Budget, BudgetExceeded, Document, Link
from .sources import SourceResolver, _date, _github_kind, _html
from .transport import Response, SourceError, canonical_public_url


SCHEMA_VERSION = "last30days-host-observations/1"
MAX_FILE_BYTES = 5 * 1_048_576
MAX_TEXT_BYTES = 1_048_576
MAX_OBSERVATIONS = 25
CLOCK_TOLERANCE_SECONDS = 60
_FIELDS = frozenset({"url", "text", "content_type", "tool", "retrieved_at"})
_CONTENT_TYPES = frozenset({"text/html", "application/xhtml+xml", "text/plain", "text/markdown", "text/x-markdown", "application/json", "application/ld+json"})
_TRUST = ("Explicit host-tool observation: HTTP status, DNS resolution and origin TLS "
          "were not independently verified by the CLI. Original HTTP bytes were not "
          "provided; hashes cover the supplied UTF-8 text. Publisher metadata and "
          "authorship remain host-reported, with no institutional or experimental verification.")
_SEGMENT = r"[A-Za-z0-9_.-]+"
_REPO_API = re.compile(r"/repos/(" + _SEGMENT + r")/(" + _SEGMENT + r")/?$")
_README_API = re.compile(r"/repos/(" + _SEGMENT + r")/(" + _SEGMENT + r")/readme/?$")
_README_NAME = re.compile(r"readme(?:\.[A-Za-z0-9_-]+)?$", re.I)


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate host observation JSON field")
        result[key] = value
    return result


def _bounded(value, maximum: int, *, nonempty: bool = True, controls: bool = False) -> str:
    try:
        if not isinstance(value, str) or (nonempty and not value.strip()) or len(value.encode("utf-8")) > maximum:
            raise ValueError
        if controls and any(ord(char) < 32 or ord(char) == 127 for char in value):
            raise ValueError
    except (ValueError, UnicodeError):
        raise ValueError("Invalid or oversized host observation field") from None
    return value


@dataclass(frozen=True)
class _Snapshot:
    url: str
    text: str
    content_type: str
    tool: str
    retrieved_at: str

    @property
    def digest(self) -> str:
        return hashlib.sha256(self.text.encode("utf-8")).hexdigest()

    def record(self) -> dict:
        return {"requested_url": self.url, "response_url": self.url, "status": None,
                "content_type": self.content_type, "body_sha256": self.digest,
                "text_sha256": self.digest, "retrieved_at": self.retrieved_at,
                "tool": self.tool, "retrieval_method": "host_tool_observation",
                "body_encoding": "UTF-8 serialization of supplied host text; original HTTP bytes unknown"}

    def original(self) -> dict:
        return {"url": self.url, "text": self.text, "content_type": self.content_type,
                "tool": self.tool, "retrieved_at": self.retrieved_at, "text_sha256": self.digest}


def _validate_row(row: dict, now: datetime) -> _Snapshot:
    if not isinstance(row, dict) or set(row) != _FIELDS:
        raise ValueError("Host observations require exactly URL, text, content type, tool and retrieval time")
    url = canonical_public_url(_bounded(row["url"], 8192, controls=True))
    text = _bounded(row["text"], MAX_TEXT_BYTES, nonempty=False)
    content_type = _bounded(row["content_type"], 128, controls=True)
    content_type = content_type.split(";", 1)[0].strip().lower()
    if content_type not in _CONTENT_TYPES:
        raise ValueError("Unsupported host observation content type")
    tool = _bounded(row["tool"], 256, controls=True)
    stamp = _bounded(row["retrieved_at"], 128, controls=True)
    try:
        observed = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        if observed.tzinfo is None or observed.utcoffset() is None or observed > now + timedelta(seconds=CLOCK_TOLERANCE_SECONDS):
            raise ValueError
    except (ValueError, OverflowError):
        raise ValueError("Host retrieval time must be timezone-aware and not in the future") from None
    return _Snapshot(url, text, content_type, tool, stamp)


def load_host_observations(path: str | Path, fallback) -> HostObservationResolver:
    """Load only an explicitly named export, bounded before UTF-8/JSON parsing."""
    with Path(path).expanduser().open("rb") as stream:
        raw = stream.read(MAX_FILE_BYTES + 1)
    if len(raw) > MAX_FILE_BYTES:
        raise ValueError("Host observation file exceeds 5 MiB")
    try:
        payload = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object)
    except (ValueError, UnicodeError, RecursionError):
        raise ValueError("Invalid host observation JSON envelope") from None
    if (not isinstance(payload, dict) or set(payload) != {"schema_version", "observations"}
            or payload["schema_version"] != SCHEMA_VERSION or not isinstance(payload["observations"], list)
            or len(payload["observations"]) > MAX_OBSERVATIONS):
        raise ValueError("Invalid or oversized host observation envelope")
    now = datetime.now(timezone.utc)
    rows = [_validate_row(row, now) for row in payload["observations"]]
    if len({row.url for row in rows}) != len(rows):
        raise ValueError("Duplicate canonical host observation URL")
    return HostObservationResolver(rows, fallback)


def _object(row: _Snapshot) -> dict | None:
    if row.content_type != "application/json":
        return None
    try:
        value = json.loads(row.text, object_pairs_hook=_unique_object)
    except (ValueError, RecursionError):
        return None
    return value if isinstance(value, dict) else None


def _matching_file(url: str, project: tuple[str, str]) -> bool:
    parts = urlsplit(url)
    path = parts.path.strip("/").split("/")
    decoded = unquote(parts.path)
    if "\\" in decoded or any(part in {".", ".."} for part in decoded.split("/")):
        return False
    if parts.hostname not in {"github.com", "www.github.com", "raw.githubusercontent.com"} or len(path) < 4:
        return False
    if tuple(value.casefold() for value in path[:2]) != project or not _README_NAME.fullmatch(path[-1]):
        return False
    return parts.hostname == "raw.githubusercontent.com" or (path[2] == "blob" and len(path) >= 5)


def _public_links(links: list[Link]) -> list[Link]:
    result, seen = [], set()
    for link in links:
        try:
            url = canonical_public_url(link.url)
        except SourceError:
            continue
        key = (url, link.relation)
        if key not in seen:
            result.append(Link(url, link.relation, link.label, link.locator))
            seen.add(key)
    return result


def _artifact_key(url: str) -> str:
    parts = urlsplit(url)
    if parts.hostname in {"github.com", "www.github.com"} and len(parts.path.strip("/").split("/")) == 2 and not parts.query:
        return "https://github.com/" + parts.path.strip("/").casefold().removesuffix(".git")
    return url


class HostObservationResolver:
    """Resolver-compatible wrapper; instantiate through the validated loader."""

    def __init__(self, observations: list[_Snapshot], fallback):
        self.fallback = fallback
        self._snapshots = {row.url: row for row in observations}
        self._repositories = {}
        for row in observations:
            match = _REPO_API.fullmatch(urlsplit(row.url).path)
            if urlsplit(row.url).hostname != "api.github.com" or not match:
                continue
            project = (match[1].casefold(), match[2].casefold())
            body = _object(row)
            if not body or not isinstance(body.get("owner"), dict):
                continue
            if not isinstance(body.get("full_name"), str) or body["full_name"].casefold() != "/".join(project):
                continue
            owner = body["owner"].get("login")
            if not isinstance(owner, str) or owner.casefold() != project[0]:
                continue
            try:
                artifact = canonical_public_url(body.get("html_url"))
            except SourceError:
                continue
            target = urlsplit(artifact)
            if (target.hostname != "github.com" or target.path.rstrip("/").casefold() != "/" + "/".join(project)
                    or target.query or _github_kind(artifact) not in {"repository", "website_repository"}):
                continue
            self._repositories[row.url] = (row, body, project, artifact)
            self._repositories.setdefault(_artifact_key(artifact), (row, body, project, artifact))

    @property
    def last_failures(self):
        return getattr(self.fallback, "last_failures", [])

    def discover(self, domain, budget, since, limit=8):
        return self.fallback.discover(domain, budget, since, limit=limit)

    def has_observation(self, url: str) -> bool:
        """Prefer exact supplied snapshots or a repo alias with observed README.

        A metadata-only alias cannot displace a previously complete repo cache.
        This predicate is side-effect free and never invokes the fallback.
        """
        try:
            canonical = canonical_public_url(url)
        except SourceError:
            return False
        if canonical in self._snapshots:
            return True
        entry = self._repositories.get(_artifact_key(canonical))
        return entry is not None and self._readme(entry[2]) is not None

    def _generic(self, row: _Snapshot) -> Document:
        if row.content_type in {"text/html", "application/xhtml+xml"}:
            # Response is an internal parser record, never an asserted HTTP 200.
            doc = _html(Response(row.url, None, {"content-type": "text/html; charset=utf-8"}, row.text.encode("utf-8")))
            parts = urlsplit(row.url)
            paper = re.fullmatch(r"/(?:abs|html)/((?:\d{4}\.\d{4,5}|[a-z.-]+/\d{7})(?:v\d+)?)", parts.path)
            ids = doc.metadata.get("html_meta", {}).get("citation_arxiv_id", [])
            authors = doc.metadata.get("html_meta", {}).get("citation_author", [])
            if parts.hostname in {"arxiv.org", "www.arxiv.org", "export.arxiv.org"} and paper:
                doc.resource_type = "paper"
                observed = ids[0].strip() if ids else ""
                requested_version = re.search(r"v\d+$", paper[1])
                observed_version = re.search(r"v\d+$", observed)
                declared_version = doc.version
                versions = [item for item in (observed_version[0] if observed_version else None, declared_version) if item]
                version_matches = not requested_version or all(version == requested_version[0] for version in versions)
                if observed and re.sub(r"v\d+$", "", observed) == re.sub(r"v\d+$", "", paper[1]) and version_matches and any(author.strip() for author in authors):
                    doc.primary_basis = "host-reported original arXiv paper metadata; not CLI HTTP verification or experimental verification"
                    version = re.search(r"v\d+$", observed)
                    doc.version = version[0] if version else None
        else:
            doc = Document(url=row.url, text=row.text, links=SourceResolver._markdown_links(row.text, row.url, "host:text"))
        parts = urlsplit(row.url)
        filename = parts.path.rsplit("/", 1)[-1]
        if (parts.hostname in {"github.com", "www.github.com", "raw.githubusercontent.com"}
                and len(parts.path.strip("/").split("/")) >= 4
                and (_README_NAME.fullmatch(filename) or filename.lower().endswith((".md", ".markdown", ".rst", ".txt")))
                and row.content_type in {"text/plain", "text/markdown", "text/x-markdown", "text/html", "application/xhtml+xml"}):
            doc.resource_type = "documentation"
            doc.metadata.update(content_scope="host_observed_file", resource_kind="documentation", discovery_role="documentation")
        return doc

    def _readme(self, project: tuple[str, str], budget: Budget | None = None):
        for row in self._snapshots.values():
            parts = urlsplit(row.url)
            match = _README_API.fullmatch(parts.path)
            if parts.hostname != "api.github.com" or not match or tuple(part.casefold() for part in match.groups()) != project:
                continue
            if budget is not None:
                budget.take()
                budget.visit(row.url)
            body = _object(row)
            if not body or body.get("encoding") != "base64" or not isinstance(body.get("content"), str):
                continue
            path = body.get("path")
            if not isinstance(path, str) or not _README_NAME.fullmatch(path.rsplit("/", 1)[-1]):
                continue
            urls = []
            valid = True
            for field in ("html_url", "download_url"):
                if body.get(field) is not None:
                    try:
                        url = canonical_public_url(body[field])
                    except SourceError:
                        valid = False
                        break
                    if not _matching_file(url, project):
                        valid = False
                        break
                    urls.append(url)
            if not valid:
                continue
            try:
                text = base64.b64decode(re.sub(r"\s+", "", body["content"]), validate=True).decode("utf-8")
            except (ValueError, UnicodeError):
                continue
            if not text.strip():
                continue
            base = urls[0] if urls else row.url
            links = [Link(url, "readme", "Observed README", f"host-github-readme:/{field}") for url, field in zip(urls, ("html_url", "download_url"))]
            return row, text, links + SourceResolver._markdown_links(text, base, path)
        for row in self._snapshots.values():
            if _matching_file(row.url, project) and row.content_type in {"text/plain", "text/markdown", "text/x-markdown", "text/html", "application/xhtml+xml"}:
                if budget is not None:
                    budget.take()
                    budget.visit(row.url)
                doc = self._generic(row)
                if doc.text.strip():
                    return row, doc.text, doc.links
        return None

    def _repository(self, entry, budget: Budget | None = None):
        row, body, project, artifact = entry
        primary = ("host-reported original GitHub repository metadata indicates owner control and no fork/mirror; not CLI HTTP verification"
                   if body.get("fork") is False and "mirror_url" in body and body["mirror_url"] is None else None)
        lines = [body["full_name"]]
        if isinstance(body.get("description"), str):
            lines.append(body["description"])
        lines.append("Owner: " + body["owner"]["login"])
        published = _date(body.get("created_at")) if isinstance(body.get("created_at"), str) else None
        used, links = [row], []
        readme = self._readme(project, budget)
        if readme:
            readme_row, text, parsed_links = readme
            used.append(readme_row)
            lines.extend(["README:", text])
            links.extend([Link(readme_row.url, "readme", "Observed README", "host:paired_snapshot_url"), *parsed_links])
        doc = Document(artifact, title=body["full_name"], text="\n".join(lines), resource_type="repository",
                       author=body["owner"]["login"], published_at=published, primary_basis=primary, links=links,
                       metadata={"adapter": "host_github_metadata", "resolution_basis": "host-observed GitHub JSON /html_url",
                                 "fork": body.get("fork"), "mirror_url": body.get("mirror_url"),
                                 "content_scope": "repository_readme" if readme else "metadata_only",
                                 "resource_kind": _github_kind(artifact),
                                 "discovery_role": "background" if _github_kind(artifact) in {"website_repository", "author_profile"} else "project" if readme else "metadata_only",
                                 "readme_scope": "actual host-observed URL; branch/commit correspondence not independently verified",
                                 "date_basis": "host-reported repository_created_at"})
        return doc, used

    def fetch(self, url: str, budget: Budget) -> Document:
        canonical = canonical_public_url(url)
        entry = self._repositories.get(_artifact_key(canonical))
        row = entry[0] if entry is not None else self._snapshots.get(canonical)
        if row is None:
            return self.fallback.fetch(url, budget)
        budget.take()
        budget.visit(row.url)
        if entry is not None:
            doc, used = self._repository(entry, budget)
        else:
            doc, used = self._generic(row), [row]
        doc.verified_at = min(used, key=lambda row: datetime.fromisoformat(row.retrieved_at.replace("Z", "+00:00"))).retrieved_at
        doc.links = _public_links(doc.links)
        doc.metadata.update(retrieval_method="host_tool_observation", identity_verified=False,
                            freshness_status="host_observed_snapshot", trust_limitation=_TRUST,
                            transport_validation="not_independently_performed_by_cli",
                            dns_validation="not_independently_performed_by_cli", tls_validation="not_independently_performed_by_cli",
                            local_address_verified=False, role_scope="host-reported resource metadata; institution and scientific claims unverified",
                            retrieval_records=[row.record() for row in used], host_snapshots=[row.original() for row in used],
                            retrieval_observations=[{"url": row.url, "retrieval_method": "host_tool_observation",
                                                     "local_address_verified": False, "dns_validation": "not_independently_performed_by_cli",
                                                     "tls_validation": "not_independently_performed_by_cli"} for row in used])
        if budget.remaining_seconds <= 0:
            raise BudgetExceeded("host processing time budget exhausted")
        return doc
