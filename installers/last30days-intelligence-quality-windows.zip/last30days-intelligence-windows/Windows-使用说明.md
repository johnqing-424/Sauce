# Windows 本机安装

## 研究质量更新

新版 `last30days-intelligence-quality-windows.zip` 的安装方式仍是完整解压后双击
`Install-Windows.cmd`。它会备份旧 Skill，保留已经可用的 Clash 私人配置和
数据库；不需要再运行旧的五文件联网修复包。

更新后在本机 Codex 新会话中输入：

```text
$last30days intelligence discover AI
请自主选择不同探索方向，筛选 3 项值得实验的资源。每项说明新意、用途、
限制和下一步验证，引用实际原文；至少深挖一层有效关联。用中文。
```

个人主页和资料清单只作发现入口，未经分析的分数不触发新 A 推送。定时 CLI
可以收集和溯源，深入语义分析需要 Agent 参与；本机新版研究质量和真实机器人
收件需要另行实测，云端测试不能替代。

1. 下载并完整解压 `last30days-intelligence-windows.zip`。不要在压缩包内直接运行。
2. 双击 `Install-Windows.cmd`。需要 Python 3.12+；如果已经有 uv，安装器可以通过 uv 准备 Python。安装包附带官方 tzdata 的 IANA 时区数据，支持 Windows 上的北京时间日报和周报。
3. 安装窗口显示 `installed` 或 `already_installed` 后，在电脑上的 Codex 打开一个新的**本机**会话。
4. 输入：`$last30days intelligence trace https://github.com/mvanhorn/last30days-skill`。
5. 再输入：`$last30days intelligence discover robotics`，或直接描述你希望探索的领域。

Skill 安装位置是当前 Windows 用户的 `%USERPROFILE%\.agents\skills\last30days`。
安装器先检查文件校验和和 Python 语法，再复制文件；已有版本会保存在同目录的
`.last30days-backup-日期-随机值`。重复安装同一包不会再次备份。私人配置和数据库不在
Skill 目录中，安装器不会读写它们。

安装成功后，新会话应能选择或识别 `$last30days`。如果看不到，重新打开 Codex 并确保
使用本机执行环境。安装到本机不会让单独的云端会话自动获得这个 Skill。

此安装包不会启动后台任务或发送消息。先确认研究报告能正常生成，再配置自己的
Webhook、Telegram 或飞书接收端和操作系统定时任务。没有推送凭据时，真实发送尚未验证。

此版本从原开发会话保存的修改记录恢复；通知模块中无法取回的尾部按原接口重建，
验收结果以恢复后的重新测试为准，不能视为原提交 `34fc4bb` 的逐字节副本。
云端验证不能代替你的 Windows 实机安装验证。

## 已安装，但 GitHub 溯源提示地址不公开

如果你使用 Clash / Clash Verge / Mihomo，且错误中出现 `198.18.*`，这是
Fake-IP 与地址检查的兼容问题。保持 Clash 开启，下载专用的
`last30days-clash-repair.zip`，完整解压，双击 `Repair-Clash.cmd`。

修复器会备份支持版本的联网文件，检测本机 HTTP/mixed 代理端口。通过真实
GitHub HTTPS 验证后，它会保存 Skill 私有配置并自动再次溯源。看到
`external_trace_verified` 表示那台电脑实际取到了证据；模拟测试不能代替这个
结果。数据库和已有报告保留，不会发送通知或修改 Clash/Windows 代理设置。

如果显示 `No verified proxy`，打开 Clash 设置查看 HTTP/mixed 端口，然后把
窗口结果告诉本机 Codex。也可在终端执行 `Repair-Clash.cmd --proxy
http://127.0.0.1:实际端口`。如果提示版本不匹配，使用最新完整安装包；原副本
仍会备份。恢复方法与真实测试范围见修复 ZIP 的 `修复说明.md`。
